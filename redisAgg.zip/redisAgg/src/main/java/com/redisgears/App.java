package com.redisgears;


import gears.ExecutionMode;
import gears.GearsBuilder;
import gears.readers.KeysReader;
import gears.records.KeysReaderRecord;

import java.io.Serializable;


public class App implements Serializable {
    public static void main(String[] args) {

        //KeysReader reader = new KeysReader();
        KeysReader reader = new KeysReader()
                .setEventTypes(new String[]{"hset"})
                .setPattern("vehiclePosition:*");  // Adjust the pattern as needed

        GearsBuilder<KeysReaderRecord> gb = GearsBuilder.CreateGearsBuilder(reader);

        //gb.filter(r -> r.getKey().startsWith("vehiclePosition:"));
        gb.foreach(r -> {
            String deviceId = r.getHashVal().get("deviceId");
            String ignitionState = r.getHashVal().get("ignition");
            try {
                double maxSpeed = 0.0;
                double avgspeed = 0.0;
                long currentFixTime = 0;
                double avgSpeed = 0;
                String aggDevicekey = "AGG:" + deviceId;

                String previousStatus = (String) GearsBuilder.execute("HGET", aggDevicekey, "status");
                GearsBuilder.execute("HSET", aggDevicekey, "status", ignitionState);

                String fixTime = r.getHashVal().get("fixTime");
                currentFixTime = Long.parseLong(fixTime);
                Object ob2 = GearsBuilder.execute("HGET", aggDevicekey, "fixTime");
                // String prevFixTimeStr = String.valueOf(GearsBuilder.execute("GET", deviceId + ":fixTime"));
                long timeDifferenceMillis = 0;
                if (ob2 != null) {
                    long prevFixTime = Long.parseLong(String.valueOf(ob2));
                    timeDifferenceMillis = currentFixTime - prevFixTime;
                }
                GearsBuilder.execute("HSET", aggDevicekey, "fixTime", fixTime);

                if (ignitionState.equals("1")) {
                    if (previousStatus == null) {
                        String speedStr = r.getHashVal().get("speed");
                        String firstDistance = r.getHashVal().get("totalDistance");
                        GearsBuilder.execute("HSET", aggDevicekey,
                                "liveSpeed", speedStr,
                                "maxSpeed", speedStr,
                                "avgSpeed", speedStr,
                                "startCount", 1 + "",
                                "stopCount", 0 + "",
                                "idleCount", 0 + "",
                                "startTime", 0 + "",
                                "distance", 0 + "",
                                "firstDistance", firstDistance + "");
                    } else if (previousStatus.equals("1")) {
                        double speed = Double.parseDouble(r.getHashVal().get("speed"));
                        double oldSpeed = Double.parseDouble(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "liveSpeed")));
                        if (oldSpeed != speed) {
                            maxSpeed = Double.parseDouble(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "maxSpeed")));
                            if (speed > maxSpeed) {
                                GearsBuilder.execute("HSET", aggDevicekey, "maxSpeed", speed + "");
                            }
                            avgspeed = Double.parseDouble(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "avgSpeed")));
                            avgSpeed = (avgspeed + speed) / 2;
                            GearsBuilder.execute("HSET", aggDevicekey, "liveSpeed", speed + "", "avgSpeed", avgSpeed + "");
                        }
                        long oldStartTime = Long.parseLong(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "startTime")));
                        GearsBuilder.execute("HSET", aggDevicekey, "startTime", oldStartTime + timeDifferenceMillis + "");
                        double CurrentDistance = Double.parseDouble(r.getHashVal().get("totalDistance"));
                        double totalDistance = CurrentDistance - Double.parseDouble(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "firstDistance")));
                        double oldTotalDistance = Double.parseDouble(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "distance")));
                        if (totalDistance > oldTotalDistance) {
                            GearsBuilder.execute("HSET", aggDevicekey, "distance", totalDistance + "");
                        }
                    } else if (previousStatus.equals("3")) {
                        double speed = Double.parseDouble(r.getHashVal().get("speed"));

                        maxSpeed = Double.parseDouble(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "maxSpeed")));
                        if (speed > maxSpeed) {
                            GearsBuilder.execute("HSET", aggDevicekey, "maxSpeed", speed + "");
                        }
                        avgspeed = Double.parseDouble(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "avgSpeed")));
                        avgSpeed = (avgspeed + speed) / 2;
                        GearsBuilder.execute("HSET", aggDevicekey, "liveSpeed", speed + "", "avgSpeed", avgSpeed + "");

                        GearsBuilder.execute("INCRBY", aggDevicekey, "startCount", 1 + "");
                        long oldIdleTime = Long.parseLong(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "idleTime")));
                        GearsBuilder.execute("HSET", aggDevicekey, "idleTime", oldIdleTime + timeDifferenceMillis + "");
                        double CurrentDistance = Double.parseDouble(r.getHashVal().get("totalDistance"));
                        double totalDistance = CurrentDistance - Double.parseDouble(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "firstDistance")));
                        double oldTotalDistance = Double.parseDouble(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "distance")));
                        if (totalDistance > oldTotalDistance) {
                            GearsBuilder.execute("HSET", aggDevicekey, "distance", totalDistance + "");
                        }
                    } else { //for old stop
                        double speed = Double.parseDouble(r.getHashVal().get("speed"));

                        maxSpeed = Double.parseDouble(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "maxSpeed")));
                        if (speed > maxSpeed) {
                            GearsBuilder.execute("HSET", aggDevicekey, "maxSpeed", speed + "");
                        }
                        avgspeed = Double.parseDouble(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "avgSpeed")));
                        avgSpeed = (avgspeed + speed) / 2;
                        GearsBuilder.execute("HSET", aggDevicekey, "liveSpeed", speed + "", "avgSpeed", avgSpeed + "");

                        GearsBuilder.execute("INCRBY", aggDevicekey, "startCount", 1 + "");

                        long oldstopTime = Long.parseLong(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "stopTime")));
                        GearsBuilder.execute("HSET", aggDevicekey, "stopTime", oldstopTime + timeDifferenceMillis + "");
                        double CurrentDistance = Double.parseDouble(r.getHashVal().get("totalDistance"));
                        double totalDistance = CurrentDistance - Double.parseDouble(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "firstDistance")));
                        double oldTotalDistance = Double.parseDouble(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "distance")));
                        if (totalDistance > oldTotalDistance) {
                            GearsBuilder.execute("HSET", aggDevicekey, "distance", totalDistance + "");
                        }
                    }
                    //For idle
                } else if (ignitionState.equals("3")) {
                    if (previousStatus == null) {
                        String speedStr = 0 + "";
                        String firstDistance = r.getHashVal().get("totalDistance");
                        GearsBuilder.execute("HSET", aggDevicekey, "liveSpeed", speedStr,
                                "maxSpeed", speedStr,
                                "avgSpeed", speedStr,
                                "startCount", "0",
                                "stopCount", "0",
                                "idleCount", "1",
                                "startTime", "0",
                                "distance", "0",
                                "firstDistance", firstDistance + "");
                    } else if (previousStatus.equals("1")) {
                        GearsBuilder.execute("HSET", aggDevicekey, "liveSpeed", 0 + "");
                        GearsBuilder.execute("INCRBY", aggDevicekey, "idleCount", 1 + "");
                        long oldStartTime = Long.parseLong(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "startTime")));
                        GearsBuilder.execute("HSET", aggDevicekey, "startTime", oldStartTime + timeDifferenceMillis + "");
                    } else if (previousStatus.equals("3")) {
                        long oldIdleTime = Long.parseLong(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "idleTime")));
                        GearsBuilder.execute("HSET", aggDevicekey, "idleTime", oldIdleTime + timeDifferenceMillis + "");
                    } else { //for old stop
                        long oldstopTime = Long.parseLong(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "stopTime")));
                        GearsBuilder.execute("HSET", aggDevicekey, "stopTime", oldstopTime + timeDifferenceMillis + "");
                    }
                } else { //for currentstatus stop 2
                    if (previousStatus == null) {
                        String speedStr = 0 + "";
                        String firstDistance = r.getHashVal().get("totalDistance");
                        GearsBuilder.execute("HSET", aggDevicekey, "liveSpeed", speedStr,
                                "maxSpeed", speedStr,
                                "avgSpeed", speedStr,
                                "startCount", "0",
                                "stopCount", "1",
                                "idleCount", "0",
                                "startTime", "0",
                                "distance", "0",
                                "firstDistance", firstDistance + "");
                    } else if (previousStatus.equals("1")) {
                        GearsBuilder.execute("HSET", aggDevicekey, "liveSpeed", 0 + "");
                        GearsBuilder.execute("INCRBY", aggDevicekey, "stopCount", 1 + "");
                        long oldStartTime = Long.parseLong(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "startTime")));
                        GearsBuilder.execute("HSET", aggDevicekey, "startTime", oldStartTime + timeDifferenceMillis + "");
                    } else if (previousStatus.equals("3")) {
                        GearsBuilder.execute("INCRBY", aggDevicekey, "stopCount", 1 + "");
                        long oldIdleTime = Long.parseLong(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "idleTime")));
                        GearsBuilder.execute("HSET", aggDevicekey, "idleTime", oldIdleTime + timeDifferenceMillis + "");
                    } else { //for old stop
                        long oldstopTime = Long.parseLong(String.valueOf(GearsBuilder.execute("HGET", aggDevicekey, "stopTime")));
                        GearsBuilder.execute("HSET", aggDevicekey, "stopTime", oldstopTime + timeDifferenceMillis + "");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("something went wrong :" + deviceId);
            }
        });

        gb.register(ExecutionMode.ASYNC);
    }
}

        /*
        KeysReader reader = new KeysReader();

        *//*KeysReader reader = new KeysReader().setPattern("vehiclePosition:*").
                setCommands(new String[] {"hset"});
*//*
        // Create the data pipe builder
        GearsBuilder<KeysReaderRecord> gb = GearsBuilder.CreateGearsBuilder(reader);

        // Filter keys that start with "Vehicle:*"

        gb.filter(r -> r.getKey().startsWith("vehiclePosition:"));
        // Count the number of state changes from on to off and off to on for each device ID
        gb.foreach(r -> {
            // Get the device ID from the key
            String deviceId = r.getHashVal().get("deviceId");

            // Get the ignition state
            String ignitionState = r.getHashVal().get("ignition");

            // Get the previous ignition state for this device ID from Redis
            String prevIgnitionState = (String) GearsBuilder.execute("HGET", "prev:" + deviceId, "ignitionState");

            String deviceState = (String) GearsBuilder.execute("HGET", deviceId, "state");


            // If previous state exists, compare with current state and update counts
            if (prevIgnitionState != null) {
                String fixTime = String.valueOf(r.getHashVal().get("fixTime"));
                long currentFixTime = Long.parseLong(fixTime);
                String prevFixTimeStr = String.valueOf(GearsBuilder.execute("HGET", "prev:" + deviceId, "fixTime"));
                long prevFixTime = prevFixTimeStr != null ? Long.parseLong(prevFixTimeStr) : 0;

               *//* if (currentFixTime < prevFixTime) {
                    // Skip this data / iteration
                    return;
                }*//*

                String speedStr = r.getHashVal().get("speed");
                GearsBuilder.execute("HSET", deviceId, "liveSpeed", speedStr);

                double speed = speedStr != null ? Double.parseDouble(speedStr) : 0;
                // Get the current maximum speed
                String maxSpeedStr = (String) GearsBuilder.execute("HGET", deviceId, "maxSpeed");

                double maxSpeed = 0; // Initialize to 0
                if (maxSpeedStr != null) {
                    // Convert the maximum age to an integer
                    maxSpeed = Double.parseDouble(maxSpeedStr);
                }
                if (speed > maxSpeed) {
                    GearsBuilder.execute("HSET", deviceId, "maxSpeed", speedStr);
                }

                if (prevIgnitionState.equals("true") && ignitionState.equals("false")) {
                    // Ignition state changed from on to off
                    //String fixTime = r.getHashVal().get("fixTime");
                    //long currentFixTime = Long.parseLong(fixTime);

                    //String prevFixTimeStr = String.valueOf(GearsBuilder.execute("GET", "prevFixTime:" + deviceId));
                    *//*long prevFixTime = prevFixTimeStr != null ? Long.parseLong(prevFixTimeStr) : 0;*//*

                    long timeDifferenceMillis = currentFixTime - prevFixTime;
                    //GearsBuilder.execute("SET", deviceId + ":difference", String.valueOf(timeDifferenceMillis));

                    if (deviceState.equals("start")) {
                        String startTimeStr = String.valueOf(GearsBuilder.execute("HGET", deviceId, "startTime"));
                        long startTime = startTimeStr != null ? Long.parseLong(startTimeStr) : 0;
                        startTime = startTime + timeDifferenceMillis;
                        GearsBuilder.execute("HSET", deviceId, "startTime", String.valueOf(startTime));
                        GearsBuilder.execute("RPUSH", deviceId + ":timeList", fixTime + "on-off");
                        GearsBuilder.execute("HSET", deviceId + ":time", prevFixTimeStr + "-" + fixTime + ":start-stop", String.valueOf(timeDifferenceMillis)); // in sec

                        String firstDistanceStr = (String) GearsBuilder.execute("HGET", deviceId, "firstDistance");
                        double firstDistance = firstDistanceStr != null ? Double.parseDouble(firstDistanceStr) : 0;
                        String lastDistanceStr = r.getHashVal().get("totalDistance");
                        double lastDistance = lastDistanceStr != null ? Double.parseDouble(lastDistanceStr) : 0;
                        double differenceTotal = lastDistance - firstDistance;
                        GearsBuilder.execute("HSET", deviceId, "differenceTotalDistance", String.valueOf(differenceTotal));

                    } else if (deviceState.equals("Idle")) {
                        String idleTimeStr = String.valueOf(GearsBuilder.execute("HGET", deviceId, "idleTime"));
                        long idleTime = idleTimeStr != null ? Long.parseLong(idleTimeStr) : 0;
                        idleTime = idleTime + timeDifferenceMillis;
                        GearsBuilder.execute("HSET", deviceId, "idleTime", String.valueOf(idleTime));
                        GearsBuilder.execute("RPUSH", deviceId + ":timeList", fixTime + "idle-off");
                        GearsBuilder.execute("HSET", deviceId + ":time", prevFixTimeStr + "-" + fixTime + ":idle-stop", String.valueOf(timeDifferenceMillis)); // in sec
                    }
                    GearsBuilder.execute("HINCRBY", deviceId, "offCount", String.valueOf("1"));
                    GearsBuilder.execute("HSET", "prev:" + deviceId, "fixTime", fixTime);
                    GearsBuilder.execute("HSET", deviceId, "state", "stop");

                } else if (prevIgnitionState.equals("false") && ignitionState.equals("true")) {

                    long timeDifferenceMillis = currentFixTime - prevFixTime;
                    //GearsBuilder.execute("SET", deviceId + ":difference", String.valueOf(timeDifferenceMillis));
                    String stopTimeStr = String.valueOf(GearsBuilder.execute("HGET", deviceId, "stopTime"));
                    long stopTime = stopTimeStr != null ? Long.parseLong(stopTimeStr) : 0;

                    stopTime = stopTime + timeDifferenceMillis;
                    GearsBuilder.execute("HSET", deviceId, "stopTime", String.valueOf(stopTime));
                    try {
                        if (!speedStr.equals("0")) {
                            GearsBuilder.execute("INCR", deviceId + ":onCount");
                            GearsBuilder.execute("RPUSH", deviceId + ":timeList", fixTime + "off-on");
                            GearsBuilder.execute("HSET", deviceId + ":time", prevFixTimeStr + "-" + fixTime + ":stop-start", String.valueOf(timeDifferenceMillis)); // in sec
                            GearsBuilder.execute("HSET", deviceId, "state", "start");

                            String avgSpeedStr = (String) GearsBuilder.execute("HGET", deviceId, "avgSpeed");
                            String prevSpeedStr = (String) GearsBuilder.execute("HGET", deviceId, "prevSpeed");
                            double prevSpeed = 0;
                            double avgSpeed = -1;

                            if (prevSpeedStr != null) {
                                prevSpeed = Integer.parseInt(prevSpeedStr);
                            }
                            if (avgSpeedStr != null) {
                                avgSpeed = Integer.parseInt(avgSpeedStr);
                            }
                            if (prevSpeed != speed && avgSpeed != -1 && prevSpeed != 0 && speed != 0) {
                                avgSpeed = (avgSpeed + speed) / 2;
                                GearsBuilder.execute("HSET", deviceId ,"avgSpeed", String.valueOf(avgSpeed));
                                GearsBuilder.execute("HSET", deviceId ,"prevSpeed", speedStr);
                            }

                            //Calculate total Distance
                            String firstDistanceStr = (String) GearsBuilder.execute("HGET", deviceId ,"firstDistance");
                            double firstDistance = firstDistanceStr != null ? Double.parseDouble(firstDistanceStr) : 0;
                            String lastDistanceStr = r.getHashVal().get("totalDistance");
                            double lastDistance = lastDistanceStr != null ? Double.parseDouble(lastDistanceStr) : 0;
                            double differenceTotal = lastDistance - firstDistance;
                            GearsBuilder.execute("HSET", deviceId ,"differenceTotalDistance", String.valueOf(differenceTotal));
                        } else {
                            GearsBuilder.execute("INCR", deviceId + ":idleCount");
                            GearsBuilder.execute("RPUSH", deviceId + ":TimeList", fixTime + "off-idle");
                            GearsBuilder.execute("HSET", deviceId + ":time", prevFixTimeStr + "-" + fixTime + ":stop-idle", String.valueOf(timeDifferenceMillis)); // in sec
                            GearsBuilder.execute("HSET", deviceId, "state", "idle");
                        }
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }
                    GearsBuilder.execute("HSET", "prev:" + deviceId, "fixTime",fixTime);

                    // Convert time difference from milliseconds to hours, minutes, and seconds
                   *//* long seconds = (startTime / 1000) % 60;
                    long minutes = (startTime / (1000 * 60)) % 60;
                    long hours = (startTime / (1000 * 60 * 60)) % 24;*//*

                    // Format the time difference into "hr:mm:ss" format
                    //String startTimeFormatted = String.format("%02d:%02d:%02d", hours, minutes, seconds);

                } else if (prevIgnitionState.equals("true") && ignitionState.equals("true")) {

                    if (deviceState.equals("Start") && speedStr.equals("0")) {

                        long timeDifferenceMillis = currentFixTime - prevFixTime;
                        String idleTimeStr = String.valueOf(GearsBuilder.execute("HGET", deviceId,"idleTime"));
                        long idleTime = idleTimeStr != null ? Long.parseLong(idleTimeStr) : 0;
                        idleTime = idleTime + timeDifferenceMillis;

                        long seconds = (idleTime / 1000) % 60;
                        long minutes = (idleTime / (1000 * 60)) % 60;
                        long hours = ((idleTime / (1000 * 60 * 60)) % 24);
                        String idleTimeFormatted = String.format("%02d:%02d:%02d", hours, minutes, seconds);

                        GearsBuilder.execute("HSET", deviceId , "state", "idle");
                        GearsBuilder.execute("HINCRBY", deviceId ,"idleCount",String.valueOf("1"));
                        GearsBuilder.execute("HSET", deviceId , "idleTime", String.valueOf(idleTime));
                        GearsBuilder.execute("HSET", deviceId , "idleTimeHour", idleTimeFormatted);
                        GearsBuilder.execute("RPUSH", deviceId + ":timeList", fixTime + "start-idle");
                        GearsBuilder.execute("HSET", deviceId + ":time", prevFixTimeStr + "-" + fixTime + ":stop-idle", String.valueOf(timeDifferenceMillis)); // in sec
                        GearsBuilder.execute("HSET", "prev:" + deviceId,"fixTime", fixTime);


                    } else if (deviceState.equals("Idle") && !speedStr.equals("0")) {

                        long timeDifferenceMillis = currentFixTime - prevFixTime;
                        String startTimeStr = String.valueOf(GearsBuilder.execute("HGET", deviceId , "startTime"));
                        long startTime = startTimeStr != null ? Long.parseLong(startTimeStr) : 0;
                        startTime = startTime + timeDifferenceMillis;
                        long seconds = (startTime / 1000) % 60;
                        long minutes = (startTime / (1000 * 60)) % 60;
                        long hours = ((startTime / (1000 * 60 * 60)) % 24);
                        String startTimeFormatted = String.format("%02d:%02d:%02d", hours, minutes, seconds);
                        GearsBuilder.execute("HSET", deviceId , "state", "start");
                        GearsBuilder.execute("HINCRBY", deviceId , "startCount",String.valueOf("1"));
                        GearsBuilder.execute("HSET", deviceId , "startTime", startTimeFormatted);
                        GearsBuilder.execute("RPUSH", deviceId + ":timeList", fixTime + "idle-start");
                        GearsBuilder.execute("HSET", deviceId + ":time", prevFixTimeStr + "-" + fixTime + ":idle-start", String.valueOf(timeDifferenceMillis)); // in sec
                        GearsBuilder.execute("SET", "prev:" + deviceId, "fixTime",fixTime);

                        String avgSpeedStr = (String) GearsBuilder.execute("HGET", deviceId , "avgSpeed");
                        String prevSpeedStr = (String) GearsBuilder.execute("HGET", deviceId , "prevSpeed");
                        double prevSpeed = 0;
                        double avgSpeed = -1;


                        if (prevSpeedStr != null) {
                            prevSpeed = Integer.parseInt(prevSpeedStr);
                        }
                        if (avgSpeedStr != null) {
                            avgSpeed = Integer.parseInt(avgSpeedStr);
                        }
                        if (prevSpeed != speed && avgSpeed != -1 && prevSpeed != 0 && speed != 0) {
                            avgSpeed = (avgSpeed + speed) / 2;
                            GearsBuilder.execute("HSET", deviceId , "avgSpeed", String.valueOf(avgSpeed));
                            GearsBuilder.execute("HSET", deviceId , "prevSpeed", speedStr);
                        }


                    } else {
                        String avgSpeedStr = String.valueOf(GearsBuilder.execute("HGET", deviceId , "avgSpeed"));
                        String prevSpeedStr = String.valueOf(GearsBuilder.execute("HGET", deviceId , "prevSpeed"));
                        double prevSpeed = 0;
                        double avgSpeed = -1;

                        if (prevSpeedStr != null) {
                            prevSpeed = Double.parseDouble(prevSpeedStr);
                        }
                        if (avgSpeedStr != null) {
                            avgSpeed = Double.parseDouble(avgSpeedStr);
                        }
                        if (prevSpeed != speed && avgSpeed != -1 && prevSpeed != 0 && speed != 0) {
                            avgSpeed = (avgSpeed + speed) / 2;
                            GearsBuilder.execute("HSET", deviceId, "avgSpeed", String.valueOf(avgSpeed));
                            GearsBuilder.execute("HSET", deviceId, "prevSpeed", speedStr);
                        }
                    }
                    String firstDistanceStr = (String) GearsBuilder.execute("HGET", deviceId, "firstDistance");
                    double firstDistance = firstDistanceStr != null ? Double.parseDouble(firstDistanceStr) : 0;
                    String lastDistanceStr = r.getHashVal().get("totalDistance");
                    double lastDistance = lastDistanceStr != null ? Double.parseDouble(lastDistanceStr) : 0;
                    double differenceTotal = lastDistance - firstDistance;
                    GearsBuilder.execute("HSET", deviceId, "differenceTotalDistance", String.valueOf(differenceTotal));
                }
            } else {
                if (ignitionState.equals("false")) {

                    String fixTime = r.getHashVal().get("fixTime");
                    GearsBuilder.execute("HINCRBY", deviceId, "offCount", String.valueOf("1"));
                    //List By device id and the on and Off Time
                    GearsBuilder.execute("RPUSH", deviceId + ":timeList", fixTime + ":stop");
                    GearsBuilder.execute("SET", "prevFixTime:" + deviceId, fixTime);
                    GearsBuilder.execute("HSET", deviceId, "state", "stop");
                    GearsBuilder.execute("HSET", deviceId, "liveSpeed", String.valueOf("0"));

                } else if (ignitionState.equals("true")) {

                    String fixTime = r.getHashVal().get("fixTime");
                    String speedStr = r.getHashVal().get("speed");
                    GearsBuilder.execute("HSET", deviceId, "liveSpeed", speedStr);

                    //Check vehicle is idle
                    if (speedStr.equals("0")) {
                        GearsBuilder.execute("HINCRBY", deviceId , "idleCount", String.valueOf("1"));
                        GearsBuilder.execute("RPUSH", deviceId + ":timeList", fixTime + ":idle");
                        GearsBuilder.execute("HSET", "prev:" + deviceId,"fixTime" ,fixTime);
                        GearsBuilder.execute("HSET", deviceId, "state", "idle");

                    } else {
                        String firstDistance = r.getHashVal().get("totalDistance");
                        GearsBuilder.execute("HINCRBY", deviceId , "onCount",String.valueOf("1"));
                        GearsBuilder.execute("RPUSH", deviceId + ":timeList", fixTime + ":start");
                        GearsBuilder.execute("HSET", "prev:" + deviceId, "fixTime",fixTime);
                        GearsBuilder.execute("HSET", deviceId, "state", "start");
                        GearsBuilder.execute("HSET", deviceId, "avgSpeed", speedStr);
                        GearsBuilder.execute("HSET", deviceId, "prevSpeed", speedStr);
                        GearsBuilder.execute("HSET", deviceId, "firstDistance", firstDistance);

                    }
                }
                GearsBuilder.execute("HSET", deviceId, "startTime", String.valueOf(0)); // ,NX

                GearsBuilder.execute("HSET", deviceId, "stopTime", String.valueOf(0));

                GearsBuilder.execute("HSET", deviceId, "idleTime", String.valueOf(0));

            }
            // Store current ignition state for this device ID for the next iteration
            GearsBuilder.execute("HSET", "prev:" + deviceId,"ignitionState", ignitionState);

            // GearsBuilder.execute("EXPIRE", "onCount:" + deviceId, "86400"); // 86400 seconds = 24 hours

        });
        // Store this pipeline of functions and
        // run them when a new person key is added
       // gb.register();

        gb.run();

        // Note: ExecutionMode defaults to ASYNC
        // if you call register() without any arguments

    }
}*/




/*
public class CarOnOffGears implements Serializable {

    private static final long serialVersionUID = 1L;
    int carInCount; // Number of vehicles entering
    int carOutCount; // Number of vehicles exiting
    private Boolean previousIgnitionState; // Track previous ignition state

    // CarOnOffGears constructor
    public CarOnOffGears(int carInCount, int carOutCount) {
        this.carInCount = carInCount;
        this.carOutCount = carOutCount;
        this.previousIgnitionState = false;
    }

    // Getter and setter for previousIgnitionState
    public boolean getPreviousIgnitionState() {
        return previousIgnitionState;
    }

    public void setPreviousIgnitionState(boolean previousIgnitionState) {
        this.previousIgnitionState = previousIgnitionState;
    }

    public static void main(String args[]) {
        // Create the reader that will pass data to the pipe
        KeysReader reader = new KeysReader();

        // Create the data pipe builder
        GearsBuilder<KeysReaderRecord> gb = GearsBuilder.CreateGearsBuilder(reader);

        // Filter for vehicle data keys
        gb               // Extract ignition state (assuming "ignition" field)
                .map(r -> r.getHashVal().get("ignition").equals("true"))
                // Accumulate car in/out counts based on state change
                // Accumulate car in/out counts based on state change
                .accumulate(new CarOnOffGears(0, 0), (accumulator, record) -> {
                    if (accumulator.previousIgnitionState == null) {
                        accumulator.previousIgnitionState = false;
                    }
                    boolean currentIgnitionState = (boolean) record;
                    if (!accumulator.getPreviousIgnitionState() && currentIgnitionState) {
                        accumulator.carInCount++;
                    } else if (accumulator.getPreviousIgnitionState() && !currentIgnitionState) {
                        accumulator.carOutCount++;
                    }
                    accumulator.setPreviousIgnitionState(currentIgnitionState);
                    return accumulator;
                })
                // No further mapping needed (counts are already accumulated)
                .run();
    }

}*/
