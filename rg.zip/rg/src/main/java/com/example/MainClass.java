package com.example;

import gears.ExecutionMode;
import gears.GearsBuilder;
import gears.readers.KeysReader;
import gears.records.KeysReaderRecord;

public class MainClass {

    public static void main(String args[]){
        System.out.println("Hello !! Redis Gears :...");

        // Create the reader that will pass data to the pipe
        KeysReader reader = new KeysReader();

        // Create the data pipe builder
        GearsBuilder<KeysReaderRecord> gb = GearsBuilder.CreateGearsBuilder(reader);

        // Only process keys that start with "person:"
        gb.filter(r->{
            return r.getKey().startsWith("person:");
        });


        // Compare each person's age to the current maximum age
        gb.foreach(r->{
            String newAgeStr = r.getHashVal().get("age");
            int newAge = Integer.parseInt(newAgeStr);

            // Get the current maximum age
            String maxAgeKey = "age:maximum";
            String maxAgeStr = (String) GearsBuilder.execute("GET", maxAgeKey);

            int maxAge = 0; // Initialize to 0
            if (maxAgeStr != null) {
                // Convert the maximum age to an integer
                maxAge = Integer.parseInt(maxAgeStr);
            }

            // Update the maximum age if a new age is higher
            if (newAge > maxAge) {
                GearsBuilder.execute("SET", maxAgeKey, newAgeStr);
            }
        });

        // Store this pipeline of functions and
        // run them when a new person key is added
        gb.register(ExecutionMode.SYNC);
        // Note: ExecutionMode defaults to ASYNC
        // if you call register() without any arguments

        System.out.println("Command Executed");
    }
}



/*
Run commnad in terminal

clean > install > package

 redis-cli -x RG.JEXECUTE com.example.MainClass < /home/krishnab/Downloads/rg/target/original-rg-1.0-SNAPSHOT.jar


* */
