package com.om.jsonredis.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.om.jsonredis.entity.PosData;
import com.om.jsonredis.repository.PosDataRepository;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import redis.clients.jedis.UnifiedJedis;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class PosDataService {

    @Autowired
    PosDataRepository posdataRepository;

    //Save Method
    public void save(String jsonData) throws JsonProcessingException {
        System.out.println("\n\n\nJson Data\n" + jsonData);
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setTimeZone(TimeZone.getTimeZone("UTC"));
        PosData posData = objectMapper.readValue(jsonData, PosData.class);
        System.out.println("\n------------Data--------------\n" + posdataRepository.save(posData));

        /*m1.put("PosData", posData);
        m1.put("status", "Okay");
        return m1;*/

        //Working exmaple of comaparing
       /* try (UnifiedJedis jedis = new UnifiedJedis("redis://localhost:6379")) {
            String key = "cnf:deviceId:" + posData.getPosition().getDeviceId();
            Integer speedvalue = Integer.valueOf(jedis.hget(key, "speed"));

            System.out.println("\n     " + speedvalue);
            System.out.println("\n  Spghgkj   " + String.valueOf(speedvalue));
            if (posData.getPosition().getSpeed() > speedvalue) {
                m1.put("status", "Okay");
                m1.put("message", "The Speed is High");
                return m1;
            } else {
                m1.put("status", "Okay");
                m1.put("message", "The Speed is Low");
                return m1;
            }
        }*/

    }

    // Range Between In FixTime
    public List<PosData> findByFixTimeRange(String jsonData) throws ParseException {
        JSONObject jData = new JSONObject(jsonData);
        String startDate = jData.getString("startDate");
        String endDate = jData.getString("endDate");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormat2.setTimeZone(TimeZone.getTimeZone("UTC"));
        try {
            // Parse the input string to a Date object
            Date startParsedDate = dateFormat.parse(startDate);
            System.out.println("Date Format " + startParsedDate);
            long sDate = startParsedDate.getTime();
            System.out.println("millisecond " + sDate);

            Date endParsedDate = dateFormat2.parse(endDate);
            System.out.println("Date Format " + endParsedDate);
            long eDate = endParsedDate.getTime();
            System.out.println("millisecond " + eDate);

            return posdataRepository.findByFixTimeRange(sDate, eDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }

    }

    //Method that will retrieve data between time
    public List<PosData> findServerTimeRange(String jsonData) throws ParseException {
        JSONObject jData = new JSONObject(jsonData);
        String startDate = jData.getString("startDate");
        String endDate = jData.getString("endDate");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormat2.setTimeZone(TimeZone.getTimeZone("UTC"));
        try {
            // Parse the input string to a Date object
            Date startParsedDate = dateFormat.parse(startDate);
            System.out.println("Date Format " + startParsedDate);
            long sDate = startParsedDate.getTime();
            System.out.println("millisecond " + sDate);

            Date endParsedDate = dateFormat2.parse(endDate);
            System.out.println("Date Format " + endParsedDate);
            long eDate = endParsedDate.getTime();
            System.out.println("millisecond " + eDate);

            return posdataRepository.findByServerTimeRange(sDate, eDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }

    }

    //Method that will retrieve data between time
    public List<PosData> findDeviceTimeRange(String jsonData) throws ParseException {
        JSONObject jData = new JSONObject(jsonData);
        String startDate = jData.getString("startDate");
        String endDate = jData.getString("endDate");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormat2.setTimeZone(TimeZone.getTimeZone("UTC"));
        try {
            // Parse the input string to a Date object
            Date startParsedDate = dateFormat.parse(startDate);
            System.out.println("Date Format " + startParsedDate);
            long sDate = startParsedDate.getTime();
            System.out.println("millisecond " + sDate);

            Date endParsedDate = dateFormat2.parse(endDate);
            System.out.println("Date Format " + endParsedDate);
            long eDate = endParsedDate.getTime();
            System.out.println("millisecond " + eDate);

            return posdataRepository.findByPosition_DeviceTimeRange(sDate, eDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }

    }

    //In Position Device Id data retrieval
    public Iterable<PosData> findByPosition_DeviceId(long id) {
        return posdataRepository.findByPosition_DeviceId(id);
    }

    //Error while parsing
    //While Saving Data Comparing Device ID and Speed In the Redis Database.
    public PosData loadData(String jsonData) throws JsonProcessingException, ParseException {
        ObjectMapper objectMapper = new ObjectMapper();
        PosData posData = objectMapper.readValue(jsonData, PosData.class);

        JSONObject jData = new JSONObject(jsonData);
        //String serverTime = jData.getJSONObject("position").getString("serverTime");
        //System.out.println("\n\nSERverTime " + serverTime);
        String deviceTime = jData.getJSONObject("position").getString("deviceTime").toString();
        // SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        SimpleDateFormat datetimeFormatter2 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        System.out.println("device Time " + deviceTime);
        // Date serverDate1 = datetimeFormatter1.parse(serverTime);
        Date deviceDate2 = datetimeFormatter2.parse(deviceTime);
        System.out.println("device Time " + deviceTime);

        //System.out.println("gpsdate :" + serverDate1);
        //Timestamp serverTS1 = new Timestamp(serverDate1.getTime());
        Timestamp deviceTS1 = new Timestamp(deviceDate2.getTime());
        //System.out.println("\n\n\nThe Start Time" + serverTS1);
        System.out.println("\nThe End Time" + deviceTS1);

        posData.getPosition().setDeviceTime(deviceTS1);
        //posData.getPosition().setServerTime(serverTS1);

        System.out.println("\n\n\n Vehicle Position Data" + posData);
        PosData p1 = posdataRepository.save(posData);
        System.out.println("\n\n\n\n\n\n New Repo" + p1);


        try (UnifiedJedis jedis = new UnifiedJedis("redis://localhost:6379")) {
            String key = "cnf:deviceId:" + posData.getPosition().getDeviceId();
            Integer speedvalue = Integer.valueOf(jedis.hget(key, "speed"));


            System.out.println("\n     {speedvalue}.");
            if (posData.getPosition().getSpeed() > speedvalue) {
                System.out.println("The Speed is High.");
            } else {
                System.out.println("The Speed is Low .");
            }
        }
        return p1;
    }

    private int countsch = 0;

    //@Scheduled(fixedRate = 100) // Run every 60000 milliseconds / 100
    public void scheduledMethod() {
        try {

            // Assuming you have jsonData available
            saveHash("{\"position\":{\"id\":0,\"attributes\":{\"sat\":15,\"mcc\":404,\"mnc\":212,\"lac\":5321,\"cid\":39299,\"ignition\":true,\"event\":0,\"archive\":false,\"mileage\":0.06609999999999999,\"total_mileage\":22433.837199997564,\"distance\":1398.95,\"totalDistance\":8263141.62,\"motion\":true,\"hours\":9979485000},\"deviceId\":2201,\"type\":null,\"uuid\":null,\"protocol\":\"gt06\",\"serverTime\":null,\"deviceTime\":\"2024-01-05T06:22:31.000+0000\",\"fixTime\":\"2024-01-05T06:22:31.000+0000\",\"outdated\":false,\"valid\":true,\"latitude\":23.060808333333334,\"longitude\":72.5105688888889,\"altitude\":0.0,\"speed\":22.678194,\"course\":65.0,\"address\":\"Sola, Daskroi Taluka, Ahmedabad District, Gujarat, India\",\"accuracy\":0.0,\"business_device_id\":3676,\"network\":null,\"ignition\":0,\"trip\":0,\"port\":6005,\"distance\":0.0,\"stopage_time\":0,\"obtype\":\"lbs\",\"battery\":0.0,\"mileage\":22433.837199997564,\"idle\":0,\"fuel\":0,\"temperature\":0,\"ac\":0,\"vin_number\":\"0000\"}}");
            countsch++;
            System.out.println("Method called " + countsch + " times.");
        } catch (JsonProcessingException e) {
            // Handle the exception
            e.printStackTrace();
        }
    }



    //Save Hash
    public void saveHash(String jsonData) throws JsonProcessingException {

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setTimeZone(TimeZone.getTimeZone("UTC"));
        PosData posData = objectMapper.readValue(jsonData, PosData.class);


        // System.out.println("\n------------Data--------------\n" + posdataRepository.save(posData));
        posdataRepository.save(posData);


        try (UnifiedJedis jedis = new UnifiedJedis("redis://192.168.0.53:6380")) {
            // Nested HashMap for "position" data
            HashMap<String, String> positionMap = new HashMap<>();

            Boolean ignition = null;

            if (posData.getPosition().getIgnition() == 1) {
                //System.out.println("One");
                ignition = true;
            } else if (posData.getPosition().getIgnition() == 2) {
                // Ignition is 2, device is off
                //System.out.println("two");
                ignition = false;
            } else if (posData.getPosition().getIgnition() == 0) {
                //System.out.println("zero");
                if (posData.getPosition().getAttributes().isIgnition() || "yes".equalsIgnoreCase(posData.getPosition().getAttributes().getIgnition_on())) {
                    // Ignition_on is "yes", device is on
                    //System.out.println("zero-Yes");
                    ignition = true;
                } else if (!posData.getPosition().getAttributes().isIgnition() || "no".equalsIgnoreCase(posData.getPosition().getAttributes().getIgnition_off())) {
                    // Ignition_off is "no", device is off
                    // System.out.println("zero-No");
                    ignition = false;
                } /*else {
                    System.out.println("ELSE BLOCK");
                }*/
            }

            double distance = posData.getPosition().getAttributes().getDistance();
            positionMap.put("distance", distance > 0 ? String.valueOf(distance) : "null");
            double totalDistance = posData.getPosition().getAttributes().getDistance();
            positionMap.put("totalDistance", totalDistance > 0 ? String.valueOf(totalDistance) : "null");

            positionMap.put("deviceId", String.valueOf(posData.getPosition().getDeviceId()));
            positionMap.put("fixTime", String.valueOf(posData.getPosition().getFixTime().getTime()));
            positionMap.put("speed", String.valueOf(posData.getPosition().getSpeed()));
            positionMap.put("ignition", String.valueOf(ignition));

            /*for (Map.Entry<String, String> entry : positionMap.entrySet()) {
                System.out.println(entry.getKey() + ": " + entry.getValue());
            }
*/

            // ... add other key-value pairs for remaining nested elements


            // System.out.println("Hset :" + jedis.hset("one", positionMap));
            jedis.hset("vehiclePosition:"+String.valueOf(posData.getPosition().getFixTime().getTime()), positionMap);
        }

    }


    public Optional<PosData> findPosServerLastHour() {
        System.out.println(System.currentTimeMillis());
        long currentTime = System.currentTimeMillis();
        long hourAgoTime = (System.currentTimeMillis() - 3600000);
        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
        Timestamp oneHourAgoTimestamp = new Timestamp(System.currentTimeMillis() - 3600000); // 1 hour in milliseconds
        System.out.println("\n\nCurrent TimeStamp" + currentTimestamp + "\nOne Hour AGO" + oneHourAgoTimestamp);
        // getPositionsLastHour( )
        return posdataRepository.findByServerTimeLastHour(hourAgoTime, currentTime);
    }

}


