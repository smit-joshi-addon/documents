package com.om.jsonredis;

import com.redis.om.spring.annotations.EnableRedisDocumentRepositories;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableRedisDocumentRepositories(basePackages = "com.om.jsonredis.*")
@Configuration
@ComponentScan(basePackages = {"com.om.jsonredis.controller", "com.om.jsonredis.repository", "com.om.jsonredis.service"})
@SpringBootApplication
@EnableScheduling
public class JsonredisApplication {

    public static void main(String[] args) {
        SpringApplication.run(JsonredisApplication.class, args);
    }

}
