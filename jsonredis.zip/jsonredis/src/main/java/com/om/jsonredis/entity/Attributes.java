package com.om.jsonredis.entity;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.redis.om.spring.annotations.Document;
import com.redis.om.spring.annotations.Indexed;
import lombok.*;

/*
@Getter
@Setter*/
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
//@RequiredArgsConstructor(staticName = "of")
@AllArgsConstructor(access = AccessLevel.PROTECTED)
@Data
@Document(timeToLive = 10L)
public class Attributes {
    @Indexed
    @NonNull
    private int sat;

    @Indexed
    @NonNull
    private int mcc;

    @Indexed
    @NonNull
    private int mnc;

    @Indexed
    @NonNull
    private int lac;

    @Indexed
    @NonNull
    private long cid;

    @Indexed
    private boolean ignition;

    @Indexed
    private String ignition_on;

    @Indexed
    private String ignition_off;

    @Indexed
    @NonNull
    private long event;

    @Indexed
    @NonNull
    private boolean archive;

    @Indexed
    @NonNull
    private double mileage;

    @Indexed
    @NonNull
    private double total_mileage;

    @Indexed
    @NonNull
    private double distance;

    @Indexed
    private int status;

    @Indexed
    @NonNull
    private double totalDistance;

    @Indexed
    @NonNull
    private boolean motion;

    @Indexed
    @NonNull
    private long hours;

    @Indexed
    private double power;




}
