package com.om.jsonredis.repository;

import com.om.jsonredis.entity.Attributes;
import com.redis.om.spring.repository.RedisDocumentRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AttributesRepository extends RedisDocumentRepository<Attributes,Long> {
}
