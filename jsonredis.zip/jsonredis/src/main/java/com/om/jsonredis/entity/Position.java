package com.om.jsonredis.entity;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.redis.om.spring.annotations.Document;
import com.redis.om.spring.annotations.Indexed;
import lombok.*;
import org.checkerframework.checker.units.qual.N;
import org.springframework.data.annotation.Id;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@RequiredArgsConstructor(staticName = "of")
@AllArgsConstructor(access = AccessLevel.PROTECTED)
@Data
@Document(timeToLive = 10L)
public class Position {

    @Id
    @Indexed @NonNull
    private long id;

    @Indexed(sortable = true) @NonNull
    private Timestamp fixTime;


   /* @NonNull
    @Indexed(sortable = true)
    private LocalDateTime permitTimestamp = LocalDateTime.now();*/


    @Indexed @NonNull
    private Attributes attributes;

    @Indexed @NonNull
    private long deviceId;

    @Indexed
    private String type;

    @Indexed
    private String uuid;

    @Indexed
    private String protocol;

    @Indexed(sortable = true)
    private Timestamp serverTime;

    @Indexed(sortable = true)
    private Timestamp deviceTime;





    @Indexed
    private Boolean outdated;

    @Indexed
    private Boolean valid;

    @Indexed
    private double latitude;

    @Indexed
    private double longitude;

    @Indexed
    private double altitude;

    @Indexed
    private double speed;

    @Indexed
    private double course;

    @Indexed
    private String address;

    @Indexed
    private int accuracy;

    @Indexed
    private long business_device_id;

    @Indexed
    private String network;

    @Indexed
    private int ignition;

    @Indexed
    private int trip;

    @Indexed
    private long port;

    @Indexed
    private double distance;

    @Indexed
    private int stopage_time;

    @Indexed
    private String obtype;

    @Indexed
    private double battery;

    @Indexed
    private double mileage;

    @Indexed
    private int idle;

    @Indexed
    private int fuel;

    @Indexed
    private int temperature;

    @Indexed
    private int ac;

    @Indexed
    private String vin_number;
}