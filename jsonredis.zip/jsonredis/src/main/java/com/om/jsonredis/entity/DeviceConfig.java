package com.om.jsonredis.entity;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.DateSerializer;
import com.redis.om.spring.annotations.Document;
import com.redis.om.spring.annotations.Indexed;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import java.sql.Timestamp;
import java.util.Date;


@NoArgsConstructor
@AllArgsConstructor
@Data
@Document
public class DeviceConfig {
    @Id @Indexed
    private String Id;

    @Indexed
    @JsonSerialize(using = DateSerializer.class)
    private Timestamp myDateTime; // Use Date to store date and time

    @Indexed @NonNull
    private Position position;

    @Indexed
    private Timestamp currentT;

    // Constructors, getters, setters...
}



