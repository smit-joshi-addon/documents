package com.om.jsonredis.repository;

import com.om.jsonredis.entity.Device;
import com.redis.om.spring.repository.RedisDocumentRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DeviceRepository extends RedisDocumentRepository<Device,Long> {
}
