package com.om.jsonredis.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.om.jsonredis.entity.DeviceConfig;
import com.om.jsonredis.repository.DeviceConfigRepository;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
@RequestMapping("dc")
public class DeviceConfigController {
    @Autowired
    DeviceConfigRepository deviceConfigRepository;

    @PostMapping("save")
    public DeviceConfig saveDC(@RequestBody String jdcData) throws ParseException, JsonProcessingException {

        ObjectMapper objectMapper = new ObjectMapper();
        DeviceConfig dcData = objectMapper.readValue(jdcData, DeviceConfig.class);

        JSONObject jData = new JSONObject(jdcData);
        String myDateTime = jData.getString("myDateTime");
        SimpleDateFormat inputFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

        try {
            Date date = inputFormatter.parse(myDateTime);
            SimpleDateFormat outputFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z");
            String formattedDateTime = outputFormatter.format(date);
            System.out.println("Date Before" + formattedDateTime);
            SimpleDateFormat datetimeFormatterUTC = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            datetimeFormatterUTC.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
            Date deviceDate2 = datetimeFormatterUTC.parse(formattedDateTime);
            System.out.println("\n\ndeviceDate2" + deviceDate2);

            DateFormat formatterUTC = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            formatterUTC.setTimeZone(TimeZone.getTimeZone("UTC")); // UTC timezone
            System.out.println("UTC Date" + formatterUTC.format(deviceDate2)); // output: 14-05-2014 18:30:00

            Timestamp ParseDAte = new Timestamp(deviceDate2.getTime());
            System.out.println("ParseDAte========>>" + ParseDAte);
            dcData.setMyDateTime(ParseDAte);

        } catch (ParseException e) {
            e.printStackTrace();
        }
        System.out.println("\n\n\n================================================================");
        return deviceConfigRepository.save(dcData);
    }

    @PostMapping("dateRange")
    public List<DeviceConfig> findDataWithinDateRange(@RequestBody String dcData) {
        JSONObject jOb = new JSONObject(dcData);
        String startDate = jOb.getString("startDate");
        String endDate = jOb.getString("endDate");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormat2.setTimeZone(TimeZone.getTimeZone("UTC"));
        try {
            // Parse the input string to a Date object
            Date startparsedDate = dateFormat.parse(startDate);
            System.out.println("DAte Format " + startparsedDate);

            long sDate = startparsedDate.getTime();
            System.out.println("millisecond" + sDate);


            // Parse the input string to a Date object
            Date endparsedDate = dateFormat2.parse(endDate);
            Long eDate = endparsedDate.getTime();
            System.out.println("millisecond" + eDate);



            return deviceConfigRepository.findByMyDateTimeBetween(sDate, eDate);
        } catch (ParseException e) {
             e.printStackTrace();
        }
        return null;
    }
}

