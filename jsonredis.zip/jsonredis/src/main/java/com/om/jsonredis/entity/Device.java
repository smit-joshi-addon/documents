package com.om.jsonredis.entity;

import com.redis.om.spring.annotations.Document;
import com.redis.om.spring.annotations.Indexed;
import lombok.*;
import org.springframework.data.annotation.Id;

import java.sql.Timestamp;


/*@Getter
@Setter*/
@NoArgsConstructor
//@RequiredArgsConstructor(staticName = "of")
@AllArgsConstructor(access = AccessLevel.PROTECTED)
@Data
@Document
public class Device {
    @Id
    @Indexed
    private long id;

    @Indexed
    private int groupId;

    @Indexed
    private String name;

    @Indexed
    private String uniqueId;

    @Indexed
    private String status;

    @Indexed
    private Timestamp lastUpdate;

    @Indexed
    private long positionId;

    @Indexed
    private long geofenceIds;

    @Indexed
    private String phone;

    @Indexed
    private String model;

    @Indexed
    private String contact;

    @Indexed
    private String category;
    @Indexed
    private Boolean disabled;
    @Indexed
    private Timestamp expirationTime;
}
