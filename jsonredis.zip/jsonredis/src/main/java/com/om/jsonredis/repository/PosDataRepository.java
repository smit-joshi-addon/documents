package com.om.jsonredis.repository;

import com.om.jsonredis.entity.PosData;
import com.redis.om.spring.annotations.Aggregation;
import com.redis.om.spring.annotations.Query;
import com.redis.om.spring.repository.RedisDocumentRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public interface PosDataRepository extends RedisDocumentRepository<PosData, String> {

    Optional<PosData> findById(String id);

    Iterable<PosData> findByPosition_DeviceId(long id);


    //Method to find record of fixTime By Range
    @Query("@position_fixTime:[$sDate $eDate]")
    List<PosData> findByFixTimeRange(long sDate, long eDate);

    @Query("@position_deviceId:[$id $tid] @position_fixTime:[prevTime $currentTime]")
    List<PosData> findIgnition(long id , long tid,long prevTime ,long currentTime);

    // Not Working @Query("SELECT pd FROM PosData pd WHERE pd.Id= ?1")
    @Query("@position_serverTime:[$sDate $eDate]")
    List<PosData> findByServerTimeRange(@Param("sDate") long sDate, @Param("eDate") long eDate);

    @Query("@position_deviceTime:[$startTime $endTime]")
    List<PosData> findByPosition_DeviceTimeRange(@Param("sDate") long startTime, @Param("eDate") long endTime);

    @Query("@position_protocol:{$protocol}")
    List<PosData> findByPos_Protocol(String protocol);

    //@Query("@position_business_device_id:[$id $tid]")

    //List<PosData> findByPosition_Protocol(String protocol);

    @Query("@position_obtype:{$obtype}")
    List<PosData> findByPosition_ob(String obtype);

    @Query("@position_id:[$id $tid]")
    List<PosData> findbyIdRange(long id, long tid);

    @Query("@position_serverTime:[$hourAgoTime $currentTime]")
    Optional<PosData> findByServerTimeLastHour(long hourAgoTime, long currentTime);


    //@Query("SELECT pd FROM PosData pd WHERE pd.position.fixTime >= ?1 and pd.position.fixTime <= ?2")
    List<PosData> findByServerTimeRange(Timestamp startTime, Timestamp endTime);

    //"FT.SEARCH" "com.om.jsonredis.entity.PosDataIdx" "@position_deviceId:[15 15]" "LIMIT" "0" "10000"

    // Method that will retrieve data between time
    List<PosData> findByPosition_DeviceTime(Timestamp deviceTime);


    // Find The record which are near the given location

    // Custom query to find people near a location within a specified distance
    @Query("GEOSEARCH posdata_position :lon :lat :distance m")
    Iterable<PosData> findNearbyPostition(@Param("lat") double lat,
                                      @Param("lon") double lon,
                                      @Param("distance") double distance);

}
