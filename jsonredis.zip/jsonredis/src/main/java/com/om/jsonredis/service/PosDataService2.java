package com.om.jsonredis.service;

import com.om.jsonredis.entity.PosData;
import com.om.jsonredis.repository.PosDataRepository;
import com.redis.om.spring.search.stream.EntityStream;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;


@Service
public class PosDataService2 {
    @Autowired
    PosDataRepository posdataRepository;

    @Autowired
    EntityStream entityStream;


    public Iterable<PosData> findIgnition(String jsonData) throws ParseException {
        JSONObject jData = new JSONObject(jsonData);
        long id = jData.getLong("id");
        String startDate = jData.getString("startDate");
        String endDate = jData.getString("endDate");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormat2.setTimeZone(TimeZone.getTimeZone("UTC"));
        try {
            // Parse the input string to a Date object
            Date startParsedDate = dateFormat.parse(startDate);
            System.out.println("Date Format " + startParsedDate);
            long prevTime = startParsedDate.getTime();
            System.out.println("millisecond " + prevTime);

            Date endParsedDate = dateFormat2.parse(endDate);
            System.out.println("Date Format " + endParsedDate);
            long currentTime = endParsedDate.getTime();
            System.out.println("millisecond " + currentTime);
           // aggregationStream.aggregate()
       /*return entityStream
                .of(PosData.class)
                .filter(PosData$.POSITION_DEVICE_ID.eq(id))

               //.filter(PosData$.POSITION_PERMIT_TIMESTAMP)
               //.filter(PosData$.POSITION)
                /*.collect(Collectors.toList());*/

       /* long currentTime = 1705561200000L; //System.currentTimeMillis();
        long hourAgoTime = 1705557600000L;   //(System.currentTimeMillis() - 7200000);*/
            long tid = id;

            List<PosData> posData = posdataRepository.findIgnition(id, tid, prevTime, currentTime);
            System.out.println("\nSize " + posData.size());

            int onCount = 0;
            int offCount = 0;
            boolean prevIgnState = false;
            boolean curIgnState = false;
            for (PosData data : posData) {

                System.out.println("------------------------------Data_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-\n" + data);
                if (data.getPosition().getIgnition() == 1) {
                    // Ignition is 1, device is on
                    curIgnState = true;
                    if (curIgnState != prevIgnState) {
                        onCount++;
                    }
                    System.out.println("\nOnCount with One" + onCount);
                } else if (data.getPosition().getIgnition() == 2) {
                    // Ignition is 2, device is off
                    curIgnState = false;
                    if (curIgnState != prevIgnState || offCount == 0) {
                        offCount++;
                    }
                    System.out.println("\nOffCount with two" + offCount);
                } else if (data.getPosition().getIgnition() == 0) {
                    // Ignition is 0, check ignition_on and ignition_off in attributes
                    if (data.getPosition().getAttributes().isIgnition() || "yes".equalsIgnoreCase(data.getPosition().getAttributes().getIgnition_on())) {
                        // Ignition_on is "yes", device is on
                        curIgnState = true;
                        if (curIgnState != prevIgnState) {
                            onCount++;
                        }
                        System.out.println("\nOnCount with Zero" + onCount);
                    } else if (!data.getPosition().getAttributes().isIgnition() || "no".equalsIgnoreCase(data.getPosition().getAttributes().getIgnition_off())) {
                        // Ignition_off is "no", device is off
                        curIgnState = false;
                        if (curIgnState != prevIgnState || offCount == 0) {
                            offCount++;
                        }
                        System.out.println("\nOffCount with Zero" + offCount);
                    }
                }
                prevIgnState = curIgnState;
            }

            System.out.println("Device turned on " + onCount + " times");
            System.out.println("Device turned off " + offCount + " times");

            //AggregationBuilder aggregationBuilder =


            return posData;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }


}
