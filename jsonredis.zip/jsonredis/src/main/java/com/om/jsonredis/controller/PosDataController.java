package com.om.jsonredis.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.om.jsonredis.entity.PosData;
import com.om.jsonredis.repository.PosDataRepository;
import com.om.jsonredis.repository.PositionRepository;
import com.om.jsonredis.service.PosDataService;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("data")
public class PosDataController {
    @Autowired
    PosDataRepository posdataRepository;

    @Autowired
    PositionRepository positionRepository;

    @Autowired
    PosDataService posDataService;


    // Store The Data And Then Comparing It and Give Response.
    @PostMapping("save")
    public void save(@RequestBody String jsonData) throws JsonProcessingException {
        posDataService.save(jsonData);
    }

    @PostMapping("saveHash")
    public void saveHash(@RequestBody String jsonData) throws JsonProcessingException {
        posDataService.saveHash(jsonData);
    }

    @PostMapping("scheduledMethod")
    public void scheduledMethod() throws JsonProcessingException {
        posDataService.scheduledMethod();
    }

    @GetMapping("/getall")
    public Iterable<PosData> getAll() {
        //System.out.println("HEll");

        return posdataRepository.findAll();
    }

    //Find Between in the Fix Time
    @PostMapping("fixTime")
    public List<PosData> findByFixTimeRange(@RequestBody String jsonData) throws JsonProcessingException, ParseException {
        return posDataService.findByFixTimeRange(jsonData);
    }

    //Find Between in the Server Time
    @PostMapping("serverTime")
    public List<PosData> findServerTimeRange(@RequestBody String jsonData) throws JsonProcessingException, ParseException {
        return posDataService.findServerTimeRange(jsonData);
    }

    @PostMapping("deviceTime")
    public List<PosData> findDeviceTimeRange(@RequestBody String jsonData) throws JsonProcessingException, ParseException {
        return posDataService.findDeviceTimeRange(jsonData);
    }

    @GetMapping("hourServerTime")
    public Optional<PosData> findPosServerLastHour() {
        return posDataService.findPosServerLastHour();
    }

    // Working
    @GetMapping("deviceId")
    public Iterable<PosData> findByDeviceId(@RequestParam long id) {
        return posDataService.findByPosition_DeviceId(id);
    }


    @PostMapping("fixTime1")
    public String getDataByDeviceTimeRange(@RequestBody String posData) throws ParseException {
        JSONObject jsonData = new JSONObject(posData);
        String startTime = jsonData.getString("start");
        String endTime = jsonData.getString("end");
        SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date lFromDate1 = datetimeFormatter1.parse(startTime);
        Date lFromDate2 = datetimeFormatter1.parse(endTime);
        System.out.println("gpsdate :" + lFromDate1);
        Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
        Timestamp fromTS2 = new Timestamp(lFromDate2.getTime());
        System.out.println("\n\n\nThe Start Time" + fromTS1);
        System.out.println("\nThe End Time" + fromTS2);
        System.out.println("The time interval");
        return null;
    }


    @GetMapping("nrLoc")
    Iterable<PosData> findNearbyPeople(@RequestParam("lat") double lat,
                                       @RequestParam("lon") double lon,
                                       @RequestParam("distance") double distance) {
        return posdataRepository.findNearbyPostition(lat, lon, distance);
    }

    @GetMapping("/devicet")
    public void getDeviceTime(@RequestParam Timestamp deviceT) {

        System.out.println("The DeviceTime" + posdataRepository.findByPosition_DeviceTime(deviceT));

    }

    @DeleteMapping("delAll")
    public void delAll() {
        posdataRepository.deleteAll();
    }
}
