package com.om.jsonredis.repository;

import com.om.jsonredis.entity.DeviceConfig;
import com.redis.om.spring.annotations.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;

import java.util.List;

@Repository
public interface DeviceConfigRepository extends CrudRepository<DeviceConfig, String> {
    //DeviceConfig findByDeviceId(String deviceId);


    @Query("@myDateTime:[$sDate $eDate]")
    List<DeviceConfig> findByMyDateTimeBetween(@Param("sDate") Long sDate, @Param("eDate") Long eDate);


}
