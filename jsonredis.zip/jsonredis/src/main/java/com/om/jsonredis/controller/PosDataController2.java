package com.om.jsonredis.controller;


import com.om.jsonredis.entity.PosData;
import com.om.jsonredis.service.PosDataService2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.search.aggr.*;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import static redis.clients.jedis.search.aggr.Reducers.count_distinct;


@RestController
@RequestMapping("agg")
public class PosDataController2 {
    @Autowired
    PosDataService2 posDataService;

 /*   @Autowired
    UnifiedJedis jedis;*/


    @PostMapping("ignition")
    public Iterable<PosData> getIgnition(@RequestBody String jsonData) throws ParseException {
        return posDataService.findIgnition(jsonData);
    }

    @GetMapping("test")
    public String aggDemo() {
        try (UnifiedJedis jedis = new UnifiedJedis("redis://localhost:6379")) {
            AggregationBuilder aggregationBuilder = new AggregationBuilder();
            aggregationBuilder.groupBy("@position_id", count_distinct("@position_id").as("Device_Id"));

            AggregationResult aggregationResult
                    = jedis.ftAggregate("com.om.jsonredis.entity.PosDataIdx", aggregationBuilder);

            System.out.println("\nAggregation :\n" + aggregationResult);
            /*
            // Extract information from AggregationResult
            String resultSummary = String.format("Total devices: %d", aggregationResult.getCountDistinct("Device_Id"));
            System.out.println(resultSummary);*/


            // Assuming the result is a Map<String, Object>
            List<Map<String, Object>> resultAsMap = aggregationResult.getResults();
            long noOfRec = aggregationResult.getTotalResults();
            System.out.println("Total Results" + noOfRec);
            System.out.println("Aggregation Rows \n" + aggregationResult.getRows());

            // Iterate over the entries and print them
            for (Map<String, Object> entry : resultAsMap) {
                for (Map.Entry<String, Object> field : entry.entrySet()) {
                    System.out.println(field.getKey() + ": " + field.getValue());
                }
                System.out.println("----");  // Add a separator between entries if needed
            }

            return "Redis !!!";
        } catch (Exception e) {
            e.printStackTrace();
            return "No Connection of Jedis";
        }
    }

    @GetMapping("ignCount")
    public void ignCount() {
        // Sorting the data by time to ensure the order for state change detection
//            aggregationBuilder.sortBy(SortedField.asc("@deviceTime"));

        AggregationBuilder aggregationBuilder = new AggregationBuilder();
        aggregationBuilder.groupBy("@position_business_device_id", Reducers.count_distinct("@position_id").as("Device_Id"));
        aggregationBuilder.groupBy("@business_device_id");

        // aggregationBuilder.filter("1705495680000< @position_fixTime < 1705675680000]");
//            aggregationBuilder.groupBy("@position_id", Reducers.count_distinct("@position_id").as("Device_Id"));

        try (UnifiedJedis jedis = new UnifiedJedis("redis://localhost:6379")) {

         /*   AggregationBuilder aggregationBuilder = new AggregationBuilder();
            Group group = new Group("@position_business_device_id")
                    .reduce(Reducers.count_distinct("@position_id").as("Device_Id"))
                    .reduce(Reducers.to_list("@position_speed"));*/

            // aggregationBuilder.groupBy(group).sortBy(desc("@Total_Count"));
            //aggregationBuilder.groupBy(group);
            // Perform the aggregation and retrieve the results
            AggregationResult aggregationResult = jedis.ftAggregate("com.om.jsonredis.entity.PosDataIdx", aggregationBuilder);

            // Extract and print the results
       /*     List<Map<String, Object>> resultAsMap = aggregationResult.getResults();
            for (Map<String, Object> entry : resultAsMap) {
                for (Map.Entry<String, Object> field : entry.entrySet()) {
                    System.out.println(field.getKey() + ": " + field.getValue());
                }
                System.out.println("----");  // Add a separator between entries if needed
            }
*/
            System.out.println(aggregationResult.getRows());

            // Determine whether the vehicle is predominantly "On" or "Off" based on counts

            //AggregationResult aggregationResult = jedis.ftAggregate("com.om.jsonredis.entity.PosDataIdx", aggregationBuilder);

            System.out.println("\nAggregation Results:\n" + aggregationResult.getRows());
        } catch (Exception e) {
            // Handle exceptions
            e.printStackTrace();
        }

    }

    @GetMapping("eval")
    public void luaScript() {

        try (UnifiedJedis jedis = new UnifiedJedis("redis://localhost:6379")) {
//Execute sum aggregation query
            String sumScript = "local sum = 0 " +
                    "for i, v in ipairs(ARGV) do " +
                    "  sum = sum + tonumber(v) " +
                    "end " +
                    "return sum";

            String countScript = "return #ARGV";

            String averageScript = "local sum = 0 " +
                    "for i, v in ipairs(ARGV) do " +
                    "  sum = sum + tonumber(v) " +
                    "end " +
                    "local count = #ARGV " +
                    "return sum / count";

            String[] values = {"10", "20", "20"};

            Long sum = (Long) jedis.eval(sumScript, 0, values);
            System.out.println("Sum: " + sum);

            Long count = (Long) jedis.eval(countScript, 0, values);
            System.out.println("Count: " + count);

            Long average = (Long) jedis.eval(averageScript, 0, values);
            System.out.println("Average: " + average);


        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @GetMapping("demo")
    public void demo() {
        AggregationBuilder aggregationBuilder = new AggregationBuilder();

// Filter by time if needed
        //aggregationBuilder.filter("");


// Use multiple filter statements to categorize the ignition state
        aggregationBuilder.filter("@position_ignition == 1").load("Ignition_On");
        aggregationBuilder.filter("@position_ignition == 2").load("Ignition_Off");
        aggregationBuilder.filter("@position_ignition == 0 && (@position_attributes_ignition_on == 'yes' || @position_attributes_ignition == true)").load("Ignition_On");
        aggregationBuilder.filter("@position_ignition == 0 && (@position_attributes_ignition_off == 'yes' || @position_attributes_ignition == false)").load("Ignition_Off");

        try (UnifiedJedis jedis = new UnifiedJedis("redis://localhost:6379")) {
            AggregationResult aggregationResult = jedis.ftAggregate("com.om.jsonredis.entity.PosDataIdx", aggregationBuilder);

            //  jedis.ftAggregateIteration()
            System.out.println("\nAggregation Results:\n" + aggregationResult.getRows());
        } catch (Exception e) {
            // Handle exceptions
            e.printStackTrace();
        }
    }
}
