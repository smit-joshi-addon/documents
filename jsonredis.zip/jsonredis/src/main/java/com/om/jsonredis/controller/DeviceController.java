package com.om.jsonredis.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.om.jsonredis.entity.Device;
import com.om.jsonredis.repository.DeviceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("device")
public class DeviceController {
    @Autowired
    DeviceRepository deviceRepository;

    @PostMapping("save")
    public Device devideData(@RequestBody String jsonData) throws JsonProcessingException {

        ObjectMapper objectMapper = new ObjectMapper();
        Device device = objectMapper.readValue(jsonData, Device.class);

        System.out.println("\n\n\n Device Data" + device);

        System.out.println(deviceRepository.findAll());
        return deviceRepository.save(device);

    }

}
