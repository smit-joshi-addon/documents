package com.om.jsonredis.repository;

import com.om.jsonredis.entity.Position;
import com.redis.om.spring.repository.RedisDocumentRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface PositionRepository extends RedisDocumentRepository<Position, Long> {

}
