package com.om.jsonredis.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.redis.om.spring.annotations.Document;
import lombok.*;
import org.springframework.data.annotation.Id;
import com.redis.om.spring.annotations.Indexed;
import org.springframework.data.redis.core.TimeToLive;


//@Getter
//@Setter
//@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@RequiredArgsConstructor(staticName = "of")
//@AllArgsConstructor(access = AccessLevel.PROTECTED)
@Data
@Document(timeToLive = 20L)
public class PosData {

    @Id @Indexed
    //@GeneratedValue(strategy = org.springframework.data.redis.core.RedisKeyValueAdapter.EnableKeyspaceEvents.ON_STARTUP)
    private String Id;

    @Indexed
    private Position position;

    /*@Indexed @NonNull
    private  Device device;*/


    @TimeToLive
    private Long expiration=60L;
}
