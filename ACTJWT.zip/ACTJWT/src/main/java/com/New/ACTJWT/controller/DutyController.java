package com.New.ACTJWT.controller;

import com.New.ACTJWT.service.DutyService;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("Duty")
public class DutyController {
    @Autowired
    DutyService dutyService;

    @PostMapping("add")
    public Map<String, Object> addDuty(@RequestBody String dutyData, HttpServletRequest request) throws JSONException {
        return dutyService.addDuty(dutyData, request);
    }

    // Update Only when Active
    @PutMapping("/updateActiveById")
    public Map<String, Object> updateActiveDuty(String dutyData) throws JSONException {
        return dutyService.updateActiveDuty(dutyData);
    }

    //Get By Id Active
    @GetMapping("/getById")
    public Map<String, Object> getActiveDutyById(@RequestParam int dutyId) {
        return dutyService.getActiveDutyById(dutyId);
    }

    // Get all Staff with Deleted
    @GetMapping("/allDuty")
    public Map<String, Object> getAllDuty() {
        return dutyService.getAllDuty();
    }

    // Get all Airlines without Deleted
    @GetMapping("/allActiveDuty")
    public Map<String, Object> getAllActiveDuty() {
        return dutyService.getAllActiveDuty();
    }

    // Get all Airlines without Deleted
    @GetMapping("/allDeleteDuty")
    public Map<String, Object> getAllDeletedDuty() {
        return dutyService.getAllDeletedDuty();
    }

    //Pagination Get all Vehicles with Deleted
    // If With Path Variable  @GetMapping("/allDutyPagination" or "/allDutyPagination/{page}...)
    @GetMapping("/allActiveDutyPagination")
    public Map<String, Object> getAllActiveDutyPagination(@RequestParam(defaultValue = "0") int page,
                                                           @RequestParam(defaultValue = "5") int size,
                                                           @RequestParam(defaultValue = "dutyId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).descending());
        return dutyService.getAllActiveDutyPagination(pageable);
    }

    @GetMapping("/allDeleteDutyPagination")
    public Map<String, Object> getAllDeletedDutyPagination(@RequestParam(defaultValue = "0") int page,
                                                           @RequestParam(defaultValue = "5") int size,
                                                           @RequestParam(defaultValue = "dutyDate") String sortBy) {
        return dutyService.getAllDeletedDutyPagination(page, size, sortBy);
    }

    @GetMapping("/allDutyPagination")
    public Map<String, Object> getAllDutyPagination(@RequestParam(defaultValue = "0") int page,
                                                       @RequestParam(defaultValue = "5") int size,
                                                       @RequestParam(defaultValue = "dutyId") String sort) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sort).descending());
        return dutyService.getAllDutyPagination(pageable);
    }


    //Soft Delete Through Method
    @DeleteMapping("/deleteById")
    public Map<String, Object> deleteDutyById(@RequestParam int dutyId) {
        return dutyService.deleteDutyById(dutyId);
    }

    //Hard Delete Through Method
    @DeleteMapping("/deleteHard")
    public Map<String, Object> delDutyHard(@RequestParam int dutyId) {
        return dutyService.delDutyHard(dutyId);
    }

    //Revert Through Method
    @PutMapping("/revertById")
    public Map<String, Object> revertDuty(@RequestParam int dutyId) {
        return dutyService.revertDuty(dutyId);
    }
}
