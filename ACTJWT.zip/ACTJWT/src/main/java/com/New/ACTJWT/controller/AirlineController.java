package com.New.ACTJWT.controller;

import com.New.ACTJWT.Repository.AirlineRepository;
import com.New.ACTJWT.model.Airline;
import com.New.ACTJWT.service.AirlineService;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


@RestController

@RequestMapping("airlines")
public class AirlineController {
    @Autowired
    AirlineService airlineService;

    @Autowired
    AirlineRepository airlineRepository;

    //Insert
    @PostMapping("/add")
    public Map<String, Object> addAirline(@RequestBody String airlineData, HttpServletRequest request) throws JSONException {
        return airlineService.addAirline(airlineData, request);
    }

    /*http://localhost:8080/airlines/getById?alId=1*/
    @GetMapping("getById")
    public Map<String, Object> getAirlineByID(@RequestParam(name = "alId") int alId) {
        return airlineService.getAirlineById(alId);
    }

    // Only Get WHen Id Is Active
    @GetMapping("Auto/getByActiveAirlineId")
    public Map<String, Object> findByIsActiveTrueAndAirlineId(@RequestParam int airlineId) {
        return airlineService.findByIsActiveTrueAndAirlineId(airlineId);
    }

    // Fetch data for the deleted record through methods
    /*@GetMapping("/getsoftd")
    public List<Airline> getDeletedRecords(){
        return alService.getDeletedRecords();
    }*/

    // Through Query records that are deleted
    @GetMapping("JPQL/getSoftDel")
    public Map<String, Object> getDeletedRecords() {
        return airlineService.getDeletedRecords();
    }

    // Through Query records that are deleted Native
    @GetMapping("Native/getSoftDel")
    public Map<String, Object> getDeletedRecordsNative() {
        return airlineService.getDeletedRecordsNative();
    }


    @GetMapping("JPQL/getActRec")
    public Map<String, Object> getActiveAirline() {
        return airlineService.getActiveAirlines();
    }

    @GetMapping("Native/getActRec")
    public Map<String, Object> getActiveAirlineNative() {
        return airlineService.getActiveAirlinesNative();
    }

    // Get all Airlines with Deleted
    @GetMapping("/allAirlines")
    public Map<String, Object> getAllAirlines() {
        return airlineService.getAllAirlines();
    }

    //Pagination Get all Airlines with Deleted
    // If With Path Variable  @GetMapping("/allAirlinesPagination" or "/allAirlinesPagination/{page}...)
    @GetMapping("/allAirlinesPagination")
    public Map<String, Object> getAllAirlinesPagination(@RequestParam(defaultValue = "0") int page,
                                                        @RequestParam(defaultValue = "5") int size,
                                                        @RequestParam(defaultValue = "airlineId") String sortBy) {
        return airlineService.getAllAirlinesPagination(page,size,sortBy);
    }

    @PutMapping("/update")
    //public Airline updateAirline(@RequestParam(name = "alId") Integer alId, @RequestBody Airline airline)
    public Map<String, Object> updateAirline(@RequestBody String airlineData) throws JSONException {
        return airlineService.updateAirline(airlineData);
    }

    // Update Only when Active
    @PutMapping("/updateActive")
    public Map<String, Object> updateActiveAirline(String airlineData) throws JSONException {
        return airlineService.updateActiveAirline(airlineData);
    }

    //Revert Through Query
    @PutMapping("/revert")
    //public String revertRecord(@PathVariable Integer alId)
    public String revertRecord(@RequestBody int alId) {
        airlineService.revertById(alId);
        return "Record Is Activated.";
    }

    // Revert Through NativeQuery
    @PutMapping("/revertN/{alId}")
    public String revertRecordN(@PathVariable int alId) {
        airlineService.revertByIdN(alId);
        return "Record Is Activated.";
    }

    //Revert Through Method
    @PutMapping("/revertM")
    public Map<String, Object> revertAirline(@RequestParam int alId) {
        return airlineService.revertAirline(alId);
    }

    //Soft Delete
    @DeleteMapping("softDel/{alId}")
    public Map<String, Object> delAirlineByID(@PathVariable int alId) {
        return airlineService.delAirlineById(alId);
    }

    //Soft Delete Only Active Record Method
    @DeleteMapping("softDelActive/{alId}")
    public Map<String, Object> delActiveAirlineByID(@PathVariable int alId) {
        return airlineService.delActiveAirlineById(alId);
    }

    //HARD DELETE
    @DeleteMapping("hardDel/{alId}")
    public Map<String, Object> delAirlineHard(@PathVariable int alId) {
        return airlineService.delAirlineHard(alId);
    }

    @DeleteMapping("delete/all")
    public String delALlAirlines() {
        return airlineService.delAllAirlines();
    }

    @GetMapping("Auto/getByAirportRegionNull")
    public List<Airline> getAirlineByAirportRegionNull() {
        return airlineRepository.findByAirport_AirportRegionIsNull();
    }

    @GetMapping("Auto/byId")
    public Map<String, Object> getAirlineByIdAuto(@RequestParam int alId) {
        return airlineService.getAirlineByIdAuto(alId);
    }

    //http://localhost:8080/airlines/JPQL/byId/3
    @GetMapping("JPQL/byId/{alId}")
    public Map<String, Object> getAirlineByIdJPQL(@PathVariable int alId) {
        return airlineService.getAirlineByIdJPQL(alId);
    }

    //http://localhost:8080/airlines/Native/byId   raw
    @GetMapping("Native/byId")
    public Map<String, Object> getAirlineByIdNative(@RequestBody int alId) {
        return airlineService.getAirlineByIdNative(alId);
    }

    @GetMapping("Auto/getByName")
    public Map<String, Object> findByAirlineName(@RequestParam String name) {
        return airlineService.findByAirlineName(name);
    }

    @GetMapping("Native/getByName")
    public Map<String, Object> findByAirlineNameNative(@RequestParam String name) {
        return airlineService.getAirlineByNameNative(name);
    }

    @GetMapping("JPQl/getByName")
    public Map<String, Object> findByAirlineNameJPQL(@RequestParam String name) {
        return airlineService.getAirlineByNameJPQL(name);
    }

    @GetMapping("Auto/getByAddress")
    public Map<String, Object> findByAirlineAddress(@PathVariable String address) {
        return airlineService.findByAirlineAddress(address);
    }

    @GetMapping("Native/getByAddress")
    public Map<String, Object> findByAirlineAddressNative(@PathVariable String address) {
        return airlineService.findByAirlineAddressNative(address);
    }

    @GetMapping("JPQl/getByAddress")
    public Map<String, Object> findByAirlineAddressJPQL(@PathVariable String address) {
        return airlineService.findByAirlineAddressJPQL(address);
    }


    @GetMapping("Auto/getByMob")
    public Map<String, Object> findByAirlineMobAuto(@RequestParam String mobNum) {
        return airlineService.findByMobileNumAuto(mobNum);
    }

    @GetMapping("JPQL/getByMob")
    public Map<String, Object> findByAirlineMobJPQL(@RequestParam String mobNum) {
        return airlineService.findByMobileNumJPQL(mobNum);
    }

    @GetMapping("Native/getByMob")
    public Map<String, Object> findByAirlineMobNative(@RequestParam String mobNum) {
        return airlineService.findByMobileNumNative(mobNum);
    }

    @GetMapping("JPQL/getByEmail")
    public Map<String, Object> findByAirlineEmailJPQL(@RequestParam String email) {
        return airlineService.findByEmailJPQL(email);
    }

    @GetMapping("Native/getByEmail")
    public Map<String, Object> findByAirlineEmailNative(@RequestParam String email) {
        return airlineService.findByEmailNative(email);
    }

    @GetMapping("Auto/getByNameAndAirportId")
    public Map<String, Object> findByAirlineNameAndAirportId(@RequestParam String name, int id) {
        return airlineService.findByAirlineNameAndAirportId(name, id);
    }

    @GetMapping("JPQL/getByNameAndAirportId")
    public Map<String, Object> findByAirlineNameAndAirportIdJPQL(@RequestParam String name, int id) {
        return airlineService.findByAirlineNameAndAirportIdJPQL(name, id);
    }

    @GetMapping("Native/getByNameAndAirportId")
    public Map<String, Object> findByAirlineNameAndAirportIdNative(@RequestParam String name, int id) {
        return airlineService.findByAirlineNameAndAirportIdNative(name, id);
    }


    /*@GetMapping("Auto/getByDistinctName")
    public Map<String, Object> findByAirlineNameAndAirportId() {
        return airlineService.findByDistinctAirlineName();
    }*/
    @GetMapping("Auto/getByNameAndAirportCountry")
    public Map<String, Object> findByAirlineNameContainingAndAirport_AirportCountry(@RequestParam String name, String country) {
        return airlineService.findByAirlineNameAndAirport_AirportCountry(name, country);
    }

    @GetMapping("Native/getProjection")
    public List<Map<String, Object>> getJoinResult() {
        return airlineService.getJoinResult();
    }

    @GetMapping("Native/getProjectionAndJoin")
    public List<Map<String, Object>> getProjectionAndJoin(@RequestParam int airlineId) {
        return airlineService.projectionAndJoin(airlineId);
    }

    @GetMapping("/page")
    public Page<Airline> findByIsDeleteTrue(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "3") int size,
            @RequestParam(defaultValue = "airlineId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).descending().and(Sort.by("airport.airportId")));
        // airlineRepository.findAll(pageable);
        return airlineRepository.findByIsDeleteTrue(pageable);
        // airlineService.findByIsDeleteTrue(page, size);
    }

}
