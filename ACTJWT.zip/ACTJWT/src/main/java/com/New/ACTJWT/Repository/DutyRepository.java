package com.New.ACTJWT.Repository;

import com.New.ACTJWT.model.Duty;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DutyRepository extends JpaRepository<Duty, Integer> {
    @Query(value = "SELECT * FROM duty d where d.is_delete= false and d.is_active= true and duty_id = :dutyId",nativeQuery = true)
    Optional<Duty> findActiveDutyById(int dutyId);

    //Fetch the record that are deleted
    List<Duty> findByIsDeleteTrue();

    //Through query
    @Query("select d from Duty d where d.isDelete= true and d.isActive=false")
    List<Duty> findAllDeletedDuty();

    @Query("select d from Duty d where d.isDelete= true and d.isActive=false")
    Page<Duty> findAllDeletedDutyPagination(Pageable pageable);

    // Get the record that are not deleted.
    @Query("select d from Duty d where d.isDelete=false and d.isActive=true")
    List<Duty> findAllActiveDuty();
    @Query("select d from Duty d where d.isDelete=false and d.isActive=true")
    Page<Duty> findAllActiveDutyPagination(Pageable pageable);

    @Modifying
    @Query("update Duty d set d.isActive=true, d.isDelete = false where d.isDelete = true and d.dutyId =:dutyId")
    public void revert(@Param("dutyId") int dutyId);

    @Modifying
    @Query(value ="update Duty set is_active = true , is_delete=false where is_delete = true and duty_id = :dutyId", nativeQuery = true)
    public void revertN(@Param("dutyId") int dutyId);
}
