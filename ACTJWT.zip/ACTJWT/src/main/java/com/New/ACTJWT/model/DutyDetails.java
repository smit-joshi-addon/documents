package com.New.ACTJWT.model;

import jakarta.persistence.*;
import lombok.*;

import java.sql.Timestamp;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "duty_details")
public class DutyDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "duty_details_id")
    private int dutyDetailsId;
    @Column(name = "description")
    private String description;
    @Column(name = "distance")
    private double distance;
    @Column(name = "address")
    private String address;
    @Column(name = "act_pickup_time")
    private Timestamp actPickupTime;
    @Column(name = "staff_status")
    private String staffStatus;
    @Column(name = "driver_name")
    private String driverName;
    @Column(name = "duty_type")
    private String dutyType;
    @Column(name = "d_d_name")
    private String dDName;
    @Column(name = "mobile_num")
    private String mobileNum;


    //Common Columns
    @Column(name = "creation_time")
    private Timestamp creationTime;
    @Column(name = "deletion_time")
    private Timestamp deletionTime;
    @Column(name = "is_active")
    private boolean isActive;
    @Column(name = "is_delete")
    private boolean isDelete;
    @Column(name = "ip_address")
    private String ipAddress;


    @ManyToOne
    @JoinColumn(name = "driver_id")
    private Driver driver;
    @OneToOne
    @JoinColumn(name = "staff_id")
    private Staff staff;
    @ManyToOne
    @JoinColumn(name = "duty_id")
    private Duty duty;

}
