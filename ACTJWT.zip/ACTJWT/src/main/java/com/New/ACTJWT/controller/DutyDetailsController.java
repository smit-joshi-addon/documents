package com.New.ACTJWT.controller;


import com.New.ACTJWT.service.DutyDetailsService;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("dutyDetails")
public class DutyDetailsController {
    @Autowired
    DutyDetailsService dutyDetailsService;

    @PostMapping("add")
    public Map<String, Object> addDutyDetails(@RequestBody String dutyDetailsData, HttpServletRequest request) throws JSONException {
        return dutyDetailsService.addDutyDetails(dutyDetailsData, request);
    }

    // Update Only when Active
    @PutMapping("/updateActiveById")
    public Map<String, Object> updateActiveDutyDetails(String dutyDetailsData) throws JSONException {
        return dutyDetailsService.updateActiveDutyDetails(dutyDetailsData);
    }

    //Get By Id Active
    @GetMapping("/getById")
    public Map<String, Object> getActiveDutyDetailsById(@RequestParam int dutyDetailsId) {
        return dutyDetailsService.getActiveDutyDetailsById(dutyDetailsId);
    }

    // Get all Staff with Deleted
    @GetMapping("/allDutyDetails")
    public Map<String, Object> getAllDutyDetails() {
        return dutyDetailsService.getAllDutyDetails();
    }

    // Get all Airlines without Deleted
    @GetMapping("/allActiveDutyDetails")
    public Map<String, Object> getAllActiveDutyDetails() {
        return dutyDetailsService.getAllActiveDutyDetails();
    }

    // Get all Duty Details without Deleted
    @GetMapping("/allDeleteDutyDetails")
    public Map<String, Object> getAllDeletedDutyDetails() {
        return dutyDetailsService.getAllDeletedDutyDetails();
    }

    //Pagination Get all Duty Details with Deleted
    // If With Path Variable  @GetMapping("/alldutyDetailsPagination" or "/alldutyDetailsPagination/{page}...)
    @GetMapping("/allActiveDutyDetailsPagination")
    public Map<String, Object> getAllActiveDutyDetailsPagination(@RequestParam(defaultValue = "0") int page,
                                                                 @RequestParam(defaultValue = "5") int size,
                                                                 @RequestParam(defaultValue = "dutyDetailsId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).descending());
        return dutyDetailsService.getAllActiveDutyDetailsPagination(pageable);
    }

    @GetMapping("/allDeleteDutyDetailsPagination")
    public Map<String, Object> getAllDeletedDutyDetailsPagination(@RequestParam(defaultValue = "0") int page,
                                                                  @RequestParam(defaultValue = "5") int size,
                                                                  @RequestParam(defaultValue = "dutyDetailsDate") String sortBy) {
        return dutyDetailsService.getAllDeletedDutyDetailsPagination(page, size, sortBy);
    }

    @GetMapping("/allDutyDetailsPagination")
    public Map<String, Object> getAllDutyDetailsPagination(@RequestParam(defaultValue = "0") int page,
                                                           @RequestParam(defaultValue = "5") int size,
                                                           @RequestParam(defaultValue = "dutyDetailsId") String sort) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sort).descending());
        return dutyDetailsService.getAllDutyDetailsPagination(pageable);
    }


    //Soft Delete Through Method
    @DeleteMapping("/deleteById")
    public Map<String, Object> deleteDutyDetailsById(@RequestParam int dutyDetailsId) {
        return dutyDetailsService.deleteDutyDetailsById(dutyDetailsId);
    }

    //Hard Delete Through Method
    @DeleteMapping("/deleteHard")
    public Map<String, Object> delDutyDetailsHard(@RequestParam int dutyDetailsId) {
        return dutyDetailsService.delDutyDetailsHard(dutyDetailsId);
    }

    //Revert Through Method
    @PutMapping("/revertById")
    public Map<String, Object> revertDutyDetailsById(@RequestParam int dutyDetailsId) {
        return dutyDetailsService.revertDutyDetailsById(dutyDetailsId);
    }
}
