package com.New.ACTJWT.model;


import jakarta.persistence.*;
import lombok.*;

import java.sql.Timestamp;

@Getter
@Setter
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="airport")
public class Airport {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name= "airport_id")
    private int airportId;
    @Column(name = "iata_code")
    private String IATACode;
    @Column(name = "airport_address")
    private String airportAddress;
    @Column(name = "airport_country")
    private String airportCountry;
    @Column(name = "airport_region")
    private String airportRegion;
    /*@Column(name = "ap_location")
    private Point apLocation;*/

    // Common Column
    @Column(name ="creation_time")
    private Timestamp creationTime;
    @Column(name ="deletion_time")
    private Timestamp deletionTime;
    @Column(name = "is_active")
    private boolean isActive;
    @Column(name = "is_delete")
    private boolean isDelete;
    @Column(name ="ip_address")
    private String ipAddress;

}
