package com.New.ACTJWT.service;


import com.New.ACTJWT.model.User;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class UserService<Lis> {
    private List<User> usersList = new ArrayList<>();

    public UserService() {
        usersList.add(new User(UUID.randomUUID().toString(), "Krishna", "k@gmail.com"));
        usersList.add(new User(UUID.randomUUID().toString(), "Admin", "admin@gmail.com"));
        usersList.add(new User(UUID.randomUUID().toString(), "Guest", "guest@gmail.com"));
    }

    public List<User> getUsers() {
        return this.usersList;
    }

}
