package com.New.ACTJWT.controller;

import com.New.ACTJWT.service.BranchService;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("branches")
public class BranchController {
    @Autowired
    BranchService branchService;

    //Insert
    @PostMapping("/add")
    public Map<String, Object> addBranch(@RequestBody String branchData, HttpServletRequest request) throws JSONException {
        return branchService.addBranch(branchData, request);
    }

    //Update the Branch
    @PutMapping("/update")
    public Map<String ,Object> updateBranchById(@RequestBody String branchData) throws JSONException {
        return branchService.updateBranchById(branchData);
    }
    //pass data in the form-data
    @PutMapping("/updateByParam")
    public Map<String ,Object> updateBranchByIdParam(@RequestParam String branchData) throws JSONException {
        return branchService.updateBranchById(branchData);
    }

    //Get Method
    @GetMapping("/getBranch")
    public Map<String, Object> getBranchById(@RequestParam int brId) {
        return branchService.getBranchById(brId);
    }

    //Get Method
    @GetMapping("/getActiveBranchById")
    public Map<String, Object> getActiveBranchById(@RequestParam int brId) {
        return branchService.getActiveBranchById(brId);
    }

    // Get Deleted Record Only
    @GetMapping("delBranches")
    public Map<String, Object> getDeletedBranches() {
        return branchService.getDeletedBranches();
    }

    // Get Deleted Record Only with Pagination
    @GetMapping("delBranchesPagination")
    public Map<String, Object> getDeletedBranchesPagination(@RequestParam(defaultValue = "0") int page,
                                                            @RequestParam(defaultValue = "5") int size,
                                                            @RequestParam(defaultValue = "branchId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).descending().and(Sort.by("branchCountry")));
        return branchService.getDeletedBranchesPagination(pageable);
    }

    // Get Active Record Only
    @GetMapping("activeBranches")
    public Map<String, Object> getActiveBranches() {
        return branchService.getActiveBranches();
    }

    @GetMapping("activeBranchesPagination")
    public Map<String, Object> getActiveBranchesPagination(@RequestParam(defaultValue = "0") int page,
                                                           @RequestParam(defaultValue = "5") int size,
                                                           @RequestParam(defaultValue = "branchId") String sortBy) {
        return branchService.getActiveBranchesPagination(page, size, sortBy);
    }


    @GetMapping("/getAllBranches")
    public Map<String, Object> getAllBranches() {
        return branchService.getAllBranches();
    }

    @GetMapping("allBranchesPagination")
    public Map<String, Object> getAllBranchesPagination(@RequestParam(defaultValue = "0") int page,
                                                        @RequestParam(defaultValue = "5") int size,
                                                        @RequestParam(defaultValue = "branchId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).descending().and(Sort.by("branchCode")));
        return branchService.getAllBranchesPagination(pageable);
    }

    // Soft Delete
    @DeleteMapping("delete/{branchId}")
    public Map<String,Object> delBranchById(@PathVariable int branchId) {
        return branchService.delBranchById(branchId);
    }

    //Hard Delete
    @DeleteMapping("/{branchId}")
    public Map<String,Object> delBranchHardById(@PathVariable int branchId){
        return branchService.delBranchHardById(branchId);
    }

    //Revert
    @PutMapping("revert/{branchId}")
    public Map<String,Object> revertBranchById(@PathVariable int branchId){
        return branchService.revertBranchById(branchId);
    }
}
