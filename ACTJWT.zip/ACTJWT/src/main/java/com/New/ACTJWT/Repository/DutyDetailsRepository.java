package com.New.ACTJWT.Repository;

import com.New.ACTJWT.model.DutyDetails;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DutyDetailsRepository extends JpaRepository<DutyDetails, Integer> {

    //Fetch the record that are deleted
    List<DutyDetails> findByIsDeleteTrue();

    @Query(value = "SELECT * FROM duty_details d where d.is_delete = false and d.is_active = true and d.duty_details_id = ?1",nativeQuery = true)
    Optional<DutyDetails> findActiveDutyDetailsById(int dutyDetailsId);

    //Through query
    @Query("select d from DutyDetails d where d.isDelete= true and d.isActive = false")
    List<DutyDetails> findAllDeletedDutyDetails();
    @Query("select d from DutyDetails d where d.isDelete= true and d.isActive = false")
    Page<DutyDetails> findAllDeletedDutyDetailsPagination(Pageable pageable);

    // Get the record that are not deleted.
    @Query("select d from DutyDetails d where d.isDelete=false and d.isActive=true")
    List<DutyDetails> findAllActiveDutyDetails();
    @Query("select d from DutyDetails d where d.isDelete=false and d.isActive=true")
    Page<DutyDetails> findAllActiveDutyDetailsPagination(Pageable pageable);


    @Modifying
    @Query("update DutyDetails a set a.isActive=true, a.isDelete = false where a.isDelete = true and a.dutyDetailsId =:dutyDetailsId")
    public void revertDutyDetails(@Param("dutyDetailsId") int dutyDetailsId);

    @Modifying
    @Query(value ="update DutyDetails set is_active = true , is_delete=false where is_delete = true and duty_details_id = :dutyDetailsId", nativeQuery = true)
    public void revertN(@Param("dutyDetailsId") int dutyDetailsId);

}
