package com.New.ACTJWT.service;

import com.New.ACTJWT.Repository.AirlineRepository;
import com.New.ACTJWT.Repository.DutyRepository;
import com.New.ACTJWT.model.Airline;
import com.New.ACTJWT.model.Duty;

import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


@Service
public class DutyService {
    @Autowired
    DutyRepository dutyRepository;

    @Autowired
    AirlineRepository airlineRepository;


    public Map<String, Object> addDuty(String dutyData, HttpServletRequest request) throws JSONException {
        JSONObject jsonData = new JSONObject(dutyData);
        Map<String, Object> m1 = new HashMap<String, Object>();
        Map<String, Object> map = new HashMap<String, Object>();

        Airline airline = null;
        int airlineId = 0;

        int totalStaff = 0;
        int relatedStaff = 0;
        String dutyName = null;
        Timestamp dutyDate;
        String stringDutyDate = null;
        String fileLocation = null;
        String fileName = null;
        boolean status = false;
        String mobileNum1 = null;
        String mobileNum2 = null;
        String email1 = null;

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Duty duty = new Duty();

        try {
            if (jsonData.has("airlineId") && jsonData.get("airlineId") != null
                    && !jsonData.get("airlineId").equals("")) {

                airlineId = jsonData.getInt("airlineId");
                Optional<Airline> existingAirlineOptional = airlineRepository.findByIsActiveTrueAndAirlineId(airlineId);
                airline = existingAirlineOptional.orElse(null);
                if (airline == null) {
                    m1.put("status", "error");
                    m1.put("error", "no_longer_available");
                    m1.put("message", "Sorry, this airline is not longer available.");
                    return m1;
                }
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field_validation");
                m1.put("message", "Please provide airline identification like airlineId.");
                return m1;
            }

            //dutyName Validation
            if (jsonData.has("dutyName") && !jsonData.get("dutyName").equals("")
                    && jsonData.get("dutyName") != null) {
                dutyName = jsonData.getString("dutyName");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide dutyName.");
                return m1;
            }

            // dutyDate Validation
            if (jsonData.has("dutyDate") && !jsonData.get("dutyDate").equals("")
                    && jsonData.get("dutyDate") != null) {
                stringDutyDate = jsonData.getString("dutyDate");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide dutyDate.");
                return m1;
            }

            // totalStaff  Validation
            if (jsonData.has("totalStaff") && !jsonData.get("totalStaff").equals("")
                    && jsonData.get("totalStaff") != null) {
                totalStaff = jsonData.getInt("totalStaff");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide totalStaff.");
                return m1;
            }
            // relatedStaff  Validation
            if (jsonData.has("relatedStaff") && !jsonData.get("relatedStaff").equals("")
                    && jsonData.get("relatedStaff") != null) {
                relatedStaff = jsonData.getInt("relatedStaff");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide relatedStaff.");
                return m1;
            }

            //fileLocation   Validation
            if (jsonData.has("fileLocation") && !jsonData.get("fileLocation").equals("")
                    && jsonData.get("fileLocation") != null) {
                fileLocation = jsonData.getString("fileLocation");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide fileLocation.");
                return m1;
            }

            if (jsonData.has("fileName") && !jsonData.get("fileName").equals("")
                    && jsonData.get("fileName") != null) {
                fileName = jsonData.getString("fileName");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide fileName.");
                return m1;
            }
            if (jsonData.has("status") && !jsonData.get("status").equals("")
                    && jsonData.get("status") != null) {
                status = jsonData.getBoolean("status");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide status.");
                return m1;
            }

            Date parsedDate = dateFormat.parse(stringDutyDate);
            dutyDate = new Timestamp(parsedDate.getTime());
            System.out.println("Timestamp: " + dutyDate);

            duty.setDutyName(dutyName);
            duty.setDutyDate(dutyDate);
            duty.setAirline(airline);
            duty.setFileLocation(fileLocation);
            duty.setFileName(fileName);
            duty.setStatus(status);
            duty.setTotalStaff(totalStaff);
            duty.setRelatedStaff(relatedStaff);
            duty.setCreationTime(new Timestamp(System.currentTimeMillis()));
            duty.setActive(true);
            duty.setDelete(false);
            String ipAddress = request.getHeader("X-FORWARDED-FOR");
            if (ipAddress == null || ipAddress.isEmpty()) {
                duty.setIpAddress(request.getRemoteAddr());
            }
            duty = dutyRepository.save(duty);

            m1.put("status", "success");
            map.put("Airline Id", duty.getAirline().getAirlineId());
            map.put("AirlineName", duty.getAirline().getAirlineName());
            map.put("AirlineAddress", duty.getAirline().getAirlineAddress());
            map.put("Airport Id", duty.getAirline().getAirport().getAirportId());
            map.put("Mobile Num1", duty.getAirline().getMobileNum1());
            map.put("Mobile Num2", duty.getAirline().getMobileNum2());
            map.put("Mobile Num3", duty.getAirline().getMobileNum3());
            map.put("Email1", duty.getAirline().getEmail1());
            map.put("Email2", duty.getAirline().getEmail2());
            m1.put("Duty Id", duty.getDutyId());
            m1.put("Duty Name", duty.getDutyName());
            m1.put("Duty Date", duty.getDutyDate());
            m1.put("Related Staff", duty.getRelatedStaff());
            m1.put("Total Staff", duty.getTotalStaff());
            m1.put("File Location", duty.getFileLocation());
            m1.put("File Name", duty.getFileName());
            m1.put("Status", duty.isStatus());
            m1.put("Airline", map);
            m1.put("message", "Duty information saved successfully!!");
            return m1;

        } catch (ParseException p) {
            p.printStackTrace();
            m1.put("status", "error");
            m1.put("error", "date_format_not_match");
            m1.put("message", "Please Enter Date in the Given Format :'yyyy-MM-dd HH:mm:ss'");
            return m1;
        } catch (Exception e) {
            e.printStackTrace();
            m1.put("status", "error");
            m1.put("error", "not_found");
            m1.put("message", "Something went wrong");
            return m1;
        }
    }

    public Map<String, Object> updateActiveDuty(String dutyData) throws JSONException {
        JSONObject jsonData = new JSONObject(dutyData);
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> propertyMap = new HashMap<>();

        Airline airline = new Airline();
        int airlineId = 0;
        Duty duty;
        int dutyId = 0;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            if (jsonData.has("dutyId") && jsonData.get("dutyId") != null
                    && !jsonData.get("dutyId").equals("")) {
                dutyId = jsonData.getInt("dutyId");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide dutyId.");
                return map;
            }
            Optional<Duty> existingDutyOptional = dutyRepository.findActiveDutyById(dutyId);
            if (existingDutyOptional.isPresent()) {
                duty = existingDutyOptional.get();
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "The Duty Does Not Exist.");
                return map;
            }

            if (!duty.getAirline().isActive() && duty.getAirline().isDelete()) {
                map.put("status", "error");
                map.put("error", "no_longer_available_airportId");
                map.put("message", "Sorry, This Airline id is not Updatable.");
                return map;
            }
            if (jsonData.has("airlineId") && jsonData.get("airlineId") != null
                    && !jsonData.get("airlineId").equals("")) {
                airlineId = jsonData.getInt("airlineId");

                Optional<Airline> existingAirlineOptional = airlineRepository.findByIsActiveTrueAndAirlineId(airlineId);
                if (existingAirlineOptional.isPresent()) {
                    airline = existingAirlineOptional.get();
                    duty.setAirline(airline);
                } else {
                    map.put("status", "error");
                    map.put("error", "no_longer_available");
                    map.put("message", "Sorry, this Airline id is not in the database.");
                    return map;
                }
            }
            if (jsonData.has("dutyName") && jsonData.get("dutyName") != null
                    && !jsonData.get("dutyName").equals("")) {
                duty.setDutyName(jsonData.getString("dutyName"));
            }
            // airline Address Update
            if (jsonData.has("dutyDate") && !jsonData.get("dutyDate").equals("")
                    && jsonData.get("dutyDate") != null) {
                String stringDutyDate = jsonData.getString("dutyDate");

                Date parsedDate = dateFormat.parse(stringDutyDate);
                Timestamp dutyDate = new Timestamp(parsedDate.getTime());
                duty.setDutyDate(dutyDate);
                System.out.println("Timestamp: " + dutyDate);
            }
            if (jsonData.has("totalStaff") && !jsonData.get("totalStaff").equals("")
                    && jsonData.get("totalStaff") != null) {
                duty.setTotalStaff(jsonData.getInt("totalStaff"));
            }
            if (jsonData.has("relatedStaff") && !jsonData.get("relatedStaff").equals("")
                    && jsonData.get("relatedStaff") != null) {
                duty.setRelatedStaff(jsonData.getInt("relatedStaff"));
            }
            //fileLocation Update
            if (jsonData.has("fileLocation") && !jsonData.get("fileLocation").equals("")
                    && jsonData.get("fileLocation") != null) {
                duty.setFileLocation(jsonData.getString("fileLocation"));
            }
            if (jsonData.has("fileName") && !jsonData.get("fileName").equals("")
                    && jsonData.get("fileName") != null) {
                duty.setFileName(jsonData.getString("fileName"));
            }

            //status Update
            if (jsonData.has("status") && !jsonData.get("status").equals("")
                    && jsonData.get("status") != null) {
                duty.setStatus(jsonData.getBoolean("status"));
            }

            duty = dutyRepository.save(duty);
            map.put("status", "success");
            map.put("message", "Duty id " + dutyId + " Update Confirmed!!!");
            // To Return duty
            propertyMap.put("Airline Id", duty.getAirline().getAirlineId());
            propertyMap.put("AirlineName", duty.getAirline().getAirlineName());
            propertyMap.put("AirlineAddress", duty.getAirline().getAirlineAddress());
            propertyMap.put("Airport Id", duty.getAirline().getAirport().getAirportId());
            propertyMap.put("MobileNum1", duty.getAirline().getMobileNum1());
            propertyMap.put("MobileNum2", duty.getAirline().getMobileNum2());
            propertyMap.put("MobileNum3", duty.getAirline().getMobileNum3());
            propertyMap.put("Email1", duty.getAirline().getEmail1());
            propertyMap.put("Email2", duty.getAirline().getEmail2());
            map.put("Duty Id", duty.getDutyId());
            map.put("Duty Name", duty.getDutyName());
            map.put("Duty Date", duty.getDutyDate());
            map.put("Related Staff", duty.getRelatedStaff());
            map.put("Total Staff", duty.getTotalStaff());
            map.put("File Location", duty.getFileLocation());
            map.put("File Name", duty.getFileName());
            map.put("Status", duty.isStatus());
            map.put("Airline", propertyMap);

        } catch (ParseException p) {
            p.printStackTrace();
            map.put("status", "error");
            map.put("error", "date_format_not_compatible");
            map.put("message", "Please provide Date in this format:'yyyy-MM-dd HH:mm:ss'");
            return map;
        } catch (JSONException e) {
            e.printStackTrace();
            map.put("status", "error");
            map.put("error", "not_found");
            map.put("message", "Something went wrong");
            return map;
        }
        return map;
    }

    public Map<String, Object> getActiveDutyById(int dutyId) {
        Duty duty;
        Optional<Duty> existingDutyOptional = dutyRepository.findActiveDutyById(dutyId);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingDutyOptional.isPresent()) {
                duty = existingDutyOptional.get();
                map.put("Airline Id", duty.getAirline().getAirlineId());
                map.put("AirlineName", duty.getAirline().getAirlineName());
                map.put("AirlineAddress", duty.getAirline().getAirlineAddress());
                map.put("Airport Id", duty.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", duty.getAirline().getMobileNum1());
                map.put("MobileNum2", duty.getAirline().getMobileNum2());
                map.put("MobileNum3", duty.getAirline().getMobileNum3());
                map.put("Email1", duty.getAirline().getEmail1());
                map.put("Email2", duty.getAirline().getEmail2());

                propertyMap.put("Duty Id", duty.getDutyId());
                propertyMap.put("Duty Name", duty.getDutyName());
                propertyMap.put("Duty Date", duty.getDutyDate());
                propertyMap.put("Related Staff", duty.getRelatedStaff());
                propertyMap.put("Total Staff", duty.getTotalStaff());
                propertyMap.put("File Location", duty.getFileLocation());
                propertyMap.put("File Name", duty.getFileName());
                propertyMap.put("Status", duty.isStatus());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "duty_no_longer_available");
                propertyMap.put("message", "Sorry, this Duty " + dutyId + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Duty Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }

    }

    // Get Active & Delete Records
    public Map<String, Object> getAllDuty() {
        List<Duty> existingDutyOptional = dutyRepository.findAll();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", duty.getAirline().getAirlineId());
            map.put("AirlineName", duty.getAirline().getAirlineName());
            map.put("AirlineAddress", duty.getAirline().getAirlineAddress());
            map.put("Airport Id", duty.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", duty.getAirline().getMobileNum1());
            map.put("MobileNum2", duty.getAirline().getMobileNum2());
            map.put("MobileNum3", duty.getAirline().getMobileNum3());
            map.put("Email1", duty.getAirline().getEmail1());
            map.put("Email2", duty.getAirline().getEmail2());

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("Airline", map);
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }

    public Map<String, Object> getAllActiveDuty() {
        List<Duty> existingDutyOptional = dutyRepository.findAllActiveDuty();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", duty.getAirline().getAirlineId());
            map.put("AirlineName", duty.getAirline().getAirlineName());
            map.put("AirlineAddress", duty.getAirline().getAirlineAddress());
            map.put("Airport Id", duty.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", duty.getAirline().getMobileNum1());
            map.put("MobileNum2", duty.getAirline().getMobileNum2());
            map.put("MobileNum3", duty.getAirline().getMobileNum3());
            map.put("Email1", duty.getAirline().getEmail1());
            map.put("Email2", duty.getAirline().getEmail2());

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("Airline", map);
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;
    }

    public Map<String, Object> getAllDeletedDuty() {
        List<Duty> existingDutyOptional = dutyRepository.findAllDeletedDuty();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", duty.getAirline().getAirlineId());
            map.put("AirlineName", duty.getAirline().getAirlineName());
            map.put("AirlineAddress", duty.getAirline().getAirlineAddress());
            map.put("Airport Id", duty.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", duty.getAirline().getMobileNum1());
            map.put("MobileNum2", duty.getAirline().getMobileNum2());
            map.put("MobileNum3", duty.getAirline().getMobileNum3());
            map.put("Email1", duty.getAirline().getEmail1());
            map.put("Email2", duty.getAirline().getEmail2());

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("Airline", map);
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;
    }

    public Map<String, Object> getAllActiveDutyPagination(Pageable pageable) {
        Page<Duty> existingDutyOptional = dutyRepository.findAll(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", duty.getAirline().getAirlineId());
            map.put("AirlineName", duty.getAirline().getAirlineName());
            map.put("AirlineAddress", duty.getAirline().getAirlineAddress());
            map.put("Airport Id", duty.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", duty.getAirline().getMobileNum1());
            map.put("MobileNum2", duty.getAirline().getMobileNum2());
            map.put("MobileNum3", duty.getAirline().getMobileNum3());
            map.put("Email1", duty.getAirline().getEmail1());
            map.put("Email2", duty.getAirline().getEmail2());

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    public Map<String, Object> getAllDeletedDutyPagination(int page, int size, String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy));
        Page<Duty> existingDutyOptional = dutyRepository.findAllDeletedDutyPagination(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", duty.getAirline().getAirlineId());
            map.put("AirlineName", duty.getAirline().getAirlineName());
            map.put("AirlineAddress", duty.getAirline().getAirlineAddress());
            map.put("Airport Id", duty.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", duty.getAirline().getMobileNum1());
            map.put("MobileNum2", duty.getAirline().getMobileNum2());
            map.put("MobileNum3", duty.getAirline().getMobileNum3());
            map.put("Email1", duty.getAirline().getEmail1());
            map.put("Email2", duty.getAirline().getEmail2());

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    public Map<String, Object> getAllDutyPagination(Pageable pageable) {
        Page<Duty> existingDutyOptional = dutyRepository.findAll(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", duty.getAirline().getAirlineId());
            map.put("AirlineName", duty.getAirline().getAirlineName());
            map.put("AirlineAddress", duty.getAirline().getAirlineAddress());
            map.put("Airport Id", duty.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", duty.getAirline().getMobileNum1());
            map.put("MobileNum2", duty.getAirline().getMobileNum2());
            map.put("MobileNum3", duty.getAirline().getMobileNum3());
            map.put("Email1", duty.getAirline().getEmail1());
            map.put("Email2", duty.getAirline().getEmail2());

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    public Map<String, Object> deleteDutyById(int dutyId) {
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            Optional<Duty> existingDutyOptional = dutyRepository.findActiveDutyById(dutyId);
            if (existingDutyOptional.isPresent()) {
                Duty duty = existingDutyOptional.get();
                duty.setDelete(true);
                duty.setActive(false);
                duty.setDeletionTime(new Timestamp(System.currentTimeMillis()));
                dutyRepository.save(duty);
                propertyMap.put("status", "success");
                propertyMap.put("message", "Duty soft deletion Confirmed!!");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "Duty_no_longer_available");
                propertyMap.put("message", "Sorry, this Duty" + dutyId + " is not Existed.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Duty Id ");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> delDutyHard(int dutyId) {
        Map<String, Object> map = new HashMap<>();

        Optional<Duty> existingDutyOptional = dutyRepository.findById(dutyId);

        try {
            if (existingDutyOptional.isPresent()) {
                dutyRepository.deleteById(dutyId);
                map.put("status", "success");
                map.put("message", "Duty id " + dutyId + " deletion Confirmed!!");
                return map;
            } else {
                map.put("status", "error");
                map.put("error", "no_longer_available");
                map.put("message", "Sorry, this Duty " + dutyId + " does not Existed.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Invalid Duty Id");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }

    public Map<String, Object> revertDuty(int dutyId) {
        Map<String, Object> map = new HashMap<>();
        try {
            Optional<Duty> existingDutyOptional = dutyRepository.findById(dutyId);
            if (existingDutyOptional.isPresent()) {
                Duty duty = existingDutyOptional.get();

                if (!duty.isActive() && duty.isDelete()) {
                    duty.setDelete(false);
                    duty.setActive(true);
                    duty.setDeletionTime(null);
                    dutyRepository.save(duty);
                    map.put("status", "success");
                    map.put("message", "Duty " + dutyId + " Revert Confirmed!!");
                    return map;
                } else {
                    map.put("status", "error");
                    map.put("error", "Duty can't be Reverted.");
                    return map;
                }
            } else {
                map.put("status", "error");
                map.put("error", "duty " + dutyId + " is not Present.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Please Check Again.");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }
}


