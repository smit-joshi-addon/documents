package com.New.ACTJWT.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import lombok.*;

import java.sql.Timestamp;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="airline")
public class Airline {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name ="airline_id")
    private int airlineId;
    @Column(name ="airline_name")
    private String airlineName;
    @Column(name = "airline_address")
    private String airlineAddress;

    @Column(name = "mobile_num1")
    //@Pattern(regexp = "^[0-9]{10}$", message = "Please provide a valid 10-digit mobile number")
    private String mobileNum1;
    @Column(name = "mobile_num2")
    private String mobileNum2;
    @Column(name = "mobile_num3")
    private String mobileNum3;

    @Column(name = "email1")
    @Email(message = "Please provide a valid email address")
    private String email1;
    @Column(name = "email2")
    @Email(message = "Please provide a valid email address")
    private String email2;

    //Common Columns
    @Column(name ="creation_time")
    private Timestamp creationTime;
    @Column(name ="deletion_time")
    private Timestamp deletionTime;
    @Column(name = "is_active")
    private boolean isActive;
    @Column(name = "is_delete")
    private boolean isDelete;
    @Column(name ="ip_address")
    private String ipAddress;


    @ManyToOne
    @JoinColumn(name = "airport_id")
    private Airport airport;


}
