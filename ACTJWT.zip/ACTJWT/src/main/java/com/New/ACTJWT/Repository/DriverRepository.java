package com.New.ACTJWT.Repository;

import com.New.ACTJWT.model.Driver;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DriverRepository extends JpaRepository<Driver, Integer> {

    //Fetch the record that are deleted
    List<Driver> findByIsDeleteTrue();
    //Through query
    @Query("select d from Driver d where d.isDelete= true and d.deletionTime is null")
    Page<Driver> findDeletedRecords(Pageable pageable);

    // Get the record that are not deleted.
    @Query(value = "select * from driver d where d.is_delete=false and d.is_active=true",nativeQuery = true)
    Page<Driver> findActiveRecords(Pageable pageable);
    @Query(value = "select * from Driver d where d.is_delete= false and d.is_active= true",nativeQuery = true)
    List<Driver> findActiveDrivers();

    @Query(value = "select * from Driver d where d.is_delete= false and d.is_active= true and d.driver_id = :driverId",nativeQuery = true)
    Optional<Driver> findActiveDriverById(int driverId);

    @Modifying
    @Query("update Driver d set d.isActive=true, d.isDelete = false where d.isDelete = true and d.driverId =:drId")
    public void revertJPQL(@Param("drId") int drId);
    @Modifying
    @Query(value ="update driver set is_active = true , is_delete=false where is_delete = true and driver_id = :drId", nativeQuery = true)
    public void revertN(@Param("drId") int drId);
}
