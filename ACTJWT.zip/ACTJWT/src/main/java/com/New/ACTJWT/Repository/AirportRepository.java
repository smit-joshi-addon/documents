package com.New.ACTJWT.Repository;

import com.New.ACTJWT.model.Airport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AirportRepository extends JpaRepository<Airport,Integer> {

    //Native
    //@Query(value = "select a.airport_id,a.iata_code,a.airport_address,a.airport_country,a.airport_region from airport a where a.is_delete=true",nativeQuery = true)
    @Query(value = "select * from airport where is_delete=true and is_active=false",nativeQuery = true)
    public List<Airport> findSoftDelAirports();

    //JPQL
    @Query("select a from Airport a where a.isDelete=false and a.isActive = true")
    List<Airport> findActiveAirports();

    @Query(value = "select * from airport where is_active=true and deletion_time is null and airport_id=:airportId",nativeQuery = true)
    Optional<Airport> findActiveByAirportId(int airportId);

}
