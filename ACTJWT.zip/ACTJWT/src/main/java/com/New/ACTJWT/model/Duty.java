package com.New.ACTJWT.model;

import jakarta.persistence.*;
import lombok.*;

import java.sql.Timestamp;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="duty")
public class Duty {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name ="duty_id")
    private int dutyId;
    @Column(name ="duty_name")
    private String dutyName;
    @Column(name ="duty_date")
    private Timestamp dutyDate;

    @Column(name = "total_staff")
    private int totalStaff;
    @Column(name = "related_staff")
    private int relatedStaff;
    @Column(name = "file_location")
    private String fileLocation;
    @Column(name = "file_name")
    private String fileName;
    @Column(name = "status")
    private boolean status;


    //Common Columns
    @Column(name ="creation_time")
    private Timestamp creationTime;
    @Column(name ="deletion_time")
    private Timestamp deletionTime;
    @Column(name = "is_active")
    private boolean isActive;
    @Column(name = "is_delete")
    private boolean isDelete;
    @Column(name ="ip_address")
    private String ipAddress;


    @ManyToOne
    @JoinColumn(name = "airline_id")
    private Airline airline;
}
