package com.New.ACTJWT.service;

import com.New.ACTJWT.Repository.DriverRepository;
import com.New.ACTJWT.Repository.DutyDetailsRepository;
import com.New.ACTJWT.Repository.DutyRepository;
import com.New.ACTJWT.Repository.StaffRepository;
import com.New.ACTJWT.model.*;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class DutyDetailsService {
    @Autowired
    DutyDetailsRepository dutyDetailsRepository;

    @Autowired
    DriverRepository driverRepository;

    @Autowired
    StaffRepository staffRepository;

    @Autowired
    DutyRepository dutyRepository;


    public Map<String, Object> addDutyDetails(String dutyDetailsData, HttpServletRequest request) throws JSONException {
        JSONObject jsonData = new JSONObject(dutyDetailsData);
        Map<String, Object> m1 = new HashMap<String, Object>();
        Map<String, Object> map = new HashMap<String, Object>();

        Driver driver = null;
        int driverId = 0;

        Staff staff = null;
        int staffId = 0;

        Duty duty = null;
        int dutyId = 0;

        double distance = 0;
        Timestamp actPickupTime;
        String stringActPickupTime = null;

        String description = null;
        String address = null;
        String staffStatus = null;
        String driverName = null;
        String dutyType = null;
        String dDName = null;
        String mobileNum = null;


        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        DutyDetails dutyDetails = new DutyDetails();

        try {
            if (jsonData.has("dutyId") && jsonData.get("dutyId") != null
                    && !jsonData.get("dutyId").equals("")) {

                dutyId = jsonData.getInt("dutyId");
                Optional<Duty> existingDutyOptional = dutyRepository.findActiveDutyById(dutyId);
                duty = existingDutyOptional.orElse(null);
                if (duty == null) {
                    m1.put("status", "error");
                    m1.put("error", "no_longer_available");
                    m1.put("message", "Sorry, this Duty is not longer available.");
                    return m1;
                }
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field_validation");
                m1.put("message", "Please provide Duty identification like dutyId.");
                return m1;
            }
            if (jsonData.has("driverId") && jsonData.get("driverId") != null
                    && !jsonData.get("driverId").equals("")) {

                driverId = jsonData.getInt("driverId");
                Optional<Driver> existingDriverOptional = driverRepository.findActiveDriverById(driverId);
                driver = existingDriverOptional.orElse(null);
                if (driver == null) {
                    m1.put("status", "error");
                    m1.put("error", "no_longer_available");
                    m1.put("message", "Sorry, this Driver is not longer available.");
                    return m1;
                }
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field_validation");
                m1.put("message", "Please provide Driver identification like driverId.");
                return m1;
            }
            if (jsonData.has("staffId") && jsonData.get("staffId") != null
                    && !jsonData.get("staffId").equals("")) {

                staffId = jsonData.getInt("staffId");
                Optional<Staff> existingStaffOptional = staffRepository.findActiveStaffById(staffId);
                staff = existingStaffOptional.orElse(null);
                if (staff == null) {
                    m1.put("status", "error");
                    m1.put("error", "no_longer_available");
                    m1.put("message", "Sorry, this Staff is not longer available.");
                    return m1;
                }
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field_validation");
                m1.put("message", "Please provide Staff identification like staffId.");
                return m1;
            }

            //description Validation
            if (jsonData.has("description") && !jsonData.get("description").equals("")
                    && jsonData.get("description") != null) {
                description = jsonData.getString("description");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide description.");
                return m1;
            }

            // distance Validation
            if (jsonData.has("distance") && !jsonData.get("distance").equals("")
                    && jsonData.get("distance") != null) {
                distance = jsonData.getDouble("distance");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide distance.");
                return m1;
            }

            // address  Validation
            if (jsonData.has("address") && !jsonData.get("address").equals("")
                    && jsonData.get("address") != null) {
                address = jsonData.getString("address");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide address.");
                return m1;
            }
            // relatedStaff  Validation
            if (jsonData.has("actPickupTime") && !jsonData.get("actPickupTime").equals("")
                    && jsonData.get("actPickupTime") != null) {
                stringActPickupTime = jsonData.getString("actPickupTime");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide relatedStaff.");
                return m1;
            }

            //staffStatus   Validation
            if (jsonData.has("staffStatus") && !jsonData.get("staffStatus").equals("")
                    && jsonData.get("staffStatus") != null) {
                staffStatus = jsonData.getString("staffStatus");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide staffStatus.");
                return m1;
            }

            if (jsonData.has("driverName") && !jsonData.get("driverName").equals("")
                    && jsonData.get("driverName") != null) {
                driverName = jsonData.getString("driverName");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide driverName.");
                return m1;
            }
            if (jsonData.has("dutyType") && !jsonData.get("dutyType").equals("")
                    && jsonData.get("dutyType") != null) {
                dutyType = jsonData.getString("dutyType");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide dutyType.");
                return m1;
            }
            if (jsonData.has("dDName") && !jsonData.get("dDName").equals("")
                    && jsonData.get("dDName") != null) {
                dDName = jsonData.getString("dDName");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide dDName.");
                return m1;
            }
            if (jsonData.has("mobileNum") && !jsonData.get("mobileNum").equals("")
                    && jsonData.get("mobileNum") != null) {
                mobileNum = jsonData.getString("mobileNum");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide mobileNum.");
                return m1;
            }

            Date parsedDate = dateFormat.parse(stringActPickupTime);
            actPickupTime = new Timestamp(parsedDate.getTime());
            System.out.println("Timestamp: " + actPickupTime);

            dutyDetails.setDriver(driver);
            dutyDetails.setStaff(staff);
            dutyDetails.setDuty(duty);
            dutyDetails.setActPickupTime(actPickupTime);
            dutyDetails.setDescription(description);
            dutyDetails.setStaffStatus(staffStatus);
            dutyDetails.setDriverName(driverName);
            dutyDetails.setDutyType(dutyType);
            dutyDetails.setDistance(distance);
            dutyDetails.setAddress(address);
            dutyDetails.setDDName(dDName);
            dutyDetails.setMobileNum(mobileNum);
            dutyDetails.setCreationTime(new Timestamp(System.currentTimeMillis()));
            dutyDetails.setActive(true);
            dutyDetails.setDelete(false);
            String ipAddress = request.getHeader("X-FORWARDED-FOR");
            if (ipAddress == null || ipAddress.isEmpty()) {
                dutyDetails.setIpAddress(request.getRemoteAddr());
            }
            dutyDetails = dutyDetailsRepository.save(dutyDetails);

            m1.put("status", "success");
           /* map.put("Airline Id", duty.getAirline().getAirlineId());
            map.put("AirlineName", duty.getAirline().getAirlineName());
            map.put("AirlineAddress", duty.getAirline().getAirlineAddress());
            map.put("Airport Id", duty.getAirline().getAirport().getAirportId());
            map.put("Mobile Num1", duty.getAirline().getMobileNum1());
            map.put("Mobile Num2", duty.getAirline().getMobileNum2());
            map.put("Mobile Num3", duty.getAirline().getMobileNum3());
            map.put("Email1", duty.getAirline().getEmail1());
            map.put("Email2", duty.getAirline().getEmail2());
            m1.put("Duty Id", duty.getDutyId());
            m1.put("Duty Name", duty.getDutyName());
            m1.put("Duty Date", duty.getDutyDate());
            m1.put("Related Staff", duty.getRelatedStaff());
            m1.put("Total Staff", duty.getTotalStaff());
            m1.put("File Location", duty.getFileLocation());
            m1.put("File Name", duty.getFileName());
            m1.put("Status", duty.isStatus());
            m1.put("Airline", map);*/
            m1.put("message", "Duty Details information saved successfully!!");
            return m1;

        } catch (ParseException p) {
            p.printStackTrace();
            m1.put("status", "error");
            m1.put("error", "date_format_not_match");
            m1.put("message", "Please Enter Date in the Given Format :'yyyy-MM-dd HH:mm:ss'");
            return m1;
        } catch (Exception e) {
            e.printStackTrace();
            m1.put("status", "error");
            m1.put("error", "not_found");
            m1.put("message", "Something went wrong");
            return m1;
        }
    }


    public Map<String, Object> updateActiveDutyDetails(String dutyDetailsData) throws JSONException {
        JSONObject jsonData = new JSONObject(dutyDetailsData);
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> propertyMap3 = new HashMap<>();

        Driver driver = new Driver();
        int driverId = 0;
        Staff staff = new Staff();
        int staffId = 0;
        Duty duty = new Duty();
        int dutyId = 0;
        DutyDetails dutyDetails;
        int dutyDetailsId = 0;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            if (jsonData.has("dutyDetailsId") && jsonData.get("dutyDetailsId") != null
                    && !jsonData.get("dutyDetailsId").equals("")) {
                dutyDetailsId = jsonData.getInt("dutyDetailsId");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide dutyDetailsId.");
                return map;
            }
            Optional<DutyDetails> existingDutyDetailsOptional = dutyDetailsRepository.findActiveDutyDetailsById(dutyDetailsId);
            if (existingDutyDetailsOptional.isPresent()) {
                dutyDetails = existingDutyDetailsOptional.get();
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "The DutyDetails Does Not Exist.");
                return map;
            }

            /*if (jsonData.has("staffId") && jsonData.get("staffId") != null
                    && !jsonData.get("staffId").equals("")) {
                staffId = jsonData.getInt("staffId");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide staffId.");
                return map;
            }
            Optional<Staff> existingStaffOptional = staffRepository.findActiveStaffById(staffId);
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "The Staff Does Not Exist.");
                return map;
            }
            if (jsonData.has("driverId") && jsonData.get("driverId") != null
                    && !jsonData.get("driverId").equals("")) {
                driverId = jsonData.getInt("driverId");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide driverId.");
                return map;
            }
            Optional<Driver> existingDriverOptional = driverRepository.findActiveDriverById(driverId);
            if (existingDriverOptional.isPresent()) {
                driver = existingDriverOptional.get();
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "The Driver Does Not Exist.");
                return map;
            }*/

            /*if (!duty.getAirline().isActive() && duty.getAirline().isDelete()) {
                map.put("status", "error");
                map.put("error", "no_longer_available_airportId");
                map.put("message", "Sorry, This Airline id is not Updatable.");
                return map;
            }*/
            if (jsonData.has("driverId") && jsonData.get("driverId") != null
                    && !jsonData.get("driverId").equals("")) {
                driverId = jsonData.getInt("driverId");

                Optional<Driver> existingDriverOptional = driverRepository.findActiveDriverById(driverId);
                if (existingDriverOptional.isPresent()) {
                    driver = existingDriverOptional.get();
                    dutyDetails.setDriver(driver);
                } else {
                    map.put("status", "error");
                    map.put("error", "no_longer_available");
                    map.put("message", "Sorry, this Driver Id is not in the database.");
                    return map;
                }
            }
            if (jsonData.has("staffId") && jsonData.get("staffId") != null
                    && !jsonData.get("staffId").equals("")) {
                staffId = jsonData.getInt("staffId");

                Optional<Staff> existingStaffOptional = staffRepository.findActiveStaffById(staffId);
                if (existingStaffOptional.isPresent()) {
                    staff = existingStaffOptional.get();
                    dutyDetails.setStaff(staff);
                } else {
                    map.put("status", "error");
                    map.put("error", "no_longer_available");
                    map.put("message", "Sorry, this staffId is not in the database.");
                    return map;
                }
            }
            if (jsonData.has("dutyId") && jsonData.get("dutyId") != null
                    && !jsonData.get("dutyId").equals("")) {
                dutyId = jsonData.getInt("dutyId");

                Optional<Duty> existingDutyOptional = dutyRepository.findActiveDutyById(dutyId);
                if (existingDutyOptional.isPresent()) {
                    duty = existingDutyOptional.get();
                    dutyDetails.setDuty(duty);
                } else {
                    map.put("status", "error");
                    map.put("error", "no_longer_available");
                    map.put("message", "Sorry, this duty Id is not in the database.");
                    return map;
                }
            }

            if (jsonData.has("description") && jsonData.get("description") != null
                    && !jsonData.get("description").equals("")) {
                dutyDetails.setDescription(jsonData.getString("description"));
            }
            // airline Address Update
            if (jsonData.has("actPickupTime") && !jsonData.get("actPickupTime").equals("")
                    && jsonData.get("actPickupTime") != null) {
                String stringActPickupTime = jsonData.getString("actPickupTime");

                Date parsedDate = dateFormat.parse(stringActPickupTime);
                Timestamp actPickupTime = new Timestamp(parsedDate.getTime());
                dutyDetails.setActPickupTime(actPickupTime);
                System.out.println("Timestamp: " + actPickupTime);
            }
            if (jsonData.has("distance") && !jsonData.get("distance").equals("")
                    && jsonData.get("distance") != null) {
                dutyDetails.setDistance(jsonData.getDouble("distance"));
            }
            if (jsonData.has("address") && !jsonData.get("address").equals("")
                    && jsonData.get("address") != null) {
                dutyDetails.setAddress(jsonData.getString("address"));
            }
            //fileLocation Update
            if (jsonData.has("staffStatus") && !jsonData.get("staffStatus").equals("")
                    && jsonData.get("staffStatus") != null) {
                dutyDetails.setStaffStatus(jsonData.getString("staffStatus"));
            }
            if (jsonData.has("driverName") && !jsonData.get("driverName").equals("")
                    && jsonData.get("driverName") != null) {
                dutyDetails.setDriverName(jsonData.getString("driverName"));
            }

            //dDName Update
            if (jsonData.has("dDName") && !jsonData.get("dDName").equals("")
                    && jsonData.get("dDName") != null) {
                dutyDetails.setDDName(jsonData.getString("dDName"));
            }
            //dutyType Update
            if (jsonData.has("dutyType") && !jsonData.get("dutyType").equals("")
                    && jsonData.get("dutyType") != null) {
                dutyDetails.setDutyType(jsonData.getString("dutyType"));
            }
            //mobileNum Update
            if (jsonData.has("mobileNum") && !jsonData.get("mobileNum").equals("")
                    && jsonData.get("mobileNum") != null) {
                dutyDetails.setMobileNum(jsonData.getString("mobileNum"));
            }

            dutyDetails = dutyDetailsRepository.save(dutyDetails);
            map.put("status", "success");
            map.put("message", "Duty Details id " + dutyDetailsId + " Update Confirmed!!!");
            // To Return duty
            propertyMap.put("Duty Id", dutyDetails.getDuty().getDutyId());
            propertyMap.put("Duty Name", dutyDetails.getDuty().getDutyName());
            propertyMap.put("Duty Date", dutyDetails.getDuty().getDutyDate());
            propertyMap.put("Related Staff", dutyDetails.getDuty().getRelatedStaff());
            propertyMap.put("Total Staff", dutyDetails.getDuty().getTotalStaff());
            propertyMap.put("File Location", dutyDetails.getDuty().getFileLocation());
            propertyMap.put("File Name", dutyDetails.getDuty().getFileName());
            propertyMap.put("Duty Status", dutyDetails.getDuty().isStatus());
            // Driver
            propertyMap2.put("Driver", dutyDetails.getDriver());
            //Staff
            propertyMap3.put("Staff", dutyDetails.getStaff());
            //DutyDetails
            map.put("Duty Details Id", dutyDetails.getDutyDetailsId());
            map.put("Description", dutyDetails.getDescription());
            map.put("Distance", dutyDetails.getDistance());
            map.put("Actual Pickup Time", dutyDetails.getActPickupTime());
            map.put("Duty Type", dutyDetails.getDutyType());
            map.put("Address", dutyDetails.getAddress());
            map.put("Staff Status", dutyDetails.getStaffStatus());
            map.put("Driver Name", dutyDetails.getDriverName());
            map.put("Duty Details Name", dutyDetails.getDDName());
            map.put("Mobile Number", dutyDetails.getMobileNum());

            map.put("Duty", propertyMap);
            map.put("Staff", propertyMap3);
            map.put("Driver", propertyMap2);


        } catch (ParseException p) {
            p.printStackTrace();
            map.put("status", "error");
            map.put("error", "date_format_not_compatible");
            map.put("message", "Please provide Date in this format:'yyyy-MM-dd HH:mm:ss'");
            return map;
        } catch (JSONException e) {
            e.printStackTrace();
            map.put("status", "error");
            map.put("error", "not_found");
            map.put("message", "Something went wrong");
            return map;
        }
        return map;
    }

    public Map<String, Object> getActiveDutyDetailsById(int dutyDetailsId) {
        DutyDetails dutyDetails;
        Optional<DutyDetails> existingDutyDetailsOptional = dutyDetailsRepository.findActiveDutyDetailsById(dutyDetailsId);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        Map<String, Object> map3 = new HashMap<>();

        try {
            if (existingDutyDetailsOptional.isPresent()) {
                dutyDetails = existingDutyDetailsOptional.get();

                map.put("Duty Id", dutyDetails.getDuty().getDutyId());
                map.put("Duty Name", dutyDetails.getDuty().getDutyName());
                map.put("Duty Date", dutyDetails.getDuty().getDutyDate());
                map.put("Related Staff", dutyDetails.getDuty().getRelatedStaff());
                map.put("Total Staff", dutyDetails.getDuty().getTotalStaff());
                map.put("File Location", dutyDetails.getDuty().getFileLocation());
                map.put("File Name", dutyDetails.getDuty().getFileName());
                map.put("Duty Status", dutyDetails.getDuty().isStatus());

                // Driver
                map2.put("Driver", dutyDetails.getDriver());
                //Staff
                map3.put("Staff", dutyDetails.getStaff());

                propertyMap.put("Duty Details Id", dutyDetails.getDutyDetailsId());
                propertyMap.put("Description", dutyDetails.getDescription());
                propertyMap.put("Distance", dutyDetails.getDistance());
                propertyMap.put("Actual Pickup Time", dutyDetails.getActPickupTime());
                propertyMap.put("Duty Type", dutyDetails.getDutyType());
                propertyMap.put("Address", dutyDetails.getAddress());
                propertyMap.put("Staff Status", dutyDetails.getStaffStatus());
                propertyMap.put("Driver Name", dutyDetails.getDriverName());
                propertyMap.put("Duty Details Name", dutyDetails.getDDName());
                propertyMap.put("Mobile Number", dutyDetails.getMobileNum());

                propertyMap.put("Duty", map);
                propertyMap.put("Driver", map2);
                propertyMap.put("Staff", map3);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "dutyDetails_no_longer_available");
                propertyMap.put("message", "Sorry, this Duty Details" + dutyDetailsId + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Duty Details Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> getAllDutyDetails() {
        List<DutyDetails> existingDutyDetailsOptional = dutyDetailsRepository.findAll();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        Map<String, Object> map2;
        Map<String, Object> map3;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyDetailsOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Duty Details data not found");
            return propertyMap;
        }

        for (DutyDetails dutyDetails : existingDutyDetailsOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map2 = new HashMap<>();
            map3 = new HashMap<>();


            map.put("Duty Id", dutyDetails.getDuty().getDutyId());
            map.put("Duty Name", dutyDetails.getDuty().getDutyName());
            map.put("Duty Date", dutyDetails.getDuty().getDutyDate());
            map.put("Related Staff", dutyDetails.getDuty().getRelatedStaff());
            map.put("Total Staff", dutyDetails.getDuty().getTotalStaff());
            map.put("File Location", dutyDetails.getDuty().getFileLocation());
            map.put("File Name", dutyDetails.getDuty().getFileName());
            map.put("Duty Status", dutyDetails.getDuty().isStatus());

            // Driver
            map2.put("Driver", dutyDetails.getDriver());
            //Staff
            map3.put("Staff", dutyDetails.getStaff());

            propertyMap2.put("Duty Details Id", dutyDetails.getDutyDetailsId());
            propertyMap2.put("Description", dutyDetails.getDescription());
            propertyMap2.put("Distance", dutyDetails.getDistance());
            propertyMap2.put("Actual Pickup Time", dutyDetails.getActPickupTime());
            propertyMap2.put("Duty Type", dutyDetails.getDutyType());
            propertyMap2.put("Address", dutyDetails.getAddress());
            propertyMap2.put("Staff Status", dutyDetails.getStaffStatus());
            propertyMap2.put("Driver Name", dutyDetails.getDriverName());
            propertyMap2.put("Duty Details Name", dutyDetails.getDDName());
            propertyMap2.put("Mobile Number", dutyDetails.getMobileNum());

            propertyMap2.put("Duty", map);
            propertyMap2.put("Driver", map2);
            propertyMap2.put("Staff", map3);

            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty Details", data);
        return propertyMap;

    }

    public Map<String, Object> getAllActiveDutyDetails() {
        List<DutyDetails> existingDutyDetailsOptional = dutyDetailsRepository.findAllActiveDutyDetails();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        Map<String, Object> map2;
        Map<String, Object> map3;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyDetailsOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Duty Details data not found");
            return propertyMap;
        }

        for (DutyDetails dutyDetails : existingDutyDetailsOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map2 = new HashMap<>();
            map3 = new HashMap<>();


            map.put("Duty Id", dutyDetails.getDuty().getDutyId());
            map.put("Duty Name", dutyDetails.getDuty().getDutyName());
            map.put("Duty Date", dutyDetails.getDuty().getDutyDate());
            map.put("Related Staff", dutyDetails.getDuty().getRelatedStaff());
            map.put("Total Staff", dutyDetails.getDuty().getTotalStaff());
            map.put("File Location", dutyDetails.getDuty().getFileLocation());
            map.put("File Name", dutyDetails.getDuty().getFileName());
            map.put("Duty Status", dutyDetails.getDuty().isStatus());

            // Driver
            map2.put("Driver", dutyDetails.getDriver());
            //Staff
            map3.put("Staff", dutyDetails.getStaff());

            propertyMap2.put("Duty Details Id", dutyDetails.getDutyDetailsId());
            propertyMap2.put("Description", dutyDetails.getDescription());
            propertyMap2.put("Distance", dutyDetails.getDistance());
            propertyMap2.put("Actual Pickup Time", dutyDetails.getActPickupTime());
            propertyMap2.put("Duty Type", dutyDetails.getDutyType());
            propertyMap2.put("Address", dutyDetails.getAddress());
            propertyMap2.put("Staff Status", dutyDetails.getStaffStatus());
            propertyMap2.put("Driver Name", dutyDetails.getDriverName());
            propertyMap2.put("Duty Details Name", dutyDetails.getDDName());
            propertyMap2.put("Mobile Number", dutyDetails.getMobileNum());

            propertyMap2.put("Duty", map);
            propertyMap2.put("Driver", map2);
            propertyMap2.put("Staff", map3);

            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty Details", data);
        return propertyMap;
    }

    public Map<String, Object> getAllDeletedDutyDetails() {
        List<DutyDetails> existingDutyDetailsOptional = dutyDetailsRepository.findAllDeletedDutyDetails();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        Map<String, Object> map2;
        Map<String, Object> map3;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyDetailsOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Duty Details data not found");
            return propertyMap;
        }

        for (DutyDetails dutyDetails : existingDutyDetailsOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map2 = new HashMap<>();
            map3 = new HashMap<>();


            map.put("Duty Id", dutyDetails.getDuty().getDutyId());
            map.put("Duty Name", dutyDetails.getDuty().getDutyName());
            map.put("Duty Date", dutyDetails.getDuty().getDutyDate());
            map.put("Related Staff", dutyDetails.getDuty().getRelatedStaff());
            map.put("Total Staff", dutyDetails.getDuty().getTotalStaff());
            map.put("File Location", dutyDetails.getDuty().getFileLocation());
            map.put("File Name", dutyDetails.getDuty().getFileName());
            map.put("Duty Status", dutyDetails.getDuty().isStatus());

            // Driver
            map2.put("Driver", dutyDetails.getDriver());
            //Staff
            map3.put("Staff", dutyDetails.getStaff());

            propertyMap2.put("Duty Details Id", dutyDetails.getDutyDetailsId());
            propertyMap2.put("Description", dutyDetails.getDescription());
            propertyMap2.put("Distance", dutyDetails.getDistance());
            propertyMap2.put("Actual Pickup Time", dutyDetails.getActPickupTime());
            propertyMap2.put("Duty Type", dutyDetails.getDutyType());
            propertyMap2.put("Address", dutyDetails.getAddress());
            propertyMap2.put("Staff Status", dutyDetails.getStaffStatus());
            propertyMap2.put("Driver Name", dutyDetails.getDriverName());
            propertyMap2.put("Duty Details Name", dutyDetails.getDDName());
            propertyMap2.put("Mobile Number", dutyDetails.getMobileNum());

            propertyMap2.put("Duty", map);
            propertyMap2.put("Driver", map2);
            propertyMap2.put("Staff", map3);

            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty Details", data);
        return propertyMap;
    }

    public Map<String, Object> getAllActiveDutyDetailsPagination(Pageable pageable) {
        Page<DutyDetails> existingDutyDetailsOptional = dutyDetailsRepository.findAllActiveDutyDetailsPagination(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        Map<String, Object> map2;
        Map<String, Object> map3;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyDetailsOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Duty Details data not found");
            return propertyMap;
        }

        for (DutyDetails dutyDetails : existingDutyDetailsOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map2 = new HashMap<>();
            map3 = new HashMap<>();


            map.put("Duty Id", dutyDetails.getDuty().getDutyId());
            map.put("Duty Name", dutyDetails.getDuty().getDutyName());
            map.put("Duty Date", dutyDetails.getDuty().getDutyDate());
            map.put("Related Staff", dutyDetails.getDuty().getRelatedStaff());
            map.put("Total Staff", dutyDetails.getDuty().getTotalStaff());
            map.put("File Location", dutyDetails.getDuty().getFileLocation());
            map.put("File Name", dutyDetails.getDuty().getFileName());
            map.put("Duty Status", dutyDetails.getDuty().isStatus());

            // Driver
            map2.put("Driver", dutyDetails.getDriver());
            //Staff
            map3.put("Staff", dutyDetails.getStaff());

            propertyMap2.put("Duty Details Id", dutyDetails.getDutyDetailsId());
            propertyMap2.put("Description", dutyDetails.getDescription());
            propertyMap2.put("Distance", dutyDetails.getDistance());
            propertyMap2.put("Actual Pickup Time", dutyDetails.getActPickupTime());
            propertyMap2.put("Duty Type", dutyDetails.getDutyType());
            propertyMap2.put("Address", dutyDetails.getAddress());
            propertyMap2.put("Staff Status", dutyDetails.getStaffStatus());
            propertyMap2.put("Driver Name", dutyDetails.getDriverName());
            propertyMap2.put("Duty Details Name", dutyDetails.getDDName());
            propertyMap2.put("Mobile Number", dutyDetails.getMobileNum());

            propertyMap2.put("Duty", map);
            propertyMap2.put("Driver", map2);
            propertyMap2.put("Staff", map3);

            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty Details", data);
        return propertyMap;
    }

    public Map<String, Object> getAllDeletedDutyDetailsPagination(int page, int size, String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy));
        Page<DutyDetails> existingDutyDetailsOptional = dutyDetailsRepository.findAllDeletedDutyDetailsPagination(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        Map<String, Object> map2;
        Map<String, Object> map3;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyDetailsOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Duty Details data not found");
            return propertyMap;
        }

        for (DutyDetails dutyDetails : existingDutyDetailsOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map2 = new HashMap<>();
            map3 = new HashMap<>();


            map.put("Duty Id", dutyDetails.getDuty().getDutyId());
            map.put("Duty Name", dutyDetails.getDuty().getDutyName());
            map.put("Duty Date", dutyDetails.getDuty().getDutyDate());
            map.put("Related Staff", dutyDetails.getDuty().getRelatedStaff());
            map.put("Total Staff", dutyDetails.getDuty().getTotalStaff());
            map.put("File Location", dutyDetails.getDuty().getFileLocation());
            map.put("File Name", dutyDetails.getDuty().getFileName());
            map.put("Duty Status", dutyDetails.getDuty().isStatus());

            // Driver
            map2.put("Driver", dutyDetails.getDriver());
            //Staff
            map3.put("Staff", dutyDetails.getStaff());

            propertyMap2.put("Duty Details Id", dutyDetails.getDutyDetailsId());
            propertyMap2.put("Description", dutyDetails.getDescription());
            propertyMap2.put("Distance", dutyDetails.getDistance());
            propertyMap2.put("Actual Pickup Time", dutyDetails.getActPickupTime());
            propertyMap2.put("Duty Type", dutyDetails.getDutyType());
            propertyMap2.put("Address", dutyDetails.getAddress());
            propertyMap2.put("Staff Status", dutyDetails.getStaffStatus());
            propertyMap2.put("Driver Name", dutyDetails.getDriverName());
            propertyMap2.put("Duty Details Name", dutyDetails.getDDName());
            propertyMap2.put("Mobile Number", dutyDetails.getMobileNum());

            propertyMap2.put("Duty", map);
            propertyMap2.put("Driver", map2);
            propertyMap2.put("Staff", map3);

            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty Details", data);
        return propertyMap;
    }

    public Map<String, Object> getAllDutyDetailsPagination(Pageable pageable) {
        Page<DutyDetails> existingDutyDetailsOptional = dutyDetailsRepository.findAll(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        Map<String, Object> map2;
        Map<String, Object> map3;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyDetailsOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Duty Details data not found");
            return propertyMap;
        }

        for (DutyDetails dutyDetails : existingDutyDetailsOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map2 = new HashMap<>();
            map3 = new HashMap<>();


            map.put("Duty Id", dutyDetails.getDuty().getDutyId());
            map.put("Duty Name", dutyDetails.getDuty().getDutyName());
            map.put("Duty Date", dutyDetails.getDuty().getDutyDate());
            map.put("Related Staff", dutyDetails.getDuty().getRelatedStaff());
            map.put("Total Staff", dutyDetails.getDuty().getTotalStaff());
            map.put("File Location", dutyDetails.getDuty().getFileLocation());
            map.put("File Name", dutyDetails.getDuty().getFileName());
            map.put("Duty Status", dutyDetails.getDuty().isStatus());

            // Driver
            map2.put("Driver", dutyDetails.getDriver());
            //Staff
            map3.put("Staff", dutyDetails.getStaff());

            propertyMap2.put("Duty Details Id", dutyDetails.getDutyDetailsId());
            propertyMap2.put("Description", dutyDetails.getDescription());
            propertyMap2.put("Distance", dutyDetails.getDistance());
            propertyMap2.put("Actual Pickup Time", dutyDetails.getActPickupTime());
            propertyMap2.put("Duty Type", dutyDetails.getDutyType());
            propertyMap2.put("Address", dutyDetails.getAddress());
            propertyMap2.put("Staff Status", dutyDetails.getStaffStatus());
            propertyMap2.put("Driver Name", dutyDetails.getDriverName());
            propertyMap2.put("Duty Details Name", dutyDetails.getDDName());
            propertyMap2.put("Mobile Number", dutyDetails.getMobileNum());

            propertyMap2.put("Duty", map);
            propertyMap2.put("Driver", map2);
            propertyMap2.put("Staff", map3);

            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty Details", data);
        return propertyMap;
    }

    public Map<String, Object> deleteDutyDetailsById(int dutyDetailsId) {
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            Optional<DutyDetails> existingDutyDetailsOptional = dutyDetailsRepository.findActiveDutyDetailsById(dutyDetailsId);
            if (existingDutyDetailsOptional.isPresent()) {
                DutyDetails dutyDetails = existingDutyDetailsOptional.get();
                dutyDetails.setDelete(true);
                dutyDetails.setActive(false);
                dutyDetails.setDeletionTime(new Timestamp(System.currentTimeMillis()));
                dutyDetailsRepository.save(dutyDetails);
                propertyMap.put("status", "success");
                propertyMap.put("message", "Duty Details soft deletion Confirmed!!");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "Duty_no_longer_available");
                propertyMap.put("message", "Sorry, this Duty Details" + dutyDetailsId + " is not Existed.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Duty Details Id ");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> delDutyDetailsHard(int dutyDetailsId) {
        Map<String, Object> map = new HashMap<>();

        Optional<DutyDetails> existingDutyDetailsOptional = dutyDetailsRepository.findById(dutyDetailsId);

        try {
            if (existingDutyDetailsOptional.isPresent()) {
                dutyDetailsRepository.deleteById(dutyDetailsId);
                map.put("status", "success");
                map.put("message", "Duty Details id " + dutyDetailsId + " deletion Confirmed!!");
                return map;
            } else {
                map.put("status", "error");
                map.put("error", "no_longer_available");
                map.put("message", "Sorry, this Duty Details" + dutyDetailsId + " does not Existed.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Invalid Duty Details Id");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }

    public Map<String, Object> revertDutyDetailsById(int dutyDetailsId) {
        Map<String, Object> map = new HashMap<>();
        try {
            Optional<DutyDetails> existingDutyDetailsOptional = dutyDetailsRepository.findById(dutyDetailsId);
            if (existingDutyDetailsOptional.isPresent()) {
                DutyDetails dutyDetails = existingDutyDetailsOptional.get();

                if (!dutyDetails.isActive() && dutyDetails.isDelete()) {
                    dutyDetails.setDelete(false);
                    dutyDetails.setActive(true);
                    dutyDetails.setDeletionTime(null);
                    dutyDetailsRepository.save(dutyDetails);
                    map.put("status", "success");
                    map.put("message", "Duty Details " + dutyDetailsId + " Revert Confirmed!!");
                    return map;
                } else {
                    map.put("status", "error");
                    map.put("error", "Duty Details can't be Reverted.");
                    return map;
                }
            } else {
                map.put("status", "error");
                map.put("error", "duty Details" + dutyDetailsId + " is not Present.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Please Check Again.");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }
}
