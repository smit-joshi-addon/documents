package com.New.ACTJWT.Repository;

import com.New.ACTJWT.model.Staff;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import java.util.List;
import java.util.Optional;

@Repository
public interface StaffRepository extends JpaRepository<Staff, Integer> {

    //Fetch the record that are deleted
    List<Staff> findByIsDeleteTrue();

    @Query(value = "select * from Staff s where s.is_delete=false and s.is_active = true and s.staff_id = :staffId",nativeQuery = true)
    Optional<Staff> findActiveStaffById(int staffId);

    //Through query
    @Query("select s from Staff s where s.isDelete= true")
    List<Staff> findAllDeletedStaff();

    //Through query
    @Query("select s from Staff s where s.isDelete= true")
    Page<Staff> findAllDeletedStaffPagination(Pageable pageable);

    // Get the record that are not deleted.
    @Query("select a from Staff a where a.isDelete=false")
    List<Staff> findAllActiveStaff();

    // Get the record that are not deleted.
    @Query("select a from Staff a where a.isDelete=false")
    Page<Staff> findActiveStaffPagination(Pageable pageable);

    //JPQL Query use Object
    @Modifying
    @Query("update Staff s set s.isActive=true, s.isDelete = false where s.isDelete = true and s.staffId =:staffId")
    public void revertStaff(@Param("staffId") int staffId);

    //Native Query use database name
    @Modifying
    @Query(value ="update Staff set is_active = true , is_delete=false , deletion_time = NULL where is_delete = true and staff_id = :staffId", nativeQuery = true)
    public void revertN(@Param("staffId") int staffId);
}
