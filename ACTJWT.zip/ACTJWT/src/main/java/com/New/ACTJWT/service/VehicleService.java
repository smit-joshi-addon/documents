package com.New.ACTJWT.service;

import com.New.ACTJWT.Repository.VehicleRepository;
import com.New.ACTJWT.model.Vehicle;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.*;

@Service
public class VehicleService {
    @Autowired
    VehicleRepository vehicleRepository;

    public Map<String, Object> addVehicle(String vehicleData, HttpServletRequest request) throws JSONException {
        JSONObject jsonData = new JSONObject(vehicleData);
        Map<String, Object> m1 = new HashMap<String, Object>();

        Vehicle vehicle = new Vehicle();
        int vehiclePersonCapacity = 0;
        String vehicleBrand = null;
        String vehicleModel = null;
        String vehiclePlatNum = null;

        try {
            //vehiclePersonCapacity Validation
            if (jsonData.has("vehiclePersonCapacity") && !jsonData.get("vehiclePersonCapacity").equals("")
                    && jsonData.get("vehiclePersonCapacity") != null) {
                vehiclePersonCapacity = jsonData.getInt("vehiclePersonCapacity");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide vehiclePersonCapacity.");
                return m1;
            }

            //vehiclePlatNum Validation
            if (jsonData.has("vehiclePlatNum") && !jsonData.get("vehiclePlatNum").equals("")
                    && jsonData.get("vehiclePlatNum") != null) {
                vehiclePlatNum = jsonData.getString("vehiclePlatNum");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide vehiclePlatNum.");
                return m1;
            }

            // vehicleBrand Validation
            if (jsonData.has("vehicleBrand") && !jsonData.get("vehicleBrand").equals("")
                    && jsonData.get("vehicleBrand") != null) {
                vehicleBrand = jsonData.getString("vehicleBrand");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide vehicleBrand.");
                return m1;
            }

            if (jsonData.has("vehicleModel") && !jsonData.get("vehicleModel").equals("")
                    && jsonData.get("vehicleModel") != null) {
                vehicleModel = jsonData.getString("vehicleModel");
            }
            vehicle.setVehiclePersonCapacity(vehiclePersonCapacity);
            vehicle.setVehicleBrand(vehicleBrand);
            vehicle.setVehicleModel(vehicleModel);
            vehicle.setVehiclePlatNum(vehiclePlatNum);
            vehicle.setCreationTime(new Timestamp(System.currentTimeMillis()));
            vehicle.setActive(true);
            vehicle.setDelete(false);
            String ipAddress = request.getHeader("X-FORWARDED-FOR");
            if (ipAddress == null || ipAddress.isEmpty()) {
                vehicle.setIpAddress(request.getRemoteAddr());
            }
            vehicleRepository.save(vehicle);
            m1.put("status", "success");
            m1.put("message", "Vehicle information saved successfully!!");
            return m1;

        } catch (Exception e) {
            e.printStackTrace();
            m1.put("status", "error");
            m1.put("error", "not_found");
            m1.put("message", "Something went wrong");
            return m1;
        }
    }

    //Get One Record By Id.
    public Map<String, Object> getVehicleById(int vehicleId) {
        Vehicle vehicle;
        Optional<Vehicle> existingVehicleOptional = vehicleRepository.findById(vehicleId);
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            if (existingVehicleOptional.isPresent()) {
                vehicle = existingVehicleOptional.get();
                propertyMap.put("vehicleId", vehicle.getVehicleId());
                propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
                propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
                propertyMap.put("vehicleModel", vehicle.getVehicleModel());
                propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Vehicle" + vehicleId + " is not longer available.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Vehicle Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    // Get Only active Record
    public Map<String, Object> getActiveVehicleById(int vehicleId) {
        Vehicle vehicle;
        Optional<Vehicle> existingVehicleOptional = vehicleRepository.findActiveVehicleById(vehicleId);
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            if (existingVehicleOptional.isPresent()) {
                vehicle = existingVehicleOptional.get();
                propertyMap.put("vehicleId", vehicle.getVehicleId());
                propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
                propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
                propertyMap.put("vehicleModel", vehicle.getVehicleModel());
                propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Vehicle" + vehicleId + " is not longer available.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Vehicle Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    //Get All The Records.
    public Map<String, Object> getAllVehicles() {
        List<Vehicle> existingVehicleOptional = vehicleRepository.findAll();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap.put("vehicleId", vehicle.getVehicleId());
            propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;
    }
    //With Pagination Only Active Records
    public Map<String, Object> getAllVehiclesPagination(Pageable pageable) {
        Page<Vehicle> existingVehicleOptional = vehicleRepository.findAll(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap.put("vehicleId", vehicle.getVehicleId());
            propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;

    }

// Return Only Active Records
    public Map<String, Object> getAllActiveVehicles() {
        List<Vehicle> existingVehicleOptional = vehicleRepository.findActiveVehicles();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap.put("vehicleId", vehicle.getVehicleId());
            propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;

    }


    // Return Only Active Records
    public Map<String, Object> getAllDeleteVehicles() {
        List<Vehicle> existingVehicleOptional = vehicleRepository.findDeletedVehicles();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap.put("vehicleId", vehicle.getVehicleId());
            propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;

    }

    //With Pagination Only Active Records
    public Map<String, Object> getAllActiveVehiclesPagination(int page, int size, String sort) {
        Pageable pageable = PageRequest.of(page,size, Sort.by(sort));
        Page<Vehicle> existingVehicleOptional = vehicleRepository.findActiveVehiclesPagination(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap.put("vehicleId", vehicle.getVehicleId());
            propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;

    }



    //Update The Vehicle
    public Map<String, Object> updateVehicleById(String vehicleData) throws JSONException {
        JSONObject jsonData = new JSONObject(vehicleData);
        Map<String, Object> map = new HashMap<>();
        int vehicleId = 0;
        Vehicle vehicle;

        try {
            if (jsonData.has("vehicleId") && jsonData.get("vehicleId") != null
                    && !jsonData.get("vehicleId").equals("")) {
                vehicleId = jsonData.getInt("vehicleId");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide vehicleId.");
                return map;
            }
            Optional<Vehicle> existingVehicleOptional = vehicleRepository.findActiveVehicleById(vehicleId);
            if (existingVehicleOptional.isPresent()) {
                vehicle = existingVehicleOptional.get();
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "The Vehicle Does Not Exist.");
                return map;
            }
            if (jsonData.has("vehiclePersonCapacity")) {
                if (!jsonData.get("vehiclePersonCapacity").equals("") && !jsonData.get("vehiclePersonCapacity").equals(null) && jsonData.get("vehiclePersonCapacity") != null) {
                    vehicle.setVehiclePersonCapacity(jsonData.getInt("vehiclePersonCapacity"));
                }
                else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper vehiclePersonCapacity.");
                    return map;
                }
            }
            if (jsonData.has("vehicleBrand")) {
                if (!jsonData.get("vehicleBrand").equals("") && !jsonData.get("vehicleBrand").equals(null) && jsonData.get("vehicleBrand") != null) {
                    vehicle.setVehicleBrand(jsonData.getString("vehicleBrand"));
                }else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper vehicleBrand.");
                    return map;
                }
            }
            if (jsonData.has("vehicleModel")) {
                if (!jsonData.get("vehicleModel").equals("") && !jsonData.get("vehicleModel").equals(null) && jsonData.get("vehicleModel") != null) {
                    vehicle.setVehicleModel(jsonData.getString("vehicleModel"));
                }else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper vehicleModel.");
                    return map;
                }
            }
            if (jsonData.has("vehiclePlatNum")) {
                if (!jsonData.get("vehiclePlatNum").equals("") && !jsonData.get("vehiclePlatNum").equals(null)
                        && jsonData.get("vehiclePlatNum") != null) {
                    vehicle.setVehiclePlatNum(jsonData.getString("vehiclePlatNum"));
                }else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper vehiclePlatNum.");
                    return map;
                }
            }
            vehicleRepository.save(vehicle);
            map.put("status", "success");
            map.put("message", "Vehicle id " + vehicleId + " Update Confirmed!!!");

            // Record Show With Only Required Field
            map.put("vehicleId", vehicle.getVehicleId());
            map.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            map.put("vehicleBrand", vehicle.getVehicleBrand());
            map.put("vehicleModel", vehicle.getVehicleModel());
            map.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
        } catch (
                Exception e) {
            e.printStackTrace();
            map.put("status", "error");
            map.put("error", "not_found");
            map.put("message", "Something went wrong");
            return map;
        }
        return map;
    }

    // HARD Delete
    public Map<String, Object> delVehicleIdHard(int vehicleId) {
        Map<String, Object> map = new HashMap<>();

        Optional<Vehicle> existingVehicleOptional = vehicleRepository.findById(vehicleId);
        try {
            if (existingVehicleOptional.isPresent()) {
                //airportRepository.deleteById(apId);
                vehicleRepository.deleteById(vehicleId);
                map.put("status", "success");
                map.put("message", "Vehicle id " + vehicleId + " deletion Confirmed!!");
                return map;
            } else {
                map.put("status", "error");
                map.put("error", "no_longer_available");
                map.put("message", "Sorry, this Vehicle " + vehicleId + " does not Existed.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Invalid Airport Id");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }

    // Soft Delete By Id.
    public Map<String, Object> delVehicleById(int vehicleId) {
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            Optional<Vehicle> existingVehicleOptional = vehicleRepository.findActiveVehicleById(vehicleId);
            if (existingVehicleOptional.isPresent()) {
                Vehicle vehicle = existingVehicleOptional.get();

                vehicle.setDelete(true);
                vehicle.setActive(false);
                vehicle.setDeletionTime(new Timestamp(System.currentTimeMillis()));
                vehicleRepository.save(vehicle);
                propertyMap.put("status", "success");
                propertyMap.put("message", "Vehicle soft deletion Confirmed!!");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Vehicle" + vehicleId + " is not Existed.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Vehicle Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    // Revert the record that are only soft deleted
    public Map<String, Object> revertVehicleById(int vehicleId) {
        Map<String, Object> map = new HashMap<>();

        try {
            Optional<Vehicle> existingVehicleOptional = vehicleRepository.findById(vehicleId);
            if (existingVehicleOptional.isPresent()) {
                Vehicle vehicle = existingVehicleOptional.get();

                if (vehicle.isActive() == false && vehicle.isDelete() == true) {
                    vehicle.setDelete(false);
                    vehicle.setActive(true);
                    vehicle.setDeletionTime(null);
                    vehicleRepository.save(vehicle);
                    map.put("status", "success");
                    map.put("message", "Vehicle " + vehicleId + " Revert Confirmed!!");
                    return map;
                } else {
                    map.put("status", "error");
                    map.put("error", "Vehicle can't be Reverted.");
                    return map;
                }
            } else {
                map.put("status", "error");
                map.put("error", "Vehicle " + vehicleId + " field is invalid input.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Please Check Again.");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }


}
