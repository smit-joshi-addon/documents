package com.New.ACTJWT.service;

import com.New.ACTJWT.Repository.AirlineRepository;
import com.New.ACTJWT.Repository.StaffRepository;
import com.New.ACTJWT.model.Airline;
import com.New.ACTJWT.model.Staff;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.*;

@Service
public class StaffService {
    @Autowired
    StaffRepository staffRepository;

    @Autowired
    AirlineRepository airlineRepository;


    public Map<String, Object> addStaff(String staffData, HttpServletRequest request) throws JSONException {
        JSONObject jsonData = new JSONObject(staffData);
        Map<String, Object> m1 = new HashMap<String, Object>();
        Map<String, Object> map = new HashMap<String, Object>();

        Airline airline = null;
        int airlineId = 0;
        int staffCode = 0;
        String staffFullName = null;
        String staffSex = null;
        String staffAddress = null;

        String mobileNum1 = null;
        String mobileNum2 = null;
        String email1 = null;

        try {
            if (jsonData.has("airlineId") && jsonData.get("airlineId") != null
                    && !jsonData.get("airlineId").equals("")) {

                airlineId = jsonData.getInt("airlineId");
                Optional<Airline> existingAirlineOptional = airlineRepository.findByIsActiveTrueAndAirlineId(airlineId);
                airline = existingAirlineOptional.orElse(null);
                if (airline == null) {
                    m1.put("status", "error");
                    m1.put("error", "no_longer_available");
                    m1.put("message", "Sorry, this airline is not longer available.");
                    return m1;
                }
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field_validation");
                m1.put("message", "Please provide airline identification like airlineId.");
                return m1;
            }

            //staffCode Validation
            if (jsonData.has("staffCode") && !jsonData.get("staffCode").equals("")
                    && jsonData.get("staffCode") != null) {
                staffCode = jsonData.getInt("staffCode");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide staffCode.");
                return m1;
            }

            // staffFullName  Validation
            if (jsonData.has("staffFullName") && !jsonData.get("staffFullName").equals("")
                    && jsonData.get("staffFullName") != null) {
                staffFullName = jsonData.getString("staffFullName");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide staffFullName.");
                return m1;
            }

            // staffSex  Validation
            if (jsonData.has("staffSex") && !jsonData.get("staffSex").equals("")
                    && jsonData.get("staffSex") != null) {
                staffSex = jsonData.getString("staffSex");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide staffSex.");
                return m1;
            }
            // staffAddress  Validation
            if (jsonData.has("staffAddress") && !jsonData.get("staffAddress").equals("")
                    && jsonData.get("staffAddress") != null) {
                staffAddress = jsonData.getString("staffAddress");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide staffAddress.");
                return m1;
            }

            //mobileNum1   Validation
            if (jsonData.has("mobileNum1") && !jsonData.get("mobileNum1").equals("")
                    && jsonData.get("mobileNum1") != null) {
                mobileNum1 = jsonData.getString("mobileNum1");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide mobileNum1.");
                return m1;
            }

            if (jsonData.has("email1") && !jsonData.get("email1").equals("")
                    && jsonData.get("email1") != null) {
                email1 = jsonData.getString("email1");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide email1.");
                return m1;
            }
            if (jsonData.has("mobileNum2") && !jsonData.get("mobileNum2").equals("")
                    && jsonData.get("mobileNum2") != null) {
                mobileNum2 = jsonData.getString("mobileNum2");
            }


            Staff staff = new Staff();
            staff.setAirline(airline);
            staff.setStaffCode(staffCode);
            staff.setStaffSex(staffSex);
            staff.setStaffAddress(staffAddress);
            staff.setStaffFullName(staffFullName);

            staff.setMobileNum1(mobileNum1);
            staff.setMobileNum2(mobileNum2);
            staff.setEmail1(email1);
            staff.setCreationTime(new Timestamp(System.currentTimeMillis()));
            staff.setActive(true);
            staff.setDelete(false);
            String ipAddress = request.getHeader("X-FORWARDED-FOR");
            if (ipAddress == null || ipAddress.isEmpty()) {
                staff.setIpAddress(request.getRemoteAddr());
            }
            staffRepository.save(staff);

            m1.put("status", "success");
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());
            m1.put("StaffId", staff.getStaffId());
            m1.put("StaffSex", staff.getStaffSex());
            m1.put("StaffAddress", staff.getStaffAddress());
            m1.put("StaffCode", staff.getStaffCode());
            m1.put("StaffFullName", staff.getStaffFullName());
            m1.put("MobileNum1", staff.getMobileNum1());
            m1.put("MobileNum2", staff.getMobileNum2());
            m1.put("Email1", staff.getEmail1());
            m1.put("Airline", map);
            m1.put("message", "Staff information saved successfully!!");
            return m1;

        } catch (Exception e) {
            e.printStackTrace();
            m1.put("status", "error");
            m1.put("error", "not_found");
            m1.put("message", "Something went wrong");
            return m1;
        }
    }

    //Update
    public Map<String, Object> updateActiveStaff(String staffData) throws JSONException {
        JSONObject jsonData = new JSONObject(staffData);
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> propertyMap = new HashMap<>();

        Airline airline = new Airline();
        int airlineId = 0;
        Staff staff;
        int staffId = 0;
        try {
            if (jsonData.has("staffId") && jsonData.get("staffId") != null
                    && !jsonData.get("staffId").equals("")) {
                staffId = jsonData.getInt("staffId");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide staffId.");
                return map;
            }
            Optional<Staff> existingStaffOptional = staffRepository.findActiveStaffById(staffId);
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "The Staff Does Not Exist.");
                return map;
            }

            if (!staff.getAirline().isActive() && staff.getAirline().isDelete()) {
                map.put("status", "error");
                map.put("error", "no_longer_available_airportId");
                map.put("message", "Sorry, This Airline id is not Updatable.");
                return map;
            }
            if (jsonData.has("airlineId") && jsonData.get("airlineId") != null
                    && !jsonData.get("airlineId").equals("")) {
                airlineId = jsonData.getInt("airlineId");

                Optional<Airline> existingAirlineOptional = airlineRepository.findByIsActiveTrueAndAirlineId(airlineId);
                if (existingAirlineOptional.isPresent()) {
                    airline = existingAirlineOptional.get();
                    staff.setAirline(airline);
                } else {
                    map.put("status", "error");
                    map.put("error", "no_longer_available");
                    map.put("message", "Sorry, this Airline id is not in the database.");
                    return map;
                }
            }
            if (jsonData.has("staffCode") && jsonData.get("staffCode") != null
                    && !jsonData.get("staffCode").equals("")) {
                staff.setStaffCode(jsonData.getInt("staffCode"));
            }
            // airline Address Update
            if (jsonData.has("staffFullName") && !jsonData.get("staffFullName").equals("")
                    && jsonData.get("staffFullName") != null) {
                staff.setStaffFullName(jsonData.getString("staffFullName"));
            }
            if (jsonData.has("staffSex") && !jsonData.get("staffSex").equals("")
                    && jsonData.get("staffSex") != null) {
                staff.setStaffSex(jsonData.getString("staffSex"));
            }
            if (jsonData.has("staffAddress") && !jsonData.get("staffAddress").equals("")
                    && jsonData.get("staffAddress") != null) {
                staff.setStaffAddress(jsonData.getString("staffAddress"));
            }
            //Staff mobile NUmber Update
            if (jsonData.has("mobileNum1") && !jsonData.get("mobileNum1").equals("")
                    && jsonData.get("mobileNum1") != null) {
                staff.setMobileNum1(jsonData.getString("mobileNum1"));
            }
            if (jsonData.has("mobileNum2") && !jsonData.get("mobileNum2").equals("")
                    && jsonData.get("mobileNum2") != null) {
                staff.setMobileNum2(jsonData.getString("mobileNum2"));
            }

            //Staff Email Update
            if (jsonData.has("email1") && !jsonData.get("email1").equals("")
                    && jsonData.get("email1") != null) {
                staff.setEmail1(jsonData.getString("email1"));
            }

            Staff staffUpdate = staffRepository.save(staff);
            map.put("status", "success");
            map.put("message", "Staff id " + staffId + " Update Confirmed!!!");
            // To Return Staff
            propertyMap.put("Airline Id", staffUpdate.getAirline().getAirlineId());
            propertyMap.put("AirlineName", staffUpdate.getAirline().getAirlineName());
            propertyMap.put("AirlineAddress", staffUpdate.getAirline().getAirlineAddress());
            propertyMap.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            propertyMap.put("MobileNum1", staffUpdate.getAirline().getMobileNum1());
            propertyMap.put("MobileNum2", staffUpdate.getAirline().getMobileNum2());
            propertyMap.put("MobileNum3", staffUpdate.getAirline().getMobileNum3());
            propertyMap.put("Email1", staffUpdate.getAirline().getEmail1());
            propertyMap.put("Email2", staffUpdate.getAirline().getEmail2());
            map.put("getStaffId", staffUpdate.getStaffId());
            map.put("getStaffSex", staffUpdate.getStaffSex());
            map.put("AirportAddress", staffUpdate.getStaffAddress());
            map.put("AirportCountry", staffUpdate.getStaffCode());
            map.put("AirportRegion", staffUpdate.getStaffFullName());
            map.put("MobileNum1", staffUpdate.getMobileNum1());
            map.put("MobileNum2", staffUpdate.getMobileNum2());
            map.put("Email1", staffUpdate.getEmail1());
            map.put("Airline", propertyMap);

        } catch (JSONException e) {
            e.printStackTrace();
            map.put("status", "error");
            map.put("error", "not_found");
            map.put("message", "Something went wrong");
            return map;
        }
        return map;
    }

    public Map<String, Object> findActiveStaffById(int staffId) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findActiveStaffById(staffId);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail1());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + staffId + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid staff Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }


    // Get Active & Delete Records
    public Map<String, Object> getAllStaff() {
        List<Staff> existingStaffOptional = staffRepository.findAll();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail1());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    // Get Active & Delete Staff
    public Map<String, Object> getAllStaffPagination(Pageable pageable) {
        Page<Staff> existingStaffOptional = staffRepository.findAll(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail1());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    // Get Active Records
    public Map<String, Object> getAllActiveStaff() {
        List<Staff> existingStaffOptional = staffRepository.findAllActiveStaff();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail1());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    // Get Active Records
    public Map<String, Object> getAllActiveStaffPagination(Pageable pageable) {
        Page<Staff> existingStaffOptional = staffRepository.findActiveStaffPagination(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail1());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    // Get Deleted Records
    public Map<String, Object> getAllDeletedStaff() {
        List<Staff> existingStaffOptional = staffRepository.findAllDeletedStaff();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail1());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    // Get Deleted Staff Pagination
    public Map<String, Object> getAllDeletedStaffPagination(int page, int size, String sort) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sort));
        Page<Staff> existingStaffOptional = staffRepository.findAllDeletedStaffPagination(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail1());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    //HARD DELETE
    public Map<String, Object> delStaffHard(int staffId) {
        Map<String, Object> map = new HashMap<>();

        Optional<Staff> existingStaffOptional = staffRepository.findById(staffId);

        try {
            if (existingStaffOptional.isPresent()) {
                staffRepository.deleteById(staffId);
                map.put("status", "success");
                map.put("message", "Staff id " + staffId + " deletion Confirmed!!");
                return map;
            } else {
                map.put("status", "error");
                map.put("error", "no_longer_available");
                map.put("message", "Sorry, this Staff " + staffId + " does not Existed.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Invalid Staff Id");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }

    // Delete By Id Soft Delete
    public Map<String, Object> deleteStaffById(int staffId) {
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            Optional<Staff> existingStaffOptional = staffRepository.findActiveStaffById(staffId);
            if (existingStaffOptional.isPresent()) {
                Staff staff = existingStaffOptional.get();
                staff.setDelete(true);
                staff.setActive(false);
                staff.setDeletionTime(new Timestamp(System.currentTimeMillis()));
                staffRepository.save(staff);
                propertyMap.put("status", "success");
                propertyMap.put("message", "Staff soft deletion Confirmed!!");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "Staff_no_longer_available");
                propertyMap.put("message", "Sorry, this Staff" + staffId + " is not Existed.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Staff Id ");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> revertStaff(int staffId) {
        Map<String, Object> map = new HashMap<>();

        try {
            Optional<Staff> existingStaffOptional = staffRepository.findById(staffId);
            if (existingStaffOptional.isPresent()) {
                Staff staff = existingStaffOptional.get();

                if (!staff.isActive() && staff.isDelete()) {
                    staff.setDelete(false);
                    staff.setActive(true);
                    staff.setDeletionTime(null);
                    staffRepository.save(staff);
                    map.put("status", "success");
                    map.put("message", "Staff " + staffId + " Revert Confirmed!!");
                    return map;
                } else {
                    map.put("status", "error");
                    map.put("error", "Staff can't be Reverted.");
                    return map;
                }
            } else {
                map.put("status", "error");
                map.put("error", "Staff " + staffId + " is not Present.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Please Check Again.");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }


}

