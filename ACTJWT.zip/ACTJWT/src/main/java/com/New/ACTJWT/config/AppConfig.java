package com.New.ACTJWT.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

@Configuration
public class AppConfig {

    @Bean
    public UserDetailsService userDetailsService() {

        UserDetails userAdmin = User.builder().username("Admin").password(passwordEncoder().encode("admin")).roles("ADMIN").build();
        UserDetails userKrishna = User.builder().username("Krishna").password(passwordEncoder().encode("krishna")).roles("ADMIN").build();
        UserDetails userGuest = User.builder().username("Guest").password(passwordEncoder().encode("guest")).roles("ADMIN").build();
        return new InMemoryUserDetailsManager(userAdmin, userGuest, userKrishna);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration builder) throws Exception {
        return builder.getAuthenticationManager();
    }
}
