package com.New.ACTJWT.controller;


import com.New.ACTJWT.service.DriverService;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@RestController
@RequestMapping("drivers")
public class DriverController {

    @Autowired
    DriverService driverService;

    @PostMapping("add")
    public Map<String, Object> addDriver(@RequestParam String driverData,
                                         @RequestParam("licImg") MultipartFile licImg,
                                         @RequestParam MultipartFile idProof,
                                         HttpServletRequest request) throws JSONException {
        return driverService.addDriver(driverData, licImg, idProof, request);
    }

    @PostMapping("addRequestBody")
    public Map<String, Object> addDriverRequestBody(@RequestBody String driverData,
                                                    @RequestParam("licImg") MultipartFile licImg,
                                                    @RequestParam MultipartFile idProof,
                                                    HttpServletRequest request) throws JSONException {
        return driverService.addDriver(driverData, licImg, idProof, request);
    }

    // Get all Airlines with Deleted
    @GetMapping("/allDrivers")
    public Map<String, Object> getAllDrivers() {
        return driverService.getAllDrivers();
    }

    @GetMapping("/allDriversPagination")
    public Map<String, Object> getAllDriversPagination(@RequestParam(defaultValue = "0") int page,
                                                       @RequestParam(defaultValue = "10") int size,
                                                       @RequestParam(defaultValue = "airlineId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).descending().and(Sort.by("driverId")));
        return driverService.getAllDriversPagination(pageable);
    }

    // Active Records
    @GetMapping("/allActiveDrivers")
    public Map<String, Object> getAllActiveDrivers() {
        return driverService.getAllActiveDrivers();
    }

    // Active Records
    @GetMapping("/allActiveDriversPagination")
    public Map<String, Object> getAllActiveDriversPagination(@RequestParam(defaultValue = "0") int page,
                                                             @RequestParam(defaultValue = "5") int size,
                                                             @RequestParam(defaultValue = "driverId") String sortBy) {
        return driverService.getAllActiveDriversPagination(page, size, sortBy);
    }

    @GetMapping("getByIdAll")
    public Map<String, Object> getDriverById(@RequestParam(name = "driverId") int driverId) {
        return driverService.getDriverById(driverId);
    }
    // Get Only Active Records
    @GetMapping("getById")
    public Map<String, Object> getActiveDriverById(@RequestParam(name = "driverId") int driverId) {
        return driverService.getActiveDriverById(driverId);
    }

    // Delete Records
    @GetMapping("/allDeleteDrivers")
    public Map<String, Object> getAllDeleteDrivers() {
        return driverService.getAllDeleteDrivers();
    }

    // Delete Records
    @GetMapping("/allDeleteDriversPagination")
    public Map<String, Object> getAllDeleteDriversPagination(@RequestParam(defaultValue = "0") int page,
                                                             @RequestParam(defaultValue = "10") int size,
                                                             @RequestParam(defaultValue = "driverId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).ascending().and(Sort.by("driverSex")));
        return driverService.getAllDeleteDriversPagination(pageable);
    }

    // Form-data (Body) -> Multipath , Request Body -> raw(body)
    @PostMapping("update")
    public Map<String , Object> updateActiveDriver(@RequestParam(required = false) MultipartFile licImg,
                                                   @RequestParam(required = false) MultipartFile idProof,
                                                   @RequestBody String driverData) throws JSONException {
        MultipartFile idProofFile = idProof != null && !idProof.isEmpty() ? idProof : null;
        MultipartFile licImgFile = licImg != null && !licImg.isEmpty() ? licImg : null;
        return driverService.updateActiveDriver(driverData,licImgFile,idProofFile);
    }

    @DeleteMapping("/delById")
    public Map<String, Object> delDriverById(@RequestParam int driverId) {
        return driverService.delActiveDriverById(driverId);
    }

    @DeleteMapping("/hardDelById")
    public Map<String, Object> hardDelDriverById(@RequestParam int driverId) {
        return driverService.delDriverById(driverId);
    }

    @PutMapping("/revertById")
    public Map<String, Object> revertAirline(@RequestParam int driverId) {
        return driverService.revertDriverById(driverId);
    }

}