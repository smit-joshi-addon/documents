package com.New.ACTJWT.controller;

import com.New.ACTJWT.service.VehicleService;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("vehicle")
public class VehicleController {
    @Autowired
    VehicleService vehicleService;

    @PostMapping("add")
    public Map<String,Object> addVehicle(@RequestBody String vehicleData, HttpServletRequest request) throws JSONException {
        return vehicleService.addVehicle(vehicleData,request);
    }

    //Update the Vehicle
    @PutMapping("/update")
    public Map<String ,Object> updateVehicleById(@RequestBody String vehicleData) throws JSONException {
        return vehicleService.updateVehicleById(vehicleData);
    }

    /*http://localhost:8080/airlines/getById?alId=1*/
    @GetMapping("getById")
    public Map<String, Object> getVehicleById(@RequestParam(name = "vehicleId") int vehicleId) {
        return vehicleService.getVehicleById(vehicleId);
    }

    // Only Get When Id Is Active
    @GetMapping("Auto/getByActiveVehicleId")
    public Map<String, Object> getActiveVehicleById(@RequestParam int airlineId) {
        return vehicleService.getActiveVehicleById(airlineId);
    }

    // Get all Airlines with Deleted
    @GetMapping("/allVehicles")
    public Map<String, Object> getAllVehicles() {
        return vehicleService.getAllVehicles();
    }

    // Get all Airlines without Deleted
    @GetMapping("/allActiveVehicles")
    public Map<String, Object> getAllActiveVehicles() {
        return vehicleService.getAllActiveVehicles();
    }

    // Get all Airlines without Deleted
    @GetMapping("/allDeleteVehicles")
    public Map<String, Object> getAllDeleteVehicles() {
        return vehicleService.getAllDeleteVehicles();
    }

    //Pagination Get all Vehicles with Deleted
    // If With Path Variable  @GetMapping("/allAirlinesPagination" or "/allAirlinesPagination/{page}...)
    @GetMapping("/allActiveAirlinesPagination")
    public Map<String, Object> getAllActiveVehiclePagination(@RequestParam(defaultValue = "0") int page,
                                                        @RequestParam(defaultValue = "5") int size,
                                                        @RequestParam(defaultValue = "vehicleId") String sortBy) {
        return vehicleService.getAllActiveVehiclesPagination(page,size,sortBy);
    }

    @GetMapping("/allAirlinesPagination")
    public Map<String, Object> getAllVehiclePagination(@RequestParam(defaultValue = "0") int page,
                                                             @RequestParam(defaultValue = "5") int size,
                                                             @RequestParam(defaultValue = "vehicleId") String sort) {
        Pageable pageable = PageRequest.of(page,size, Sort.by(sort).descending());
        return vehicleService.getAllVehiclesPagination(pageable);
    }


    @DeleteMapping("deleteById")
    public Map<String,Object> delVehicleById(@RequestParam int vehicleId){
        return vehicleService.delVehicleById(vehicleId);
    }
    @DeleteMapping("deleteHard")
    public Map<String,Object> delVehicleHard(@RequestParam int vehicleId){
        return vehicleService.delVehicleIdHard(vehicleId);
    }

    @PutMapping("revertById")
    public Map<String,Object> revertVehicleById(@RequestParam int vehicleId){
        return vehicleService.revertVehicleById(vehicleId);
    }



}
