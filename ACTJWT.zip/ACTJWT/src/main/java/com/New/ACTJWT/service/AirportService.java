package com.New.ACTJWT.service;

import com.New.ACTJWT.Repository.AirportRepository;
import com.New.ACTJWT.model.Airport;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.*;

@Service
public class AirportService {
    @Autowired
    AirportRepository airportRepository;

    private Airport al = new Airport();

    //Insert
   /* public String addAirline(Airline airline, HttpServletRequest request){
        //To get the client ip
        String ipAddress = request.getHeader("X-FORWARDED-FOR");
        if(ipAddress == null || ipAddress.isEmpty()){
            airline.setIpAddress(request.getRemoteAddr());
        }

        *//*String ipAddress = request.getHeader("X-FORWARDED-FOR");

                if (ipAddress == null || ipAddress.isEmpty()) {
                     String remoteAddr = request.getRemoteAddr();

                  // Check if it's an IPv6 loopback address and convert to IPv4
                    if (remoteAddr.equals("0:0:0:0:0:0:0:1")) {
                          InetAddress inetAddress;
                          try {
                              inetAddress = InetAddress.getLocalHost();
                              remoteAddr = inetAddress.getHostAddress();
                          } catch (UnknownHostException e) {
                       e.printStackTrace(); // Handle the exception as needed
                   }
               }
                airline.setIpAddress(remoteAddr);
            }*//*
            // Rest of your method...

        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
        airline.setCreationTime(currentTimestamp);
        alRepo.save(airline);
        return "Created";
    }
*/
    //Inserted
   /* public  addAirline(Airline airline, HttpServletRequest request){
        //To get the client ip
        String ipAddress = request.getHeader("X-FORWARDED-FOR");
        if(ipAddress == null || ipAddress.isEmpty()){
            airline.setIpAddress(request.getRemoteAddr());
        }
        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
        airline.setCreationTime(currentTimestamp);
        alRepo.save(airline);
        return "Created";
    }*/

    //Json Validation insertion
    public Map<String, Object> addAirport(String airportData, HttpServletRequest request) throws JSONException {
        JSONObject jsonData = new JSONObject(airportData);
        Map<String, Object> m1 = new HashMap<String, Object>();

        Airport airport = new Airport();
        int airportId = 0;
        String IATACode = null;
        String airportAddress = null;
        String airportCountry = null;
        String airportRegion = null;

        try {
            //Iata Code Validation
            if (jsonData.has("IATACode") && !jsonData.get("IATACode").equals("")
                    && jsonData.get("IATACode") != null) {
                IATACode = jsonData.getString("IATACode");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide iatacode.");
                return m1;
            }

            // Airport Address Validation
            if (jsonData.has("airportAddress") && !jsonData.get("airportAddress").equals("")
                    && jsonData.get("airportAddress") != null) {
                airportAddress = jsonData.getString("airportAddress");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide airport address.");
                return m1;
            }

            // Airport Country Validation
            if (jsonData.has("airportCountry") && !jsonData.get("airportCountry").equals("")
                    && jsonData.get("airportCountry") != null) {
                airportCountry = jsonData.getString("airportCountry");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide Airport Country.");
                return m1;
            }

            if (jsonData.has("airportRegion") && !jsonData.get("airportRegion").equals("")
                    && jsonData.get("airportRegion") != null) {
                airportRegion = jsonData.getString("airportRegion");
            }
            // airport.setApRegion(jsonData.getString("apRegion"));
            airport.setAirportId(airportId);
            airport.setIATACode(IATACode);
            airport.setAirportAddress(airportAddress);
            airport.setAirportCountry(airportCountry);
            airport.setAirportRegion(airportRegion);
            airport.setCreationTime(new Timestamp(System.currentTimeMillis()));
            airport.setActive(true);
            airport.setDelete(false);
            String ipAddress = request.getHeader("X-FORWARDED-FOR");
            if (ipAddress == null || ipAddress.isEmpty()) {
                airport.setIpAddress(request.getRemoteAddr());
            }
            airportRepository.save(airport);

            m1.put("status", "success");
            m1.put("message", "Airport information saved successfully!!");
            return m1;

        } catch (Exception e) {
            e.printStackTrace();
            m1.put("status", "error");
            m1.put("error", "not_found");
            m1.put("message", "Something went wrong");
            return m1;
        }
    }

    //Update The Airport
    public Map<String, Object> updateAirportById(String airportData) throws JSONException {
        JSONObject jsonData = new JSONObject(airportData);
        Map<String, Object> map = new HashMap<>();
        int airportId = 0;
        Airport airport;

        try {
            if (jsonData.has("airportId") && jsonData.get("airportId") != null
                    && !jsonData.get("airportId").equals("")) {
                airportId = jsonData.getInt("airportId");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide airportId.");
                return map;
            }
            Optional<Airport> existingAirportOptional = airportRepository.findById(airportId);
            if (existingAirportOptional.isPresent()) {
                airport = existingAirportOptional.get();
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "The Airport Does Not Exist.");
                return map;
            }
            if (airport.isActive() == true && airport.isDelete() == false) {
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "AirlineId is Soft Delete.");
                return map;
            }
            if (jsonData.has("IATACode")) {
                if (!jsonData.get("IATACode").equals("") && !jsonData.get("IATACode").equals(null) && jsonData.get("IATACode") != null) {
                    airport.setIATACode(jsonData.getString("IATACode"));
                    //existingAirportOptional.get().setIATACode(jsonData.getString("IATACode"));
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper IATACode.");
                    return map;
                }
            }
            if (jsonData.has("airportAddress")) {
                if (!jsonData.get("airportAddress").equals("") && !jsonData.get("airportAddress").equals(null) && jsonData.get("airportAddress") != null) {
                    airport.setAirportAddress(jsonData.getString("airportAddress"));
                    // existingAirportOptional.get().setApAddress(jsonData.getString("apAddress"));
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper airportAddress.");
                    return map;
                }
            }
            if (jsonData.has("airportCountry")) {
                if (!jsonData.get("airportCountry").equals("") && !jsonData.get("airportCountry").equals(null) && jsonData.get("airportCountry") != null) {
                    airport.setAirportCountry(jsonData.getString("airportCountry"));
                    //existingAirportOptional.get().setApCountry(jsonData.getString("apCountry"));
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper airportCountry.");
                    return map;
                }
            }
            if (jsonData.has("airportRegion")) {
                if (!jsonData.get("airportRegion").equals("") && !jsonData.get("airportRegion").equals(null) && jsonData.get("airportRegion") != null) {
                    airport.setAirportRegion(jsonData.getString("airportRegion"));
                    //existingAirportOptional.get().setApRegion(jsonData.getString("apRegion"));
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper airportRegion.");
                    return map;
                }
            }
            airportRepository.save(airport);
            map.put("status", "success");
            map.put("message", "Airline id " + airportId + " Update Confirmed!!!");

            // Record Show With Only Required Field
            map.put("Airport_id", airport.getAirportId());
            map.put("IATACode", airport.getIATACode());
            map.put("ApAddress", airport.getAirportAddress());
            map.put("airportCountry", airport.getAirportCountry());
            map.put("ApRegion", airport.getAirportRegion());
            //map.put("Airport Record ", airport);
        } catch (
                Exception e) {
            e.printStackTrace();
            map.put("status", "error");
            map.put("error", "not_found");
            map.put("message", "Something went wrong");
            return map;
        }
        return map;
    }


//Get By ID Function
    /*public Optional<Airline> getAirlineById(Integer alId)
    {
        return alRepo.findById(alId);
    }

    //Get all the airline details
    public List<Airline> getAllAirlines() {
        return alRepo.findAll();
    }

    // Fetch data for the deleted record through method
    *//*public List<Airline> getDeletedRecords() {
        return alRepo.findByIsDeleteTrue();
    }*//*

    // Get Active Records
    public List<Airline> getActiveRecords(){
        return alRepo.findActiveRecords();
    }

    // Get The Soft Deleted Records
    public List<Airline> getDeletedRecords() {
        return alRepo.findDeletedRecords();
    }

    // This method is for the update but update the given field and other will be null
    *//*public Airline updateAirline(Integer alId , Airline airline){
        al = alRepo.findById(alId).get();
        System.out.println(al);

        if(Objects.nonNull(al.getAirlineId())){
            airline.setAirlineId(alId);
        }
        return alRepo.save(airline);
    }*//*

    public Airline updateAirline(Integer alId , Airline airline){
        al = alRepo.findById(alId).get();

        if(Objects.nonNull(al.getAirlineId())){
            al.setAirlineName(airline.getAirlineName());
           }
        return alRepo.save(al);
    }
    @Transactional
    public void revertById(Integer alId){
        alRepo.revert(alId);
    }
    @Transactional
    public void revertByIdN(Integer alId) {
        alRepo.revertN(alId);
    }

    // Delete By Id
    public Airline delAirlineById(Integer alId) {

        al = airportRepository.findById(alId).get();
        if(Objects.nonNull(al.getAirportId())){
            al.setDelete(true);
            al.setActive(false);
            Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
            al.setDeletionTime(currentTimestamp);
        }
        return airportRepository.save(al);

    }*/

    //Get One Record By Id.
    public Map<String, Object> getAirportById(int apId) {
        Airport airport;
        Optional<Airport> existingAirportOptional = airportRepository.findById(apId);
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            if (existingAirportOptional.isPresent()) {
                airport = existingAirportOptional.get();
                propertyMap.put("Airport_id", airport.getAirportId());
                propertyMap.put("IATACode", airport.getIATACode());
                propertyMap.put("ApAddress", airport.getAirportAddress());
                propertyMap.put("airportCountry", airport.getAirportCountry());
                propertyMap.put("ApRegion", airport.getAirportRegion());
                //propertyMap.put("getCreationTime", airport.getCreationTime());
                //propertyMap.put("Is_Active", airport.isActive());
                //propertyMap.put("Is_Delete", airport.isDelete());
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Airport" + apId + " is not longer available.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Airport Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    //Get All The Records.
    public Map<String, Object> getAllAirports() {
        List<Airport> existingAirportOptional = airportRepository.findAll();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingAirportOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Airport airport : existingAirportOptional) {
            //to assign for each airport
            propertyMap2 = new HashMap<>();
            propertyMap2.put("Airport_id", airport.getAirportId());
            propertyMap2.put("IATACode", airport.getIATACode());
            propertyMap2.put("ApAddress", airport.getAirportAddress());
            propertyMap2.put("ApCountry", airport.getAirportCountry());
            propertyMap2.put("ApRegion", airport.getAirportRegion());
            data.add(propertyMap2);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Airport", data);
        return propertyMap;

    }


//Delete All Airlines
   /* public String delAllAirlines(){
        airportRepository.deleteAll();
        return "All Airline Got Deleted";
    }*/

    // Soft Delete By Id.
    public Map<String, Object> delAirportById(int apId) {
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            Optional<Airport> existingAirportOptional = airportRepository.findActiveByAirportId(apId);
            if (existingAirportOptional.isPresent()) {
                Airport airport = existingAirportOptional.get();
                airport.setDelete(true);
                airport.setActive(false);
                airport.setDeletionTime(new Timestamp(System.currentTimeMillis()));
                airportRepository.save(airport);
                propertyMap.put("status", "success");
                propertyMap.put("message", "Airport soft deletion Confirmed!!");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Airport" + apId + " is not Existed.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Airport Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    // HARD Delete
    public Map<String, Object> delAirportHard(int apId) {
        Map<String, Object> map = new HashMap<>();

        Optional<Airport> existingAirportOptional = airportRepository.findById(apId);

        try {
            if (existingAirportOptional.isPresent()) {
                //airportRepository.deleteById(apId);
                airportRepository.deleteById(existingAirportOptional.get().getAirportId());
                map.put("status", "success");
                map.put("message", "Airport id " + apId + " deletion Confirmed!!");
                return map;
            } else {
                map.put("status", "error");
                map.put("error", "no_longer_available");
                map.put("message", "Sorry, this Airport " + apId + " does not Existed.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Invalid Airport Id");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }

    // Revert the record that are only soft deleted
    public Map<String, Object> revertAirport(int apId) {
        Map<String, Object> map = new HashMap<>();

        try {
            Optional<Airport> existingAirportOptional = airportRepository.findById(apId);
            if (existingAirportOptional.isPresent()) {
                Airport airport = existingAirportOptional.get();

                if (airport.isActive() == false && airport.isDelete() == true) {
                    airport.setDelete(false);
                    airport.setActive(true);
                    airport.setDeletionTime(null);
                    airportRepository.save(airport);
                    map.put("status", "success");
                    map.put("message", "Airport " + apId + " Revert Confirmed!!");
                    return map;
                } else {
                    map.put("status", "error");
                    map.put("error", "Airport can't be Reverted.");
                    return map;
                }
            } else {
                map.put("status", "error");
                map.put("error", "Airport " + apId + " field is invalid input.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Please Check Again.");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }

    // Get Soft Delete Records NATIVE Query
    public Map<String, Object> findSoftDelAirports() {
        Map<String ,Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String,Object>> data = new ArrayList<>();
        List<Airport> airports = airportRepository.findSoftDelAirports();

        if(airports.isEmpty()){
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "data not found");
            return map;
        }

        for(Airport airport :airports){
            map2= new HashMap<>();
            map2.put("Airport_id", airport.getAirportId());
            map2.put("IATACode", airport.getIATACode());
            map2.put("ApAddress", airport.getAirportAddress());
            map2.put("ApCountry", airport.getAirportCountry());
            map2.put("ApRegion", airport.getAirportRegion());
            data.add(map2);
            System.out.println("\nProperty Map ====\n"+map2);
            System.out.println("\n Data"+data);
        }

        map.put("Airports",data);
        map.put("status", "success");
        return map;
    }

    //Get Only Active Record through Jpql Query
    public Map<String, Object> findActiveAirports() {
        Map<String ,Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String,Object>> data = new ArrayList<>();
        List<Airport> airports = airportRepository.findActiveAirports();

        if(airports.isEmpty()){
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There Not Any Active Record.");
            return map;
        }

        for(Airport airport :airports){

            map2= new HashMap<>();
            map2.put("Airport_id", airport.getAirportId());
            map2.put("IATACode", airport.getIATACode());
            map2.put("ApAddress", airport.getAirportAddress());
            map2.put("ApCountry", airport.getAirportCountry());
            map2.put("ApRegion", airport.getAirportRegion());
            data.add(map2);
        }

        map.put("Airports",data);
        map.put("status", "success");
        return map;
    }

    //public List<Map<String,Object>> projectionNative()
}

