package com.New.ACTJWT.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import lombok.*;

import java.sql.Timestamp;

@Getter
@Setter
@AllArgsConstructor
@Data
@NoArgsConstructor
@Entity
@Table(name = "driver")
public class Driver {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "driver_id")
    private int driverId;
    @Column(name = "driver_name")
    private String driverName;
    @Column(name = "driver_sex")
    private String driverSex;
    @Column(name = "licence_num")
    private String licenceNum;
    @Column(name = "licence_img")
    private String licenceImg; //Image
    @Column(name = "id_proof")
    private String idProof; //Image

    @Column(name = "mobile_num1")
    //@Pattern(regexp = "^[0-9]{10}$", message = "Please provide a valid 10-digit mobile number")
    private String mobileNum1;
    @Column(name = "mobile_num2")
    private String mobileNum2;

    @Column(name = "email1")
    @Email(message = "Please provide a valid email address")
    private String email1;


    //Common Columns
    @Column(name = "creation_time")
    private Timestamp creationTime;
    @Column(name = "deletion_time")
    private Timestamp deletionTime;
    @Column(name = "is_active")
    private boolean isActive;
    @Column(name = "is_delete")
    private boolean isDelete;
    @Column(name = "ip_address")
    private String ipAddress;


    @ManyToOne
    @JoinColumn(name = "branch_id")
    private Branch branch;

    @ManyToOne
    @JoinColumn(name = "vehicle_id")
    private Vehicle vehicle;


}
