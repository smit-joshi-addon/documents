package com.New.ACTJWT.controller;

import com.New.ACTJWT.service.AirportService;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController

@RequestMapping("airports")
public class AirportController {

    @Autowired
    AirportService airportService;

    //Insert
    @PostMapping("/add")
    public Map<String, Object> addAirport(@RequestBody String airportData, HttpServletRequest request) throws JSONException {
        return airportService.addAirport(airportData,request);
    }

    //Insert Through Request Param
    //http://localhost:8080/airports/addByParam Body-> FormData
    @PostMapping("/addByParam")
    public Map<String, Object> addAirportByParam(@RequestParam String airportData, HttpServletRequest request) throws JSONException {
       // System.out.println("Airport Data "+airportData);

        return airportService.addAirport(airportData,request);
    }

    // Get One Record By Id.
    //http://localhost:8080/airports/1
    @GetMapping("/{apId}")
    public Map<String, Object> getAirportById(@PathVariable int apId){
        return airportService.getAirportById(apId);
    }

    //Work in both param & form-data
    //http://localhost:8080/airports/getAirportByParam?apId=1
    @GetMapping("/getAirportByParam")
    public Map<String, Object> getAirportByParam(@RequestParam int apId){
        return airportService.getAirportById(apId);
    }

    //Only pass value as 10
    @GetMapping("/getAirportByBody")
    public Map<String, Object> getAirportByBody(@RequestBody int apId){
        //System.out.println("data"+data);
        //System.out.println("tri"+tri);
        return airportService.getAirportById(apId);
    }

    //Get All The Airports.
    @GetMapping("/getAirports")
    public Map<String, Object> getAllAirports(){
        return airportService.getAllAirports();
    }

    //Update the Airport
    @PutMapping("/update")
    public Map<String ,Object> updateAirportById(@RequestBody String airportData) throws JSONException {
        return airportService.updateAirportById(airportData);
    }

    //Revert
    @PutMapping("/{apId}")
    public Map<String,Object> revertAirport(@PathVariable int apId){
        return airportService.revertAirport(apId);
    }

    // Soft Delete
    @DeleteMapping("delete/{apId}")
    public Map<String,Object> delAirportByID(@PathVariable int apId) {
        return airportService.delAirportById(apId);
    }

    //Hard Delete
    @DeleteMapping("/{apId}")
    public Map<String,Object> delAirportHard(@PathVariable int apId){
        return airportService.delAirportHard(apId);
    }


    //Return ALl the records that are soft Deleted.
    @GetMapping("softDelAirports")
    public Map<String ,Object> findSoftDelAirports(){
        return airportService.findSoftDelAirports();
    }
    //Return Only Active Record JPQL Query.
    @GetMapping("activeAirports")
    public Map<String ,Object> findActiveAirports(){
        return airportService.findActiveAirports();
    }

    @PostMapping("test")
    public String test(@RequestParam String a ){
        //Pass In the Param
        // Request Body In the raw

      //  System.out.println("Airport---"+airport);
        System.out.println("Num---"+a);
        return null;
    }
}
