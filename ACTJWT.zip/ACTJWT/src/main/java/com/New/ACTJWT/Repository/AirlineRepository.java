package com.New.ACTJWT.Repository;

import com.New.ACTJWT.model.Airline;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import java.util.List;
import java.util.Optional;

@Repository
public interface AirlineRepository extends JpaRepository<Airline, Integer> {

    Airline findByAirlineId(int alId);
    @Query("select a from Airline a where a.airlineId=?1")
    Airline findByAirlineIdJPQL(int alId);
    @Query(value = "select * from airline where airline_id=:alId", nativeQuery = true)
    Airline findByAirlineIdNative(int alId);

    List<Airline> findByAirlineName(String alName);
    @Query("select a from Airline a where a.airlineName=:alName")
    List<Airline> findByAirlineNameJPQL(String alName);
    @Query(value = "select * from airline where airline_name=?1", nativeQuery = true)
    List<Airline> findByAirlineNameNative(String alName);
    
    List<Airline> findByAirlineAddress(String alAddress);
    @Query("select a from Airline a where a.airlineAddress = ?1")
    List<Airline> findByAirlineAddressJPQL(String alAddress);
    @Query(value = "select * from airline where airline_address = ?1",nativeQuery = true)
    List<Airline> findByAirlineAddressNative(String alAddress);


    List<Airline> findByAirlineNameIgnoreCaseAndAirport_AirportId(String name ,int id);
    @Query(value = "select a.* from airline a join airport ap ON a.airport_id = ap.airport_id AND LOWER(a.airline_name) =LOWER(?1) AND ap.airport_id=?2",nativeQuery = true)
    List<Airline> findByAirlineNameAndAirportIdNative(String name ,int id);
    @Query("SELECT a FROM Airline a JOIN a.airport ap WHERE LOWER(a.airlineName) = LOWER(?1) AND ap.airportId = ?2")
    List<Airline> findByAirlineNameAndAirportIdJPQL(String name ,int id);


    List<Airline> findByAirlineNameContainingAndAirport_AirportCountry(String name ,String country);


    //List<Airline> findDistinctByAirlineName();
    List<Airline> findByMobileNum1OrMobileNum2OrMobileNum3(String mobNum,String mobNum2, String mobNum3);
    @Query("select a from Airline a where a.mobileNum1=:mobNum or a.mobileNum2 =:mobNum or a.mobileNum3=:mobNum")
    List<Airline> findByMobileNumJPQL(String mobNum);
    @Query(value = "select * from Airline where mobileNum1=:mobNum or mobileNum2 =:mobNum or mobileNum3=:mobNum",nativeQuery = true)
    List<Airline> findByMobileNumNative(String mobNum);

    /**
     * @param email
     * @return list
     */
    @Query("select a from Airline a  where a.email1=:email or a.email2 =:email")
    List<Airline> findByAirlineEmailJPQL(String email);
    @Query(value = "select * from airline  where email1=:email or email2 =:email",nativeQuery = true)
    List<Airline> findByAirlineEmailNative(String email);

    List<Airline> findByAirport_AirportRegionIsNull();

    // Pagination Method for the get method

    //Fetch the record that are deleted with pagination and Sorting
    // query -->  select a1_0.airline_id,a1_0.airport_id from airline a1_0 where a1_0.is_delete order by a1_0.airline_id desc,a1_0.airport_id offset ? rows fetch first ? rows only
    Page<Airline> findByIsDeleteTrue(Pageable pageable);
    //Through query
    @Query("select a from Airline a where a.isDelete= true and a.isActive = false")
    List<Airline> findDeletedAirlines();
    @Query(value = "select * from airline where is_delete= true and is_active = false",nativeQuery = true)
    List<Airline> findDeletedAirlinesNative();

    Optional<Airline> findByIsActiveTrueAndAirlineId(int airlineId);
    // Get the record that are not deleted.
    @Query("select a from Airline a where a.isDelete=false and a.isActive= true")
    List<Airline> findActiveAirlines();
    // Get the record that are not deleted.
    @Query(value = "select * from airline where is_delete=false and is_active= true",nativeQuery = true)
    List<Airline> findActiveAirlinesNative();

    @Modifying
    @Query("update Airline a set a.isActive=true, a.isDelete = false where a.isDelete = true and a.airlineId =:alId")
    public void revert(@Param("alId") Integer alId);

    @Modifying
    @Query(value ="update Airline set is_active = true , is_delete=false where is_delete = true and airline_id = :alId", nativeQuery = true)
    public void revertN(@Param("alId") Integer alId);

    @Query(value = "select a.airline_id, a.airline_name from airline a",nativeQuery = true)
    public List<Object[]> joinQuery();

    @Query(value = "select a.airline_id, a.airline_name, a.airline_address, ap.airport_id, ap.iata_code from airline a join airport ap ON a.airport_id = ap.airport_id AND a.airline_id =?1",nativeQuery = true)
    public List<Object[]> projectionJoin(int airlineId);
}
