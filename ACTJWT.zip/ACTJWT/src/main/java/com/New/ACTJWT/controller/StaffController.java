package com.New.ACTJWT.controller;

import com.New.ACTJWT.service.StaffService;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("staff")
public class StaffController {
    @Autowired
    StaffService staffService;

    @PostMapping("add")
    public Map<String, Object> addStaff(@RequestBody String staffData, HttpServletRequest request) throws JSONException {
        return staffService.addStaff(staffData, request);
    }

    // Update Only when Active
    @PutMapping("/updateActiveById")
    public Map<String, Object> updateActiveStaff(String staffData) throws JSONException {
        return staffService.updateActiveStaff(staffData);
    }

    //Get By Id Active
    @GetMapping("/getById")
    public Map<String, Object> findActiveStaffById(@RequestParam int driverId) {
        return staffService.findActiveStaffById(driverId);
    }

    // Get all Staff with Deleted
    @GetMapping("/allStaff")
    public Map<String, Object> getAllStaff() {
        return staffService.getAllStaff();
    }

    // Get all Airlines without Deleted
    @GetMapping("/allActiveStaff")
    public Map<String, Object> getAllActiveStaff() {
        return staffService.getAllActiveStaff();
    }

    // Get all Airlines without Deleted
    @GetMapping("/allDeleteStaff")
    public Map<String, Object> getAllDeletedStaff() {
        return staffService.getAllDeletedStaff();
    }

    //Pagination Get all Vehicles with Deleted
    // If With Path Variable  @GetMapping("/allStaffPagination" or "/allAirlinesPagination/{page}...)
    @GetMapping("/allActiveStaffPagination")
    public Map<String, Object> getAllActiveStaffPagination(@RequestParam(defaultValue = "0") int page,
                                                             @RequestParam(defaultValue = "5") int size,
                                                             @RequestParam(defaultValue = "staffId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).descending());
        return staffService.getAllActiveStaffPagination(pageable);
    }

    @GetMapping("/allDeleteStaffPagination")
    public Map<String, Object> getAllDeleteStaffPagination(@RequestParam(defaultValue = "0") int page,
                                                           @RequestParam(defaultValue = "5") int size,
                                                           @RequestParam(defaultValue = "staffId") String sortBy) {
        return staffService.getAllDeletedStaffPagination(page, size, sortBy);
    }

    @GetMapping("/allStaffPagination")
    public Map<String, Object> getAllVehiclePagination(@RequestParam(defaultValue = "0") int page,
                                                       @RequestParam(defaultValue = "5") int size,
                                                       @RequestParam(defaultValue = "staffId") String sort) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sort).descending());
        return staffService.getAllStaffPagination(pageable);
    }


    //Soft Delete Through Method
    @DeleteMapping("/deleteById")
    public Map<String, Object> deleteStaffById(@RequestParam int staffId) {
        return staffService.deleteStaffById(staffId);
    }

    //Hard Delete Through Method
    @DeleteMapping("/deleteHard")
    public Map<String, Object> deleteStaffByIdHard(@RequestParam int staffId) {
        return staffService.delStaffHard(staffId);
    }

    //Revert Through Method
    @PutMapping("/revertById")
    public Map<String, Object> revertStaff(@RequestParam int staffId) {
        return staffService.revertStaff(staffId);
    }
}
