package com.New.ACTJWT.Repository;

import com.New.ACTJWT.model.Branch;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BranchRepository extends JpaRepository<Branch, Integer> {

    //Fetch the record that are deleted
    List<Branch> findByIsDeleteTrue();
    @Query("select b from Branch b where b.isDelete=true and b.isActive=false")
    List<Branch> findDeletedBranches();

    @Query("select b from Branch b where b.isDelete=true and b.isActive=false")
    Page<Branch> findDeletedBranchesPagination(Pageable pageable);

    @Query(value = "select * from Branch b where b.is_delete=false and b.is_active=true",nativeQuery = true)
    List<Branch> findActiveBranches();

    @Query(value = "select * from Branch b where b.is_delete=false and b.is_active=true",nativeQuery = true)
    Page<Branch> findActiveBranchesPagination(Pageable pageable);

    @Query(value = "select * from Branch b where b.is_delete= false and b.is_active= true and b.branch_id = :branchId",nativeQuery = true)
    Optional<Branch> findActiveBranchById(int branchId);

    //Through query

    @Modifying
    @Query("update Branch b set b.isActive=true, b.isDelete = false where b.isDelete = true and b.branchId =:brId")
    public void revertBranch(@Param("brId") int brId);

    @Modifying
    @Query(value ="update branch set is_active = true , is_delete=false where is_delete = true and branch_id = :brId", nativeQuery = true)
    public void revertN(@Param("brId") int brId);
}
