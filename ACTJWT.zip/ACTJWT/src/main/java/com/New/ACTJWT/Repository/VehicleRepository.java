package com.New.ACTJWT.Repository;

import com.New.ACTJWT.model.Vehicle;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import java.util.List;
import java.util.Optional;

@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, Integer> {

    @Query("select v from Vehicle v where v.isDelete = false and v.isActive = true and v.vehicleId = :vehicleId")
    Optional<Vehicle> findActiveVehicleById(int vehicleId);

    //Fetch the record that are deleted
    List<Vehicle> findByIsDeleteTrue();

    //Through query
    @Query("select a from Vehicle a where a.isDelete= true")
    List<Vehicle> findDeletedVehicles();

    // Get the record that are not deleted.
    @Query("select v from Vehicle v where v.isDelete=false")
    List<Vehicle> findActiveVehicles();

    @Query(value = "select * from Vehicle v where v.is_Delete=false",nativeQuery = true)
    Page<Vehicle> findActiveVehiclesPagination(Pageable pageable);

    @Modifying
    @Query("update Vehicle v set v.isActive=true, v.isDelete = false where v.isDelete = true and v.vehicleId =:vId")
    public void revertVehicle(@Param("vId") Integer vId);

    @Modifying
    @Query(value ="update vehicle set is_active = true , is_delete=false where is_delete = true and vehicle_id = :vId", nativeQuery = true)
    public void revertN(@Param("vId") Integer vId);
}
