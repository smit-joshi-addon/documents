package com.New.ACTJWT.controller;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@RestController
@RequestMapping("")
public class ImageController {

    private static final String LIC_IMAGE_DIRECTORY = "/home/krishnab/Downloads/ACT/src/main/resources/LicenceImage/";
    private static final String ID_PROOF_IMAGE_DIRECTORY = "/home/krishnab/Downloads/ACT/src/main/resources/IdProof/";


    @GetMapping("/licImg/{imageName:.+}")
    public ResponseEntity<ByteArrayResource> displayLicenceImage(@PathVariable String imageName) throws IOException {
        //Path imagePath = Paths.get(imageName);
        Path imagePath = Path.of(LIC_IMAGE_DIRECTORY, imageName);

        System.out.println("Image ...."+imagePath);
        if (Files.exists(imagePath) && Files.isReadable(imagePath)) {
            byte[] imageBytes = Files.readAllBytes(imagePath);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_JPEG);
            headers.setContentLength(imageBytes.length);

            ByteArrayResource byteArrayResource = new ByteArrayResource(imageBytes);
            return ResponseEntity.ok()
                    .headers(headers)
                    .body(byteArrayResource);
        } else {
            // Handle the case when the image doesn't exist or is not readable
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/idProof/{imageName:.+}")
    public ResponseEntity<ByteArrayResource> displayIdProfImage(@PathVariable String imageName) throws IOException {
        //Path imagePath = Paths.get(imageName);
        Path imagePath = Path.of(ID_PROOF_IMAGE_DIRECTORY, imageName);

        System.out.println("Image ...."+imagePath);
        if (Files.exists(imagePath) && Files.isReadable(imagePath)) {
            byte[] imageBytes = Files.readAllBytes(imagePath);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_JPEG);
            headers.setContentLength(imageBytes.length);

            ByteArrayResource byteArrayResource = new ByteArrayResource(imageBytes);
            return ResponseEntity.ok()
                    .headers(headers)
                    .body(byteArrayResource);
        } else {
            // Handle the case when the image doesn't exist or is not readable
            return ResponseEntity.notFound().build();
        }
    }


}
