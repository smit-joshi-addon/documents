package com.New.ACT.service;


import com.New.ACT.Repository.DriverRepository;
import org.springframework.transaction.annotation.Transactional;
import com.New.ACT.Repository.DutyDetailsRepository;
import com.New.ACT.Repository.DutyRepository;
import com.New.ACT.Repository.StaffRepository;
import com.New.ACT.model.Duty;

import com.New.ACT.model.DutyDetails;
import com.New.ACT.model.Staff;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONException;
import org.json.JSONObject;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.WKTReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


@Service
public class DutyService {
    @Autowired
    DutyRepository dutyRepository;

    @Autowired
    StaffRepository staffRepository;

    @Autowired
    DriverRepository driverRepository;

    @Autowired
    DutyDetailsRepository dutyDetailsRepository;


    public Map<String, Object> addDuty(String dutyData, HttpServletRequest request) throws JSONException {
        JSONObject jsonData = new JSONObject(dutyData);
        Map<String, Object> m1 = new HashMap<String, Object>();

        int totalStaff = 0;
        int relatedStaff = 0;
        String dutyName = null;
        Timestamp dutyDate;
        String stringDutyDate = null;
        String fileLocation = null;
        String fileName = null;
        boolean status = false;
        String mobileNum1 = null;
        String mobileNum2 = null;
        String email1 = null;

        Geometry dutyLocation = null;

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Duty duty = new Duty();

        try {
            //dutyName Validation
            if (jsonData.has("dutyName") && !jsonData.get("dutyName").equals("")
                    && jsonData.get("dutyName") != null) {
                dutyName = jsonData.getString("dutyName");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide dutyName.");
                return m1;
            }
            // Duty Location Validation
            if (jsonData.has("dutyLocation") && !jsonData.get("dutyLocation").equals("")
                    && jsonData.get("dutyLocation") != null) {
                // Use JTS to convert the WKT string to a Geometry object
                WKTReader wktReader = new WKTReader();
                dutyLocation = wktReader.read(jsonData.getString("dutyLocation"));
                dutyLocation.setSRID(4326);
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide Duty Location.");
                return m1;
            }

            // dutyDate Validation
            if (jsonData.has("dutyDate") && !jsonData.get("dutyDate").equals("")
                    && jsonData.get("dutyDate") != null) {
                stringDutyDate = jsonData.getString("dutyDate");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide dutyDate.");
                return m1;
            }

            // totalStaff  Validation
            if (jsonData.has("totalStaff") && !jsonData.get("totalStaff").equals("")
                    && jsonData.get("totalStaff") != null) {
                totalStaff = jsonData.getInt("totalStaff");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide totalStaff.");
                return m1;
            }
            // relatedStaff  Validation
            if (jsonData.has("relatedStaff") && !jsonData.get("relatedStaff").equals("")
                    && jsonData.get("relatedStaff") != null) {
                relatedStaff = jsonData.getInt("relatedStaff");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide relatedStaff.");
                return m1;
            }

            //fileLocation   Validation
            if (jsonData.has("fileLocation") && !jsonData.get("fileLocation").equals("")
                    && jsonData.get("fileLocation") != null) {
                fileLocation = jsonData.getString("fileLocation");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide fileLocation.");
                return m1;
            }

            if (jsonData.has("fileName") && !jsonData.get("fileName").equals("")
                    && jsonData.get("fileName") != null) {
                fileName = jsonData.getString("fileName");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide fileName.");
                return m1;
            }
            if (jsonData.has("status") && !jsonData.get("status").equals("")
                    && jsonData.get("status") != null) {
                status = jsonData.getBoolean("status");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide status.");
                return m1;
            }

            Date parsedDate = dateFormat.parse(stringDutyDate);
            dutyDate = new Timestamp(parsedDate.getTime());
            System.out.println("Timestamp: " + dutyDate);

            duty.setDutyName(dutyName);
            duty.setDutyDate(dutyDate);
            duty.setFileLocation(fileLocation);
            duty.setFileName(fileName);
            duty.setStatus(status);
            duty.setTotalStaff(totalStaff);
            duty.setRelatedStaff(relatedStaff);
            duty.setCreationTime(new Timestamp(System.currentTimeMillis()));
            duty.setActive(true);
            duty.setDelete(false);
            String ipAddress = request.getHeader("X-FORWARDED-FOR");
            if (ipAddress == null || ipAddress.isEmpty()) {
                duty.setIpAddress(request.getRemoteAddr());
            }
            duty = dutyRepository.save(duty);

            m1.put("status", "success");
            m1.put("Duty Id", duty.getDutyId());
            m1.put("Duty Name", duty.getDutyName());
            m1.put("Duty Date", duty.getDutyDate());
            m1.put("Related Staff", duty.getRelatedStaff());
            m1.put("Total Staff", duty.getTotalStaff());
            m1.put("File Location", duty.getFileLocation());
            m1.put("File Name", duty.getFileName());
            m1.put("Status", duty.isStatus());
            m1.put("message", "Duty information saved successfully!!");
            return m1;

        } catch (ParseException p) {
            p.printStackTrace();
            m1.put("status", "error");
            m1.put("error", "date_format_not_match");
            m1.put("message", "Please Enter Date in the Given Format :'yyyy-MM-dd HH:mm:ss'");
            return m1;
        } catch (Exception e) {
            e.printStackTrace();
            m1.put("status", "error");
            m1.put("error", "not_found");
            m1.put("message", "Something went wrong");
            return m1;
        }
    }

    public Map<String, Object> updateActiveDuty(String dutyData) throws JSONException {
        JSONObject jsonData = new JSONObject(dutyData);
        Map<String, Object> map = new HashMap<>();
        Duty duty;
        int dutyId = 0;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            if (jsonData.has("dutyId") && jsonData.get("dutyId") != null
                    && !jsonData.get("dutyId").equals("")) {
                dutyId = jsonData.getInt("dutyId");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide dutyId.");
                return map;
            }
            Optional<Duty> existingDutyOptional = dutyRepository.findActiveDutyById(dutyId);
            if (existingDutyOptional.isPresent()) {
                duty = existingDutyOptional.get();
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "The Duty Does Not Exist.");
                return map;
            }

            if (jsonData.has("dutyName") && jsonData.get("dutyName") != null
                    && !jsonData.get("dutyName").equals("")) {
                duty.setDutyName(jsonData.getString("dutyName"));
            }
            // airline Address Update
            if (jsonData.has("dutyDate") && !jsonData.get("dutyDate").equals("")
                    && jsonData.get("dutyDate") != null) {
                String stringDutyDate = jsonData.getString("dutyDate");

                Date parsedDate = dateFormat.parse(stringDutyDate);
                Timestamp dutyDate = new Timestamp(parsedDate.getTime());
                duty.setDutyDate(dutyDate);
                System.out.println("Timestamp: " + dutyDate);
            }
            if (jsonData.has("totalStaff") && !jsonData.get("totalStaff").equals("")
                    && jsonData.get("totalStaff") != null) {
                duty.setTotalStaff(jsonData.getInt("totalStaff"));
            }
            if (jsonData.has("relatedStaff") && !jsonData.get("relatedStaff").equals("")
                    && jsonData.get("relatedStaff") != null) {
                duty.setRelatedStaff(jsonData.getInt("relatedStaff"));
            }
            //fileLocation Update
            if (jsonData.has("fileLocation") && !jsonData.get("fileLocation").equals("")
                    && jsonData.get("fileLocation") != null) {
                duty.setFileLocation(jsonData.getString("fileLocation"));
            }
            if (jsonData.has("fileName") && !jsonData.get("fileName").equals("")
                    && jsonData.get("fileName") != null) {
                duty.setFileName(jsonData.getString("fileName"));
            }

            //status Update
            if (jsonData.has("status") && !jsonData.get("status").equals("")
                    && jsonData.get("status") != null) {
                duty.setStatus(jsonData.getBoolean("status"));
            }

            duty = dutyRepository.save(duty);
            map.put("status", "success");
            map.put("message", "Duty id " + dutyId + " Update Confirmed!!!");
            // To Return duty

            map.put("Duty Id", duty.getDutyId());
            map.put("Duty Name", duty.getDutyName());
            map.put("Duty Date", duty.getDutyDate());
            map.put("Related Staff", duty.getRelatedStaff());
            map.put("Total Staff", duty.getTotalStaff());
            map.put("File Location", duty.getFileLocation());
            map.put("File Name", duty.getFileName());
            map.put("Status", duty.isStatus());

        } catch (ParseException p) {
            p.printStackTrace();
            map.put("status", "error");
            map.put("error", "date_format_not_compatible");
            map.put("message", "Please provide Date in this format:'yyyy-MM-dd HH:mm:ss'");
            return map;
        } catch (JSONException e) {
            e.printStackTrace();
            map.put("status", "error");
            map.put("error", "not_found");
            map.put("message", "Something went wrong");
            return map;
        }
        return map;
    }

    public Map<String, Object> getActiveDutyById(int dutyId) {
        Duty duty;
        Optional<Duty> existingDutyOptional = dutyRepository.findActiveDutyById(dutyId);

        Map<String, Object> propertyMap = new HashMap<>();

        try {
            if (existingDutyOptional.isPresent()) {
                duty = existingDutyOptional.get();

                propertyMap.put("Duty Id", duty.getDutyId());
                propertyMap.put("Duty Name", duty.getDutyName());

                propertyMap.put("Duty Date", duty.getDutyDate());
                propertyMap.put("Related Staff", duty.getRelatedStaff());
                propertyMap.put("Total Staff", duty.getTotalStaff());
                propertyMap.put("File Location", duty.getFileLocation());
                propertyMap.put("File Name", duty.getFileName());
                propertyMap.put("Status", duty.isStatus());

                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "duty_no_longer_available");
                propertyMap.put("message", "Sorry, this Duty " + dutyId + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Duty Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }

    }

    public Map<String, Object> getDutyByName(String dutyName) {
        List<Duty> existingDutyOptional = dutyRepository.findByDutyName(dutyName);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();
            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }

    public Map<String, Object> getDutyByNameJPQL(String dutyName) {
        List<Duty> existingDutyOptional = dutyRepository.findByDutyNameJPQL(dutyName);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();


            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }

    public Map<String, Object> getDutyByNameNative(String dutyName) {
        List<Duty> existingDutyOptional = dutyRepository.findByDutyNameNative(dutyName);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }

    public Map<String, Object> getDutyByTotalStaffHighNative(int totalStaff) {
        List<Duty> existingDutyOptional = dutyRepository.findByTotalStaffHighNative(totalStaff);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }


    public Map<String, Object> getDutyByTotalStaffBetween(int start, int stop) {
        List<Duty> existingDutyOptional = dutyRepository.findByTotalStaffBetween(start, stop);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();
            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }

    public Map<String, Object> getDutyByRelatedStaffBetween(int start, int stop) {
        List<Duty> existingDutyOptional = dutyRepository.findByRelatedStaffBetween(start, stop);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();


            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }

    public Map<String, Object> getDutyByRelatedStaffHighNative(int relatedStaff) {
        List<Duty> existingDutyOptional = dutyRepository.findByRelatedStaffHighNative(relatedStaff);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }

    public Map<String, Object> getDutyByRelatedStaffLessJPQL(int relatedStaff) {
        List<Duty> existingDutyOptional = dutyRepository.findByRelatedStaffLessJPQL(relatedStaff);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();
            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }

    public Map<String, Object> getDutyByTotalStaffLessJPQL(int totalStaff) {
        List<Duty> existingDutyOptional = dutyRepository.findByTotalStaffLessJPQL(totalStaff);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();


            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());

            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());

            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }

    public Map<String, Object> getDutyByFileLocation(String fileLocation) {
        List<Duty> existingDutyOptional = dutyRepository.findByFileLocation(fileLocation);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());

            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());

            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }


    public Map<String, Object> getDutyByFileLocationJPQL(String fileLocation) {
        List<Duty> existingDutyOptional = dutyRepository.findByFileLocationJPQL(fileLocation);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();
            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());

            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());

            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }


    public Map<String, Object> getDutyByFileLocationNative(String fileLocation) {
        List<Duty> existingDutyOptional = dutyRepository.findByFileLocationNative(fileLocation);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());

            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }

    public Map<String, Object> getDutyByFileName(String fileName) {
        List<Duty> existingDutyOptional = dutyRepository.findByFileName(fileName);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();


            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());

            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }


    public Map<String, Object> getDutyByFileNameJPQL(String fileName) {
        List<Duty> existingDutyOptional = dutyRepository.findByFileNameJPQL(fileName);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }


    public Map<String, Object> getDutyByFileNameNative(String fileName) {
        List<Duty> existingDutyOptional = dutyRepository.findByFileNameNative(fileName);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();


            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }


    public Map<String, Object> getDutyByStatusJPQL(boolean status) {
        List<Duty> existingDutyOptional = dutyRepository.findByStatusJPQL(status);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();


            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }


    public Map<String, Object> getDutyByStatusNative(boolean status) {
        List<Duty> existingDutyOptional = dutyRepository.findByStatusNative(status);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }


    public Map<String, Object> getDutyByStatus(boolean status) {
        List<Duty> existingDutyOptional = dutyRepository.findByStatus(status);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();
            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }


    // Get Active & Delete Records
    public Map<String, Object> getAllDuty() {
        List<Duty> existingDutyOptional = dutyRepository.findAll();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;

    }

    public Map<String, Object> getAllActiveDuty() {
        List<Duty> existingDutyOptional = dutyRepository.findAllActiveDuty();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();
            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;
    }

    public Map<String, Object> getAllDeletedDuty() {
        List<Duty> existingDutyOptional = dutyRepository.findAllDeletedDuty();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Duty data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            propertyMap2.put("status", "success");
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Duty", data);
        return propertyMap;
    }

    public Map<String, Object> getAllActiveDutyPagination(Pageable pageable) {
        Page<Duty> existingDutyOptional = dutyRepository.findAll(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    public Map<String, Object> getAllDeletedDutyPagination(int page, int size, String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy));
        Page<Duty> existingDutyOptional = dutyRepository.findAllDeletedDutyPagination(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();


            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    public Map<String, Object> getAllDutyPagination(Pageable pageable) {
        Page<Duty> existingDutyOptional = dutyRepository.findAll(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDutyOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "duty_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Duty duty : existingDutyOptional) {
            propertyMap2 = new HashMap<>();

            propertyMap2.put("Duty Id", duty.getDutyId());
            propertyMap2.put("Duty Name", duty.getDutyName());
            propertyMap2.put("Duty Date", duty.getDutyDate());
            propertyMap2.put("Related Staff", duty.getRelatedStaff());
            propertyMap2.put("Total Staff", duty.getTotalStaff());
            propertyMap2.put("File Location", duty.getFileLocation());
            propertyMap2.put("File Name", duty.getFileName());
            propertyMap2.put("Status", duty.isStatus());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    public Map<String, Object> deleteDutyById(int dutyId) {
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            Optional<Duty> existingDutyOptional = dutyRepository.findActiveDutyById(dutyId);
            if (existingDutyOptional.isPresent()) {
                Duty duty = existingDutyOptional.get();
                duty.setDelete(true);
                duty.setActive(false);
                duty.setDeletionTime(new Timestamp(System.currentTimeMillis()));
                dutyRepository.save(duty);
                propertyMap.put("status", "success");
                propertyMap.put("message", "Duty soft deletion Confirmed!!");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "Duty_no_longer_available");
                propertyMap.put("message", "Sorry, this Duty" + dutyId + " is not Existed.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Duty Id ");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> delDutyHard(int dutyId) {
        Map<String, Object> map = new HashMap<>();

        Optional<Duty> existingDutyOptional = dutyRepository.findById(dutyId);

        try {
            if (existingDutyOptional.isPresent()) {
                dutyRepository.deleteById(dutyId);
                map.put("status", "success");
                map.put("message", "Duty id " + dutyId + " deletion Confirmed!!");
                return map;
            } else {
                map.put("status", "error");
                map.put("error", "no_longer_available");
                map.put("message", "Sorry, this Duty " + dutyId + " does not Existed.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Invalid Duty Id");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }

    public Map<String, Object> revertDuty(int dutyId) {
        Map<String, Object> map = new HashMap<>();
        try {
            Optional<Duty> existingDutyOptional = dutyRepository.findById(dutyId);
            if (existingDutyOptional.isPresent()) {
                Duty duty = existingDutyOptional.get();

                if (!duty.isActive() && duty.isDelete()) {
                    duty.setDelete(false);
                    duty.setActive(true);
                    duty.setDeletionTime(null);
                    dutyRepository.save(duty);
                    map.put("status", "success");
                    map.put("message", "Duty " + dutyId + " Revert Confirmed!!");
                    return map;
                } else {
                    map.put("status", "error");
                    map.put("error", "Duty can't be Reverted.");
                    return map;
                }
            } else {
                map.put("status", "error");
                map.put("error", "duty " + dutyId + " is not Present.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Please Check Again.");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }

    public Map<String, Object> getRecordsForDate(String stringTargetDate) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Map<String, Object> propertyMap = new HashMap<>();
        try {
            Date targetDate = dateFormat.parse(stringTargetDate);

            List<Duty> existingDutyOptional = dutyRepository.getRecordsForDate(targetDate);

            Map<String, Object> propertyMap2;
            ArrayList<Map<String, Object>> data = new ArrayList<>();

            if (existingDutyOptional.isEmpty()) {
                propertyMap.put("status", "error");
                propertyMap.put("error", "duty_no_longer_available");
                propertyMap.put("message", "Duty data not found");
                return propertyMap;
            }

            for (Duty duty : existingDutyOptional) {
                propertyMap2 = new HashMap<>();
              /*  map = new HashMap<>();
                map.put("Airline Id", duty.getAirline().getAirlineId());
                map.put("AirlineName", duty.getAirline().getAirlineName());
                map.put("AirlineAddress", duty.getAirline().getAirlineAddress());
                map.put("AirlineLocation", duty.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", duty.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", duty.getAirline().getMobileNum1());
                map.put("MobileNum2", duty.getAirline().getMobileNum2());
                map.put("MobileNum3", duty.getAirline().getMobileNum3());
                map.put("Email1", duty.getAirline().getEmail1());
                map.put("Email2", duty.getAirline().getEmail2());*/

                propertyMap2.put("Duty Id", duty.getDutyId());
                propertyMap2.put("Duty Name", duty.getDutyName());
                //   propertyMap2.put("Duty Location", duty.getDutyLocation().toText());
                propertyMap2.put("Duty Date", duty.getDutyDate());
                propertyMap2.put("Related Staff", duty.getRelatedStaff());
                propertyMap2.put("Total Staff", duty.getTotalStaff());
                propertyMap2.put("File Location", duty.getFileLocation());
                propertyMap2.put("File Name", duty.getFileName());
                propertyMap2.put("Status", duty.isStatus());
                // propertyMap2.put("Airline", map);
                propertyMap2.put("status", "success");
                data.add(propertyMap2);
            }
            propertyMap.put("status", "success");
            propertyMap.put("Duty", data);
            return propertyMap;
        } catch (ParseException e) {
            e.printStackTrace();
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Please Check Date Again.");
            propertyMap.put("message", "Something went Wrong with Date Format use this 'yyyy-MM-dd ...");
            return propertyMap;

        }

    }


    /**
     * @noinspection deprecation
     */
    @Transactional
    public String uploadFile(HttpServletRequest request) throws FileNotFoundException {

        String filePath = "/home/krishnab/Downloads/Daily Roster Report Go 24 Mar 2022.xls";
        // String filePath = "/home/krishnab/Downloads/Final cabin crew roster for 20th june 2022.xlsx";
        String fileName = filePath.substring(filePath.lastIndexOf('/') + 1);
        System.out.println("FIleName " + fileName);

        Duty duty = new Duty();

        try (InputStream inputStream = new FileInputStream(filePath)) {
            Workbook workbook;
            String fileExtension = FilenameUtils.getExtension(filePath);
            if ("xls".equalsIgnoreCase(fileExtension)) {
                workbook = new HSSFWorkbook(inputStream);
            } else if ("xlsx".equalsIgnoreCase(fileExtension)) {
                workbook = new XSSFWorkbook(inputStream);
            } else {
                // Handle unsupported file format
                throw new IllegalArgumentException("Unsupported file format: " + fileExtension);
            }

            Sheet sheet = workbook.getSheetAt(0); // Assuming the data is in the first sheet
            System.out.println("Inner Sheet");

            //Date of the report
            Row dateRow = sheet.getRow(4);
            Cell cell = dateRow.getCell(17);

            long reportDate = 0;

            if (cell != null && cell.getCellType() == CellType.STRING) {
                String cellValue = cell.getStringCellValue().trim();
                if (cellValue.startsWith("Report Date")) {
                    String dateString = cellValue.substring(cellValue.indexOf(":") + 2).trim();
                    //System.out.println("Date"+dateString);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, dd MMMM yyyy");
                    try {
                        Date date = dateFormat.parse(dateString);
                        reportDate = date.getTime(); // Timestamp in milliseconds
                        // System.out.println("Timestamp: " + reportDate);
                        // You can now use the timestamp as needed
                    } catch (ParseException e) {
                        System.err.println("Error parsing date: " + e.getMessage());
                    }
                }
            }
            // Header Confirmation
            Row header = sheet.getRow(6);
            String flightSectorHeader = header.getCell(4).getStringCellValue();
            if (!flightSectorHeader.equals("Flight No(s)\nSector(s)")) {
                return "Flight No(s)\\nSector(s) Header Not Found";
            }
            String STDUTCHeader = header.getCell(11).getStringCellValue();
            if (!STDUTCHeader.equals("STD\nSTA\n(UTC)")) {
                return "STD\nSTA\n(UTC)\n Header Not Found";
            }
            String staffDetailsHeader = header.getCell(16).getStringCellValue();
            if (!staffDetailsHeader.equals("Staff ID : Crew Name")) {
                return "'Staff ID : Crew Name' Header Not Found";
            }
            //System.out.println("Header " + flightSectorHeader + STDUTCHeader + staffDetailsHeader);

            // Initialize a counter for staff codes
            int totalStaffCount = 0;

            // Create a pattern to match the staff code
            Pattern pattern = Pattern.compile("(\\d+):");
            ArrayList<Map<String, Object>> flightDetailsList = new ArrayList<>();
            // To Store Unique Related Staff
            Set<String> uniqueStaffCodes = new HashSet<>(); // Set to store unique staff codes
            // Iterate through rows
            for (Row row : sheet) {
                Cell flightSectorCell = row.getCell(4); // Column index 3 for 'Flight No(s) Sector(s)'

                if (flightSectorCell == null) {
                    //System.out.println("Continue...");
                    continue;
                }
                //Getting string Value for filtering
                String flightSectorValue = flightSectorCell.getStringCellValue();
                // End Of The Read File Or Stop Reading File
                if ("ACM".equals(flightSectorValue)) { // Use equals() method for string comparison
                    System.out.println("Break");
                    break;
                }
                if (flightSectorValue.isEmpty()) {
                    //System.out.println("Value Continue..");
                    continue;
                }
                //System.out.println("Flight Details :" + flightSectorValue);
                String staffCodeNames = row.getCell(16).getStringCellValue();
                //System.out.println("Staff Id " + staffCodeNames);

                //Count Total Staff  Create a matcher object for staff codes
                Matcher matcher = pattern.matcher(staffCodeNames);
                // Iterate through the matches to find staff codes
                while (matcher.find()) {
                    totalStaffCount++;
                }
                // Entry Of related Staff
                if (flightSectorValue.contains("AMD")) {
                    int lastNumericIndex = -1;
                    for (int i = flightSectorValue.length() - 1; i > 0; i--) {
                        if (Character.isDigit(flightSectorValue.charAt(i))) {
                            lastNumericIndex = i;
                            break;
                        }
                    }
                    if (lastNumericIndex == -1) {
                        continue;
                    }
                    String flightRoute = flightSectorValue.substring(lastNumericIndex + 1);
                    if (flightRoute.startsWith("AMD") || flightRoute.endsWith("AMD")) {

                        System.out.println("Flight Route " + flightRoute);
                        String deptUtcTime = row.getCell(11).getStringCellValue();
                        String arrivalUtcTime = sheet.getRow(row.getRowNum() + 1).getCell(11).getStringCellValue();

                        // Create a new staffCodeList for each flight
                        List<String> staffCodeList = new ArrayList<>();

                        Matcher codeMatcher = pattern.matcher(staffCodeNames);

                        while (codeMatcher.find()) {
                            String staffCode = codeMatcher.group(1);
                            if (uniqueStaffCodes.contains(staffCode)) {
                                staffCodeList.add(staffCode);
                            } else if (staffRepository.existsByStaffCode(staffCode)) { // database check
                                uniqueStaffCodes.add(staffCode);
                                staffCodeList.add(staffCode);
                            }
                        }
                        // Check if staffCodeList has values
                        if (!staffCodeList.isEmpty()) {
                            Map<String, Object> flightMap = new HashMap<>();
                            //Store data in HashMap
                            flightMap.put("flightRoute", flightRoute);
                            flightMap.put("deptUtcTime", deptUtcTime);
                            flightMap.put("arrivalUtcTime", arrivalUtcTime);
                            flightMap.put("staffCodeList", new ArrayList<>(staffCodeList));
                            flightDetailsList.add(flightMap);

                            System.out.println("\n\nFor Loop");
                            for (Map<String, Object> flightDetails : flightDetailsList) {
                                System.out.println("\nFlight details...");
                                System.out.println("Flight Route " + flightDetails.get("flightRoute"));
                                System.out.println("Flight Take Off " + flightDetails.get("deptUtcTime"));
                                System.out.println("Flight Land " + flightDetails.get("arrivalUtcTime"));
                                System.out.println("staffCodeList " + flightDetails.get("staffCodeList"));
                            }
                            System.out.println("For End\n\n\n");
                        }
                    }
                }
            }

            System.out.println("Total Staff " + totalStaffCount);
            int relatedStaff = uniqueStaffCodes.size();
            System.out.println("Related Staff Number" + relatedStaff);
            System.out.println("Staff List" + uniqueStaffCodes.toString());


            //Store in the database
            duty.setDutyName(fileName);
            duty.setDutyDate(new Timestamp(reportDate)); // This milisecond 2022-03-24 00:00:00 [localtime ] utc (-05:30)
            duty.setFileLocation(filePath);
            duty.setFileName(fileName);
            duty.setTotalStaff(totalStaffCount);
            duty.setRelatedStaff(relatedStaff);
            duty.setStatus(true);
            duty.setCreationTime(new Timestamp(System.currentTimeMillis()));
            duty.setActive(true);
            duty.setDelete(false);
            String ipAddress = request.getHeader("X-FORWARDED-FOR");
            if (ipAddress == null || ipAddress.isEmpty()) {
                duty.setIpAddress(request.getRemoteAddr());
            }
            duty = dutyRepository.save(duty);

            System.out.println(reportDate);

            for (Map<String, Object> flightDetails : flightDetailsList) {
                String flightRoute = (String) flightDetails.get("flightRoute");
                String deptUtcTime = (String) flightDetails.get("deptUtcTime");
                String arrivalUtcTime = (String) flightDetails.get("arrivalUtcTime");
                List<String> staffCodeList = (ArrayList<String>) flightDetails.get("staffCodeList");

                for (String staffCode : staffCodeList) {
                    Optional<Staff> optionalStaff = staffRepository.findByStaffCode(staffCode);
                    if (optionalStaff.isPresent()) {
                        Staff staff = optionalStaff.get();

                        DutyDetails dutyDetails = new DutyDetails();
                        dutyDetails.setDuty(duty);
                        dutyDetails.setDDName(flightRoute);
                        dutyDetails.setStaff(staff);
                        dutyDetails.setMobileNum(staff.getMobileNum1());
                        dutyDetails.setAddress(staff.getStaffAddress());

                        Timestamp timestamp = null;
                        if (flightRoute.startsWith("AMD") && flightRoute.endsWith("AMD")) {
                            // Create DutyDetails entry for pickup
                            DutyDetails pickupDetails = new DutyDetails(dutyDetails); // Copy constructor
                            try {
                                String[] parts = deptUtcTime.split(":");
                                int hours = Integer.parseInt(parts[0]);
                                int minutes = Integer.parseInt(parts[1]);
                                timestamp = new Timestamp(reportDate);
                                timestamp.setHours(hours);
                                timestamp.setMinutes(minutes);
                                pickupDetails.setActPickupTime(timestamp);
                                pickupDetails.setDutyType("Pick Up");
                                dutyDetailsRepository.save(pickupDetails);
                            } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                                e.printStackTrace(); // Handle or log exception
                            }

                            // Create DutyDetails entry for pickup
                            DutyDetails dropDetails = new DutyDetails(dutyDetails); // Copy constructor
                            try {
                                String[] parts = arrivalUtcTime.split(":");
                                int hours = Integer.parseInt(parts[0]);
                                int minutes = Integer.parseInt(parts[1]);
                                timestamp = new Timestamp(reportDate);
                                timestamp.setHours(hours);
                                timestamp.setMinutes(minutes);
                                dropDetails.setActPickupTime(timestamp);
                                dropDetails.setDutyType("drop");
                                dutyDetailsRepository.save(dropDetails);
                            } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                                e.printStackTrace(); // Handle or log exception
                            }
                        } else if (flightRoute.startsWith("AMD")) {
                            try {
                                //WORKING
                                // Subtract 2 hours and 30 minutes
                                //long millisecondsToSubtract = 2 * 60 * 60 * 1000 + 30 * 60 * 1000;
                                //long newTime = timestamp.getTime() - millisecondsToSubtract;
                                // Update the timestamp with the new time
                                //timestamp.setTime(newTime);
                                String[] parts = deptUtcTime.split(":");
                                int hours = Integer.parseInt(parts[0]);
                                int minutes = Integer.parseInt(parts[1]);
                                timestamp = new Timestamp(reportDate);
                                timestamp.setHours(hours);
                                timestamp.setMinutes(minutes);
                                dutyDetails.setActPickupTime(timestamp);
                                dutyDetails.setDutyType("Pick Up");
                                dutyDetailsRepository.save(dutyDetails);

                            } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                                e.printStackTrace(); // Handle or log exception
                            }
                        } else if (flightRoute.endsWith("AMD")) {
                            try {
                                String[] parts = arrivalUtcTime.split(":");
                                int hours = Integer.parseInt(parts[0]);
                                int minutes = Integer.parseInt(parts[1]);
                                timestamp = new Timestamp(reportDate);
                                timestamp.setHours(hours);
                                timestamp.setMinutes(minutes);
                                dutyDetails.setActPickupTime(timestamp);
                                dutyDetails.setDutyType("Drop");
                                dutyDetailsRepository.save(dutyDetails);
                            } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                                e.printStackTrace(); // Handle or log exception
                            }
                        } else {
                            // Handle other cases if necessary
                            System.out.println("Else.... ");
                            continue;
                        }
                    }
                }
                System.out.println("Flight Route: " + flightRoute);
                System.out.println("Arrival UTC Time: " + deptUtcTime);
                System.out.println("Departure UTC Time: " + arrivalUtcTime);
                System.out.println("Staff Code List: " + staffCodeList);
            }

            List<Object[]> result = staffRepository.staffNDriverAllocation(uniqueStaffCodes);

            Map<Integer, Integer> driverCapacities = new HashMap<>();

// Retrieve capacities for all drivers and store them in the HashMap
            List<Object[]> capacities = driverRepository.vehiclePersonCapacity();
            for (Object[] capacityRow : capacities) {
                Integer driverId = (Integer) capacityRow[0];
                Integer capacity = (Integer) capacityRow[1];
                driverCapacities.put(driverId, capacity);
            }

            Set<Integer> allocatedStaffIds = new HashSet<>();
            int staffToAllocate = uniqueStaffCodes.size();
// Iterate through the result and allocate drivers
            for (Object[] row : result) {
                Double distance = (Double) row[0];
                Integer staffId = (Integer) row[1];
                Integer driverId = (Integer) row[2];

                int dutyId = duty.getDutyId();

                // Check if this staff ID has already been allocated
                if (allocatedStaffIds.contains(staffId)) {
                    // Skip allocation for this staff ID since it's already allocated
                    System.out.println("Skipping allocation for staff ID: " + staffId);
                    continue;
                }

                // Check if we have already retrieved the capacity for this driver
                Integer driverCapacity = driverCapacities.get(driverId);
                if (driverCapacity == null) {
                    // If capacity not found in the HashMap, fetch it from the database
                    System.out.println("Driver Capacity Null" + driverId);
                    driverCapacity = driverRepository.findVehiclePersonCapacityByDriverId(driverId);
                    driverCapacities.put(driverId, driverCapacity); // Store in HashMap for future reference
                }

                // Allocate the staff member to the driver if capacity allows
                if (driverCapacity != null && driverCapacity > 0) {

                    dutyDetailsRepository.updateStaffDriver(distance, driverId, staffId, dutyId);
                    System.out.println("Distance: " + distance);
                    System.out.println("Staff ID: " + staffId);
                    System.out.println("Driver ID: " + driverId);
                    System.out.println("-------------------------");
                    // Decrease the driver's capacity
                    driverCapacity--; // Decrement the capacity
                    driverCapacities.put(driverId, driverCapacity); // Update the capacity in the map
                    // Add the staff ID to the allocated set
                    allocatedStaffIds.add(staffId);
                } else {
                    System.out.println("No available capacity for driver ID: " + driverId + " to allocate staff ID: " + staffId);
                }

                if (staffToAllocate == allocatedStaffIds.size()) {
                    System.out.println("\nstaffToAllocate " + staffToAllocate);
                    System.out.println("\nallocatedStaffIds " + allocatedStaffIds);
                    System.out.println("All Staff Assigned");
                    break;
                }
            }

            if (staffToAllocate > allocatedStaffIds.size()) {
                System.out.println("\n\nStaff Is Not Assigned ....\n");
                int notAssignedStaff = staffToAllocate - allocatedStaffIds.size();
                System.out.println("No of Staff Not Assigned :- " + notAssignedStaff);
                System.out.println("\nallocatedStaffIds " + allocatedStaffIds);
            }

            return "Read Successfully";

        } catch (IOException e) {
            e.printStackTrace();

            return "Exception";
        }
    }

    /**
     * @noinspection deprecation
     */
    @Transactional
    public String uploadFileTest(HttpServletRequest request) throws FileNotFoundException {

        String filePath = "/home/krishnab/Downloads/Daily Roster Report Go 24 Mar 2022.xls";
        // String filePath = "/home/krishnab/Downloads/Final cabin crew roster for 20th june 2022.xlsx";
        String fileName = filePath.substring(filePath.lastIndexOf('/') + 1);
        System.out.println("FIleName " + fileName);

        Duty duty = new Duty();

        try (InputStream inputStream = new FileInputStream(filePath)) {
            Workbook workbook;
            String fileExtension = FilenameUtils.getExtension(filePath);
            if ("xls".equalsIgnoreCase(fileExtension)) {
                workbook = new HSSFWorkbook(inputStream);
            } else if ("xlsx".equalsIgnoreCase(fileExtension)) {
                workbook = new XSSFWorkbook(inputStream);
            } else {
                // Handle unsupported file format
                throw new IllegalArgumentException("Unsupported file format: " + fileExtension);
            }

            Sheet sheet = workbook.getSheetAt(0); // Assuming the data is in the first sheet
            System.out.println("Inner Sheet");

            //Date of the report
            Row dateRow = sheet.getRow(4);
            Cell cell = dateRow.getCell(17);

            long reportDate = 0;

            if (cell != null && cell.getCellType() == CellType.STRING) {
                String cellValue = cell.getStringCellValue().trim();
                if (cellValue.startsWith("Report Date")) {
                    String dateString = cellValue.substring(cellValue.indexOf(":") + 2).trim();
                    //System.out.println("Date"+dateString);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, dd MMMM yyyy");
                    try {
                        Date date = dateFormat.parse(dateString);
                        reportDate = date.getTime(); // Timestamp in milliseconds
                        // System.out.println("Timestamp: " + reportDate);
                        // You can now use the timestamp as needed
                    } catch (ParseException e) {
                        System.err.println("Error parsing date: " + e.getMessage());
                    }
                }
            }


            // Initialize a counter for staff codes
            int totalStaffCount = 0;

            // Create a pattern to match the staff code
            Pattern pattern = Pattern.compile("(\\d+):");
            ArrayList<Map<String, Object>> flightDetailsList = new ArrayList<>();
            // To Store Unique Related Staff
            Set<String> uniqueStaffCodes = new HashSet<>(); // Set to store unique staff codes
            // Iterate through rows
            for (Row row : sheet) {
                Cell flightSectorCell = row.getCell(4); // Column index 3 for 'Flight No(s) Sector(s)'

                if (flightSectorCell == null) {
                    //System.out.println("Continue...");
                    continue;
                }
                //Getting string Value for filtering
                String flightSectorValue = flightSectorCell.getStringCellValue();
                // End Of The Read File Or Stop Reading File
                if ("ACM".equals(flightSectorValue)) { // Use equals() method for string comparison
                    System.out.println("Break");
                    break;
                }
                if (flightSectorValue.isEmpty()) {
                    //System.out.println("Value Continue..");
                    continue;
                }
                //System.out.println("Flight Details :" + flightSectorValue);
                String staffCodeNames = row.getCell(16).getStringCellValue();
                //System.out.println("Staff Id " + staffCodeNames);

                //Count Total Staff  Create a matcher object for staff codes
                Matcher matcher = pattern.matcher(staffCodeNames);
                // Iterate through the matches to find staff codes
                while (matcher.find()) {
                    totalStaffCount++;
                }
                // Entry Of related Staff
                if (flightSectorValue.contains("AMD")) {
                    int lastNumericIndex = -1;
                    for (int i = flightSectorValue.length() - 1; i > 0; i--) {
                        if (Character.isDigit(flightSectorValue.charAt(i))) {
                            lastNumericIndex = i;
                            break;
                        }
                    }
                    if (lastNumericIndex == -1) {
                        continue;
                    }
                    String flightRoute = flightSectorValue.substring(lastNumericIndex + 1);
                    if (flightRoute.startsWith("AMD") || flightRoute.endsWith("AMD")) {

                        System.out.println("Flight Route " + flightRoute);
                        String deptUtcTime = row.getCell(11).getStringCellValue();
                        String arrivalUtcTime = sheet.getRow(row.getRowNum() + 1).getCell(11).getStringCellValue();

                        // Create a new staffCodeList for each flight
                        List<String> staffCodeList = new ArrayList<>();

                        Matcher codeMatcher = pattern.matcher(staffCodeNames);

                        while (codeMatcher.find()) {
                            String staffCode = codeMatcher.group(1);
                            if (uniqueStaffCodes.contains(staffCode)) {
                                staffCodeList.add(staffCode);
                            } else if (staffRepository.existsByStaffCode(staffCode)) { // database check
                                uniqueStaffCodes.add(staffCode);
                                staffCodeList.add(staffCode);
                            }
                        }
                        // Check if staffCodeList has values
                        if (!staffCodeList.isEmpty()) {
                            Map<String, Object> flightMap = new HashMap<>();
                            //Store data in HashMap
                            flightMap.put("flightRoute", flightRoute);
                            flightMap.put("deptUtcTime", deptUtcTime);
                            flightMap.put("arrivalUtcTime", arrivalUtcTime);
                            flightMap.put("staffCodeList", new ArrayList<>(staffCodeList));
                            flightDetailsList.add(flightMap);

                            System.out.println("\n\nFor Loop");
                            for (Map<String, Object> flightDetails : flightDetailsList) {
                                System.out.println("\nFlight details...");
                                System.out.println("Flight Route " + flightDetails.get("flightRoute"));
                                System.out.println("Flight Take Off " + flightDetails.get("deptUtcTime"));
                                System.out.println("Flight Land " + flightDetails.get("arrivalUtcTime"));
                                System.out.println("staffCodeList " + flightDetails.get("staffCodeList"));
                            }
                            System.out.println("For End\n\n\n");
                        }
                    }
                }
            }

            System.out.println("Total Staff " + totalStaffCount);
            int relatedStaff = uniqueStaffCodes.size();
            System.out.println("Related Staff Number" + relatedStaff);
            System.out.println("Staff List" + uniqueStaffCodes.toString());


            //Store in the database
           /* duty.setDutyName(fileName);
            duty.setDutyDate(new Timestamp(reportDate)); // This milisecond 2022-03-24 00:00:00 [localtime ] utc (-05:30)
            duty.setFileLocation(filePath);
            duty.setFileName(fileName);
            duty.setTotalStaff(totalStaffCount);
            duty.setRelatedStaff(relatedStaff);
            duty.setStatus(true);
            duty.setCreationTime(new Timestamp(System.currentTimeMillis()));
            duty.setActive(true);
            duty.setDelete(false);
            String ipAddress = request.getHeader("X-FORWARDED-FOR");
            if (ipAddress == null || ipAddress.isEmpty()) {
                duty.setIpAddress(request.getRemoteAddr());
            }
            duty = dutyRepository.save(duty);
              System.out.println(reportDate);
*/
            staffTransportation(flightDetailsList, reportDate);


            return "Read Successfully";

        } catch (IOException e) {
            e.printStackTrace();

            return "Exception";
        } catch (ParseException e) {
            e.printStackTrace();
            return "ParseException";
        }
    }

    private void staffTransportation(ArrayList<Map<String, Object>> flightDetailsList, long reportDate) throws ParseException {

// Create a map to store unique staff codes with their associated flight details
        Map<String, List<Map<String, Object>>> uniqueStaffMap = new HashMap<>();

        // Iterate through each flight
        for (Map<String, Object> flight : flightDetailsList) {
            List<String> staffCodeList = (List<String>) flight.get("staffCodeList");

            // Iterate through staff codes of each flight
            for (String staffCode : staffCodeList) {
                // Check if the staff code is already in the map
                if (uniqueStaffMap.containsKey(staffCode)) {
                    // If the staff code already exists, add the flight details to its list
                    uniqueStaffMap.get(staffCode).add(flight);
                } else {
                    // If the staff code is new, create a new list and add the flight details to it
                    List<Map<String, Object>> flights = new ArrayList<>();
                    flights.add(flight);
                    uniqueStaffMap.put(staffCode, flights);
                }
            }
        }

        System.out.println("Outside");
        // Now you have unique staff codes with their associated flight details in uniqueStaffMap
        // You can iterate over this map to access each staff code along with its flights
        for (Map.Entry<String, List<Map<String, Object>>> entry : uniqueStaffMap.entrySet()) {
            System.out.println("Inside");
            String staffCode = entry.getKey();
            Optional<Staff> optionalStaff = staffRepository.findByStaffCode(staffCode);
            if (!optionalStaff.isPresent()) {
                continue;
            }
            Staff staff = optionalStaff.get();
            List<Map<String, Object>> flights = entry.getValue();
            int size = flights.size();
            System.out.println("Size" + size);
            // Process each staff code and its associated flights
            System.out.println("Staff Code: " + staffCode);

            if (size == 1) {
                for (Map<String, Object> flight : flights) {
                    String flightRoute = (String) flight.get("flightRoute");
                    String deptUtcTime = (String) flight.get("deptUtcTime");
                    String arrivalUtcTime = (String) flight.get("arrivalUtcTime");

                    if (flightRoute == null || deptUtcTime == null || arrivalUtcTime == null) {
                        // Handle null values, log or throw an exception
                        System.err.println("Null values found in flight details. Skipping...");
                        continue;
                    }

                    if (flightRoute.startsWith("AMD")) {
                        DutyDetails dutyDetails = new DutyDetails();
                        // dutyDetails.setDuty(duty);
                        dutyDetails.setDDName(flightRoute);
                        dutyDetails.setStaff(staff);
                        dutyDetails.setMobileNum(staff.getMobileNum1());
                        dutyDetails.setAddress(staff.getStaffAddress());
                        saveDutyDetails(dutyDetails, deptUtcTime, "Pick Up", reportDate); // Copy constructor

                    }
                    if (flightRoute.endsWith("AMD")) {
                        DutyDetails dutyDetails = new DutyDetails();
                        //dutyDetails.setDuty(duty);
                        dutyDetails.setDDName(flightRoute);
                        dutyDetails.setStaff(staff);
                        dutyDetails.setMobileNum(staff.getMobileNum1());
                        dutyDetails.setAddress(staff.getStaffAddress());
                        saveDutyDetails(dutyDetails, arrivalUtcTime, "Drop", reportDate);
                    }
                    //return who has only one flight schedule. Skip to the next staff member
                    System.out.println("Flight Details:");
                    System.out.println("Flight Route: " + flight.get("flightRoute"));
                    System.out.println("Arrival UTC Time: " + flight.get("deptUtcTime"));
                    System.out.println("Departure UTC Time: " + flight.get("arrivalUtcTime"));
                }
            }
            //more than one staff
            else {
                String nextDepartureTime = null;
                // Check if this is the first flight
                for (int i = 0; i < flights.size(); i++) {
                    Map<String, Object> flight = flights.get(i);
                    String flightRoute = (String) flight.get("flightRoute");
                    String deptUtcTime = (String) flight.get("deptUtcTime");
                    String arrivalUtcTime = (String) flight.get("arrivalUtcTime");

                    if (flightRoute == null || deptUtcTime == null || arrivalUtcTime == null) {
                        // Handle null values, log or throw an exception
                        System.err.println("Null values found in flight details. Skipping...");
                        continue;
                    }
                    //start with amd then assign pickup
                    if (i == 0) {
                        if (flightRoute.startsWith("AMD")) {
                            DutyDetails dutyDetails = new DutyDetails();
                            // dutyDetails.setDuty(duty);
                            dutyDetails.setDDName(flightRoute);
                            dutyDetails.setStaff(staff);
                            dutyDetails.setMobileNum(staff.getMobileNum1());
                            dutyDetails.setAddress(staff.getStaffAddress());
                            saveDutyDetails(dutyDetails, deptUtcTime, "Pick Up", reportDate); // Copy constructor
                            System.out.println("FIrst Record");
                        }
                    }
                    // last flight end with amd then assign drop
                    if (i == size - 1) {
                        if (flightRoute.endsWith("AMD")) {
                            DutyDetails dutyDetails = new DutyDetails();
                            //dutyDetails.setDuty(duty);
                            dutyDetails.setDDName(flightRoute);
                            dutyDetails.setStaff(staff);
                            dutyDetails.setMobileNum(staff.getMobileNum1());
                            dutyDetails.setAddress(staff.getStaffAddress());
                            saveDutyDetails(dutyDetails, arrivalUtcTime, "Drop", reportDate);
                            System.out.println("last Record\n");
                        }
                        continue;
                    }

                    Map<String, Object> nextFlight = flights.get(i + 1);
                    nextDepartureTime = (String) nextFlight.get("deptUtcTime");

                    long timeDifferenceHours = calculateTimeDifference(arrivalUtcTime, nextDepartureTime);
                    System.out.println("Time difference in hours: " + timeDifferenceHours + " hours");

                    if (timeDifferenceHours >= 4) {
                        if (flightRoute.endsWith("AMD")) {
                            DutyDetails dutyDetails = new DutyDetails();
                            //dutyDetails.setDuty(duty);
                            dutyDetails.setDDName(flightRoute);
                            dutyDetails.setStaff(staff);
                            dutyDetails.setMobileNum(staff.getMobileNum1());
                            dutyDetails.setAddress(staff.getStaffAddress());
                            saveDutyDetails(dutyDetails, arrivalUtcTime, "Drop", reportDate);
                            System.out.println("Under middle end\n");
                        }
                        String nextFlightRoute = (String) nextFlight.get("flightRoute");
                        if (nextFlightRoute.startsWith("AMD")) {
                            DutyDetails dutyDetails = new DutyDetails();
                            // dutyDetails.setDuty(duty);
                            dutyDetails.setDDName(nextFlightRoute);
                            dutyDetails.setStaff(staff);
                            dutyDetails.setMobileNum(staff.getMobileNum1());
                            dutyDetails.setAddress(staff.getStaffAddress());
                            saveDutyDetails(dutyDetails, nextDepartureTime, "Pick Up", reportDate);
                            System.out.println("Under Middle start\n");
                        }
                    }
                }
            }
        }

 /*
        // Initialize variables to track previous flight's departure time and staff codes
        Timestamp prevDepartureTime = null;
        Set<String> previousStaffCodes = new HashSet<>();

        for (Map<String, Object> flight : flightDetailsList) {
            String flightRoute = (String) flight.get("flightRoute");
            String deptUtcTime = (String) flight.get("deptUtcTime");
            String arrivalUtcTime = (String) flight.get("arrivalUtcTime");
            List<String> staffCodeList = (ArrayList<String>) flight.get("staffCodeList");

            System.out.println("\nArrayLst");
            System.out.println("Flight Route: " + flightRoute);
            System.out.println("Arrival UTC Time: " + deptUtcTime);
            System.out.println("Departure UTC Time: " + arrivalUtcTime);
            System.out.println("Staff Code List: " + staffCodeList);

        }


        for (Map<String, Object> flightDetails : flightDetailsList) {
            String flightRoute = (String) flightDetails.get("flightRoute");
            String deptUtcTime = (String) flightDetails.get("deptUtcTime");
            String arrivalUtcTime = (String) flightDetails.get("arrivalUtcTime");
            List<String> staffCodeList = (ArrayList<String>) flightDetails.get("staffCodeList");



            // Validate flight details
            if (flightRoute == null || deptUtcTime == null || arrivalUtcTime == null || staffCodeList == null) {
                // Handle null values, log or throw an exception
                System.err.println("Null values found in flight details. Skipping...");
                continue;
            }


            for (String staffCode : staffCodeList) {
                // Check if staff code is repeated
                if (previousStaffCodes.contains(staffCode) && prevDepartureTime != null) {
                    // Calculate time duration between flights
                    long duration = calculateTimeDuration(prevDepartureTime, deptUtcTime, reportDate);
                    System.out.println("Time duration for repeated staff code " + staffCode + ": " + duration + " milliseconds");
                }

                // Update previous staff codes
                previousStaffCodes.add(staffCode);
            }

            // Update previous departure time for the next iteration
            prevDepartureTime = parseTimestamp(arrivalUtcTime, reportDate);
*/

           /* for (String staffCode : staffCodeList) {
                Optional<Staff> optionalStaff = staffRepository.findByStaffCode(staffCode);
                if (optionalStaff.isPresent()) {
                    Staff staff = optionalStaff.get();

                    DutyDetails dutyDetails = new DutyDetails();
                    dutyDetails.setDuty(duty);
                    dutyDetails.setDDName(flightRoute);
                    dutyDetails.setStaff(staff);
                    dutyDetails.setMobileNum(staff.getMobileNum1());
                    dutyDetails.setAddress(staff.getStaffAddress());

                    if (flightRoute.startsWith("AMD") && flightRoute.endsWith("AMD")) {
                        // Create DutyDetails entry for pickup
                        DutyDetails pickupDetails = new DutyDetails(dutyDetails); // Copy constructor
                        saveDutyDetails(pickupDetails, deptUtcTime, "Pick Up", reportDate);
                        // Create DutyDetails entry for pickup
                        DutyDetails dropDetails = new DutyDetails(dutyDetails); // Copy constructor
                        saveDutyDetails(dropDetails, arrivalUtcTime, "Drop", reportDate);
                    } else if (flightRoute.startsWith("AMD")) {
                        saveDutyDetails(dutyDetails, deptUtcTime, "Pick Up", reportDate);

                    } else if (flightRoute.endsWith("AMD")) {
                        saveDutyDetails(dutyDetails, arrivalUtcTime, "Drop", reportDate);
                    } else {
                        // Handle other cases if necessary
                        System.out.println("Else.... ");
                        continue;
                    }
                }
            }*/
 /*        System.out.println("Flight Route: " + flightRoute);
            System.out.println("Arrival UTC Time: " + deptUtcTime);
            System.out.println("Departure UTC Time: " + arrivalUtcTime);
            System.out.println("Staff Code List: " + staffCodeList);
        }
*/
    }

    private static long calculateTimeDifference(String arrivalUtcTime, String departureUtcTime) {
        DateFormat dateFormat = new SimpleDateFormat("HH:mm");
        try {
            Date nextDepartureTime = dateFormat.parse(departureUtcTime);
            Date arrivalTime = dateFormat.parse(arrivalUtcTime);
            long differenceMillis = nextDepartureTime.getTime() - arrivalTime.getTime();
            return TimeUnit.MILLISECONDS.toHours(differenceMillis);
        } catch (ParseException e) {
            e.printStackTrace();
            return -1; // Return -1 if parsing fails
        }
    }

    private long calculateTimeDuration(Timestamp prevArrivalTime, String deptUtcTime, long reportDate) {
        try {
            // Parse arrival time of the current flight
            Timestamp arrivalTimestamp = parseTimestamp(deptUtcTime, reportDate);

            // Calculate time duration in milliseconds
            long durationMillis = arrivalTimestamp.getTime() - prevArrivalTime.getTime();
            System.out.println("durationMillis" + durationMillis);
            long durationMinutes = durationMillis / 60000; // Convert milliseconds to minutes
            System.out.println("Duration in minutes: " + durationMinutes);

            return durationMillis;
        } catch (ParseException e) {
            e.printStackTrace(); // Handle or log parsing errors
            return -1; // Return a default value or handle the error case appropriately
        }
    }

    /**
     * @noinspection deprecation
     */
    private Timestamp parseTimestamp(String timeString, long reportDate) throws ParseException {
        DateFormat dateFormat = new SimpleDateFormat("HH:mm");
        Date date = dateFormat.parse(timeString);
        Timestamp timestamp = new Timestamp(reportDate);
        timestamp.setHours(date.getHours());
        timestamp.setMinutes(date.getMinutes());
        return timestamp;
    }

    /**
     * @noinspection deprecation
     */
    private void saveDutyDetails(DutyDetails dutyDetails, String time, String dutyType, long reportDate) {
        Timestamp timestamp = null;
        try {
            String[] parts = time.split(":");
            int hours = Integer.parseInt(parts[0]);
            int minutes = Integer.parseInt(parts[1]);
            timestamp = new Timestamp(reportDate);
            timestamp.setHours(hours);
            timestamp.setMinutes(minutes);
            dutyDetails.setActPickupTime(timestamp);
            dutyDetails.setDutyType(dutyType);
            System.out.println("Duty Details " + dutyDetailsRepository.save(dutyDetails));
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            e.printStackTrace(); // Handle or log exception
        }
    }


}

/*
sabarmati ashram
72.5575159 23.0443213
Ahmedabad
72.4149307 23.0201581

	14.84 km
 */


//[005207, 012023, 015715, 010532, 015755, 015572, 013280, 005784, 015691, 013372]