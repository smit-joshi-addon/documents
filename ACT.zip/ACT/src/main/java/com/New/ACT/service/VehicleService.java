package com.New.ACT.service;

import com.New.ACT.Repository.VehicleRepository;
import com.New.ACT.model.Airport;
import com.New.ACT.model.Vehicle;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.json.JSONObject;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.WKTReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.sql.Timestamp;
import java.util.*;

@Service
public class VehicleService {
    @Autowired
    VehicleRepository vehicleRepository;

    public Map<String, Object> addVehicle(String vehicleData, HttpServletRequest request) throws JSONException {
        JSONObject jsonData = new JSONObject(vehicleData);
        Map<String, Object> m1 = new HashMap<String, Object>();

        Vehicle vehicle = new Vehicle();
        int vehiclePersonCapacity = 0;
        String vehicleBrand = null;
        String vehicleModel = null;
        String vehiclePlatNum = null;
        Geometry vehicleLocation;

        try {
            //vehiclePersonCapacity Validation
            if (jsonData.has("vehiclePersonCapacity") && !jsonData.get("vehiclePersonCapacity").equals("")
                    && jsonData.get("vehiclePersonCapacity") != null) {
                vehiclePersonCapacity = jsonData.getInt("vehiclePersonCapacity");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide vehiclePersonCapacity.");
                return m1;
            }

            //vehiclePlatNum Validation
            if (jsonData.has("vehiclePlatNum") && !jsonData.get("vehiclePlatNum").equals("")
                    && jsonData.get("vehiclePlatNum") != null) {
                vehiclePlatNum = jsonData.getString("vehiclePlatNum");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide vehiclePlatNum.");
                return m1;
            }

            // vehicleBrand Validation
            if (jsonData.has("vehicleBrand") && !jsonData.get("vehicleBrand").equals("")
                    && jsonData.get("vehicleBrand") != null) {
                vehicleBrand = jsonData.getString("vehicleBrand");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide vehicleBrand.");
                return m1;
            }
            // Airport Location Validation
            if (jsonData.has("vehicleLocation") && !jsonData.get("vehicleLocation").equals("")
                    && jsonData.get("vehicleLocation") != null) {
                // Use JTS to convert the WKT string to a Geometry object
                WKTReader wktReader = new WKTReader();
                vehicleLocation =  wktReader.read(jsonData.getString("vehicleLocation"));
                vehicleLocation.setSRID(4326);
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide Vehicle Location.");
                return m1;
            }

            if (jsonData.has("vehicleModel") && !jsonData.get("vehicleModel").equals("")
                    && jsonData.get("vehicleModel") != null) {
                vehicleModel = jsonData.getString("vehicleModel");
            }
            vehicle.setVehiclePersonCapacity(vehiclePersonCapacity);
            vehicle.setVehicleBrand(vehicleBrand);
            vehicle.setVehicleModel(vehicleModel);
            vehicle.setVehicleLocation(vehicleLocation);
            vehicle.setVehiclePlatNum(vehiclePlatNum);
            vehicle.setCreationTime(new Timestamp(System.currentTimeMillis()));
            vehicle.setActive(true);
            vehicle.setDelete(false);
            String ipAddress = request.getHeader("X-FORWARDED-FOR");
            if (ipAddress == null || ipAddress.isEmpty()) {
                vehicle.setIpAddress(request.getRemoteAddr());
            }
            vehicleRepository.save(vehicle);
            m1.put("status", "success");
            m1.put("message", "Vehicle information saved successfully!!");
            return m1;

        } catch (Exception e) {
            e.printStackTrace();
            m1.put("status", "error");
            m1.put("error", "not_found");
            m1.put("message", "Something went wrong");
            return m1;
        }
    }

    //Get One Record By Id.
    public Map<String, Object> getVehicleById(int vehicleId) {
        Vehicle vehicle;
        Optional<Vehicle> existingVehicleOptional = vehicleRepository.findById(vehicleId);
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            if (existingVehicleOptional.isPresent()) {
                vehicle = existingVehicleOptional.get();
                propertyMap.put("vehicleId", vehicle.getVehicleId());
                propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
                propertyMap.put("vehicle Location", vehicle.getVehicleLocation().toText());
                propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
                propertyMap.put("vehicleModel", vehicle.getVehicleModel());
                propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Vehicle" + vehicleId + " is not longer available.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Vehicle Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> getVehicleByIdJPQL(int vehicleId) {
        Vehicle vehicle;
        Optional<Vehicle> existingVehicleOptional = vehicleRepository.findByVehicleIdJPQL(vehicleId);
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            if (existingVehicleOptional.isPresent()) {
                vehicle = existingVehicleOptional.get();
                propertyMap.put("vehicleId", vehicle.getVehicleId());
                propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
                propertyMap.put("vehicle Location", vehicle.getVehicleLocation().toText());
                propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
                propertyMap.put("vehicleModel", vehicle.getVehicleModel());
                propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Vehicle" + vehicleId + " is not longer available.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Vehicle Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> getActiveVehicleByIdNative(int vehicleId) {
        Vehicle vehicle;
        Optional<Vehicle> existingVehicleOptional = vehicleRepository.findActiveByVehicleIdNative(vehicleId);
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            if (existingVehicleOptional.isPresent()) {
                vehicle = existingVehicleOptional.get();
                propertyMap.put("vehicleId", vehicle.getVehicleId());
                propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
                propertyMap.put("vehicle Location", vehicle.getVehicleLocation().toText());
                propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
                propertyMap.put("vehicleModel", vehicle.getVehicleModel());
                propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Vehicle" + vehicleId + " is not longer available.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Vehicle Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> getVehicleByPlatNum(String vehiclePlatNum) {
        Vehicle vehicle;
        Optional<Vehicle> existingVehicleOptional = vehicleRepository.findByVehiclePlatNum(vehiclePlatNum);
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            if (existingVehicleOptional.isPresent()) {
                vehicle = existingVehicleOptional.get();
                propertyMap.put("vehicleId", vehicle.getVehicleId());
                propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
                propertyMap.put("vehicle Location", vehicle.getVehicleLocation().toText());
                propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
                propertyMap.put("vehicleModel", vehicle.getVehicleModel());
                propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Vehicle" + vehiclePlatNum + " is not longer available.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Vehicle vehiclePlatNum");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> getVehicleByPlatNumJPQL(String vehiclePlatNum) {
        Vehicle vehicle;
        Optional<Vehicle> existingVehicleOptional = vehicleRepository.findByVehiclePlatNumJPQL(vehiclePlatNum);
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            if (existingVehicleOptional.isPresent()) {
                vehicle = existingVehicleOptional.get();
                propertyMap.put("vehicleId", vehicle.getVehicleId());
                propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
                propertyMap.put("vehicle Location", vehicle.getVehicleLocation().toText());
                propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
                propertyMap.put("vehicleModel", vehicle.getVehicleModel());
                propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Vehicle" + vehiclePlatNum + " is not longer available.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Vehicle vehiclePlatNum");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> getVehicleByPlatNumNative(String vehiclePlatNum) {
        Vehicle vehicle;
        Optional<Vehicle> existingVehicleOptional = vehicleRepository.findByVehiclePlatNumNative(vehiclePlatNum);
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            if (existingVehicleOptional.isPresent()) {
                vehicle = existingVehicleOptional.get();
                propertyMap.put("vehicleId", vehicle.getVehicleId());
                propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
                propertyMap.put("vehicle Location", vehicle.getVehicleLocation().toText());
                propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
                propertyMap.put("vehicleModel", vehicle.getVehicleModel());
                propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Vehicle" + vehiclePlatNum + " is not longer available.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Vehicle vehiclePlatNum");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> getVehicleByPersonCapacity(int vPerCap) {
        List<Vehicle> existingVehicleOptional = vehicleRepository.findByVehiclePersonCapacity(vPerCap);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap2.put("vehicleId", vehicle.getVehicleId());
            propertyMap2.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap2.put("vehicle Location", vehicle.getVehicleLocation().toText());
            propertyMap2.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap2.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap2.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;
    }

    public Map<String, Object> getVehicleByPersonCapacityJPQL(int vPerCap) {
        List<Vehicle> existingVehicleOptional = vehicleRepository.findByVehiclePersonCapacityJPQL(vPerCap);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap2.put("vehicleId", vehicle.getVehicleId());
            propertyMap2.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap2.put("vehicle Location", vehicle.getVehicleLocation().toText());
            propertyMap2.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap2.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap2.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;
    }

    public Map<String, Object> getVehicleByPersonCapacityNative(int vPerCap) {
        List<Vehicle> existingVehicleOptional = vehicleRepository.findByVehiclePersonCapacityNative(vPerCap);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap2.put("vehicleId", vehicle.getVehicleId());
            propertyMap2.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap2.put("vehicle Location", vehicle.getVehicleLocation().toText());
            propertyMap2.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap2.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap2.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;
    }

    public Map<String, Object> getVehicleByBrand(String brand) {
        List<Vehicle> existingVehicleOptional = vehicleRepository.findByVehicleBrand(brand);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap2.put("vehicleId", vehicle.getVehicleId());
            propertyMap2.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap2.put("vehicle Location", vehicle.getVehicleLocation().toText());
            propertyMap2.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap2.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap2.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;
    }

    public Map<String, Object> getVehicleByBrandJPQL(String brand) {
        List<Vehicle> existingVehicleOptional = vehicleRepository.findByVehicleBrandJPQL(brand);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap.put("vehicleId", vehicle.getVehicleId());
            propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap.put("vehicle Location", vehicle.getVehicleLocation().toText());
            propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;
    }

    public Map<String, Object> getVehicleByBrandNative(String brand) {
        List<Vehicle> existingVehicleOptional = vehicleRepository.findByVehicleBrandNative(brand);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap.put("vehicleId", vehicle.getVehicleId());
            propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap.put("vehicle Location", vehicle.getVehicleLocation().toText());
            propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;
    }
 public Map<String, Object> getVehicleByModel(String model) {
        List<Vehicle> existingVehicleOptional = vehicleRepository.findByVehicleModel(model);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap.put("vehicleId", vehicle.getVehicleId());
            propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap.put("vehicle Location", vehicle.getVehicleLocation().toText());
            propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;
    }
 public Map<String, Object> getVehicleByModelJPQL(String model) {
        List<Vehicle> existingVehicleOptional = vehicleRepository.findByVehicleModelJPQL(model);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap.put("vehicleId", vehicle.getVehicleId());
            propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap.put("vehicle Location", vehicle.getVehicleLocation().toText());
            propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;
    }
 public Map<String, Object> getVehicleByModelNative(String model) {
        List<Vehicle> existingVehicleOptional = vehicleRepository.findByVehicleModelNative(model);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap.put("vehicleId", vehicle.getVehicleId());
            propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap.put("vehicle Location", vehicle.getVehicleLocation().toText());
            propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;
    }


    // Get Only active Record
    public Map<String, Object> getActiveVehicleById(int vehicleId) {
        Vehicle vehicle;
        Optional<Vehicle> existingVehicleOptional = vehicleRepository.findActiveVehicleById(vehicleId);
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            if (existingVehicleOptional.isPresent()) {
                vehicle = existingVehicleOptional.get();
                propertyMap.put("vehicleId", vehicle.getVehicleId());
                propertyMap.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
                propertyMap.put("vehicle Location", vehicle.getVehicleLocation().toText());
                propertyMap.put("vehicleBrand", vehicle.getVehicleBrand());
                propertyMap.put("vehicleModel", vehicle.getVehicleModel());
                propertyMap.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Vehicle" + vehicleId + " is not longer available.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Vehicle Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    //Get All The Records.
    public Map<String, Object> getAllVehicles() {
        List<Vehicle> existingVehicleOptional = vehicleRepository.findAll();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap2.put("vehicleId", vehicle.getVehicleId());
            propertyMap2.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap2.put("vehicle Location", vehicle.getVehicleLocation().toText());
            propertyMap2.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap2.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap2.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;
    }

    //With Pagination Only Active Records
    public Map<String, Object> getAllVehiclesPagination(Pageable pageable) {
        Page<Vehicle> existingVehicleOptional = vehicleRepository.findAll(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap2.put("vehicleId", vehicle.getVehicleId());
            propertyMap2.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap2.put("vehicle Location", vehicle.getVehicleLocation().toText());
            propertyMap2.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap2.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap2.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;

    }

    // Return Only Active Records
    public Map<String, Object> getAllActiveVehicles() {
        List<Vehicle> existingVehicleOptional = vehicleRepository.findActiveVehicles();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap2.put("vehicleId", vehicle.getVehicleId());
            propertyMap2.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap2.put("vehicle Location", vehicle.getVehicleLocation().toText());
            propertyMap2.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap2.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap2.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;

    }


    // Return Only Active Records
    public Map<String, Object> getAllDeleteVehicles() {
        List<Vehicle> existingVehicleOptional = vehicleRepository.findDeletedVehicles();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap2.put("vehicleId", vehicle.getVehicleId());
            propertyMap2.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap2.put("vehicle Location", vehicle.getVehicleLocation().toText());
            propertyMap2.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap2.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap2.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;

    }

    //With Pagination Only Active Records
    public Map<String, Object> getAllActiveVehiclesPagination(int page, int size, String sort) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sort));
        Page<Vehicle> existingVehicleOptional = vehicleRepository.findActiveVehiclesPagination(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingVehicleOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Vehicle vehicle : existingVehicleOptional) {
            //to assign for each Vehicle
            propertyMap2 = new HashMap<>();
            propertyMap2.put("vehicleId", vehicle.getVehicleId());
            propertyMap2.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            propertyMap2.put("vehicle Location", vehicle.getVehicleLocation().toText());
            propertyMap2.put("vehicleBrand", vehicle.getVehicleBrand());
            propertyMap2.put("vehicleModel", vehicle.getVehicleModel());
            propertyMap2.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Vehicle", data);
        return propertyMap;

    }


    //Update The Vehicle
    public Map<String, Object> updateVehicleById(String vehicleData) throws JSONException {
        JSONObject jsonData = new JSONObject(vehicleData);
        Map<String, Object> map = new HashMap<>();
        int vehicleId = 0;
        Vehicle vehicle;

        try {
            if (jsonData.has("vehicleId") && jsonData.get("vehicleId") != null
                    && !jsonData.get("vehicleId").equals("")) {
                vehicleId = jsonData.getInt("vehicleId");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide vehicleId.");
                return map;
            }
            Optional<Vehicle> existingVehicleOptional = vehicleRepository.findActiveVehicleById(vehicleId);
            if (existingVehicleOptional.isPresent()) {
                vehicle = existingVehicleOptional.get();
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "The Vehicle Does Not Exist.");
                return map;
            }
            if (jsonData.has("vehiclePersonCapacity")) {
                if (!jsonData.get("vehiclePersonCapacity").equals("") && !jsonData.get("vehiclePersonCapacity").equals(null) && jsonData.get("vehiclePersonCapacity") != null) {
                    vehicle.setVehiclePersonCapacity(jsonData.getInt("vehiclePersonCapacity"));
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper vehiclePersonCapacity.");
                    return map;
                }
            }
            if (jsonData.has("vehicleBrand")) {
                if (!jsonData.get("vehicleBrand").equals("") && !jsonData.get("vehicleBrand").equals(null) && jsonData.get("vehicleBrand") != null) {
                    vehicle.setVehicleBrand(jsonData.getString("vehicleBrand"));
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper vehicleBrand.");
                    return map;
                }
            }
            if (jsonData.has("vehicleModel")) {
                if (!jsonData.get("vehicleModel").equals("") && !jsonData.get("vehicleModel").equals(null) && jsonData.get("vehicleModel") != null) {
                    vehicle.setVehicleModel(jsonData.getString("vehicleModel"));
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper vehicleModel.");
                    return map;
                }
            }
            if (jsonData.has("vehiclePlatNum")) {
                if (!jsonData.get("vehiclePlatNum").equals("") && !jsonData.get("vehiclePlatNum").equals(null)
                        && jsonData.get("vehiclePlatNum") != null) {
                    vehicle.setVehiclePlatNum(jsonData.getString("vehiclePlatNum"));
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper vehiclePlatNum.");
                    return map;
                }
            }
            if (jsonData.has("vehicleLocation")) {
                if (!jsonData.get("vehicleLocation").equals("") && !jsonData.get("vehicleLocation").equals(null) && jsonData.get("vehicleLocation") != null) {
                    WKTReader wktReader = new WKTReader();
                    Geometry vehicleLocation =wktReader.read(jsonData.getString("vehicleLocation"));
                    vehicleLocation.setSRID(4326);
                    vehicle.setVehicleLocation(vehicleLocation);
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper vehicleLocation.");
                    return map;
                }
            }
            vehicleRepository.save(vehicle);
            map.put("status", "success");
            map.put("message", "Vehicle id " + vehicleId + " Update Confirmed!!!");

            // Record Show With Only Required Field
            map.put("vehicleId", vehicle.getVehicleId());
            map.put("vehiclePersonCapacity", vehicle.getVehiclePersonCapacity());
            map.put("vehicle Location", vehicle.getVehicleLocation().toText());
            map.put("vehicleBrand", vehicle.getVehicleBrand());
            map.put("vehicleModel", vehicle.getVehicleModel());
            map.put("vehiclePlatNum", vehicle.getVehiclePlatNum());
        } catch (
                Exception e) {
            e.printStackTrace();
            map.put("status", "error");
            map.put("error", "not_found");
            map.put("message", "Something went wrong");
            return map;
        }
        return map;
    }

    // HARD Delete
    public Map<String, Object> delVehicleIdHard(int vehicleId) {
        Map<String, Object> map = new HashMap<>();

        Optional<Vehicle> existingVehicleOptional = vehicleRepository.findById(vehicleId);
        try {
            if (existingVehicleOptional.isPresent()) {
                //airportRepository.deleteById(apId);
                vehicleRepository.deleteById(vehicleId);
                map.put("status", "success");
                map.put("message", "Vehicle id " + vehicleId + " deletion Confirmed!!");
                return map;
            } else {
                map.put("status", "error");
                map.put("error", "no_longer_available");
                map.put("message", "Sorry, this Vehicle " + vehicleId + " does not Existed.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Invalid Airport Id");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }

    // Soft Delete By Id.
    public Map<String, Object> delVehicleById(int vehicleId) {
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            Optional<Vehicle> existingVehicleOptional = vehicleRepository.findActiveVehicleById(vehicleId);
            if (existingVehicleOptional.isPresent()) {
                Vehicle vehicle = existingVehicleOptional.get();

                vehicle.setDelete(true);
                vehicle.setActive(false);
                vehicle.setDeletionTime(new Timestamp(System.currentTimeMillis()));
                vehicleRepository.save(vehicle);
                propertyMap.put("status", "success");
                propertyMap.put("message", "Vehicle soft deletion Confirmed!!");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Vehicle" + vehicleId + " is not Existed.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Vehicle Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    // Revert the record that are only soft deleted
    public Map<String, Object> revertVehicleById(int vehicleId) {
        Map<String, Object> map = new HashMap<>();

        try {
            Optional<Vehicle> existingVehicleOptional = vehicleRepository.findById(vehicleId);
            if (existingVehicleOptional.isPresent()) {
                Vehicle vehicle = existingVehicleOptional.get();

                if (vehicle.isActive() == false && vehicle.isDelete() == true) {
                    vehicle.setDelete(false);
                    vehicle.setActive(true);
                    vehicle.setDeletionTime(null);
                    vehicleRepository.save(vehicle);
                    map.put("status", "success");
                    map.put("message", "Vehicle " + vehicleId + " Revert Confirmed!!");
                    return map;
                } else {
                    map.put("status", "error");
                    map.put("error", "Vehicle can't be Reverted.");
                    return map;
                }
            } else {
                map.put("status", "error");
                map.put("error", "Vehicle " + vehicleId + " field is invalid input.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Please Check Again.");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }


}
