package com.New.ACT.Repository;

import com.New.ACT.model.DutyDetails;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public interface DutyDetailsRepository extends JpaRepository<DutyDetails, Integer> {


    //Fetch the record that are deleted
    List<DutyDetails> findByIsDeleteTrue();

    Optional<DutyDetails> findByDutyDetailsId(int dutyDetailsId);

    @Query(value = "SELECT * FROM duty_details d where d.is_delete = false and d.is_active = true and d.duty_details_id = ?1", nativeQuery = true)
    Optional<DutyDetails> findActiveDutyDetailsById(int dutyDetailsId);


    List<DutyDetails> findByDescriptionIgnoreCase(String description);
    @Query(value = "SELECT * FROM duty_details WHERE LOWER(description) = LOWER(:description)", nativeQuery = true)
    List<DutyDetails> findByDescriptionNative(@Param("description") String description);
    @Query("SELECT d FROM DutyDetails d WHERE LOWER(d.description) = LOWER(:description)")
    List<DutyDetails> findByDescriptionJPQL(@Param("description") String description);


    @Query("SELECT d FROM DutyDetails d WHERE d.distance <= :distance")
    List<DutyDetails> findByDistanceLessJPQL(@Param("distance") double distance);
    @Query(value = "SELECT * FROM duty_details d WHERE d.distance >= :distance",nativeQuery = true)
    List<DutyDetails> findByDistanceHighNative(@Param("distance") double distance);
    List<DutyDetails> findByDistance(@Param("distance") double distance);


    @Query("SELECT d FROM DutyDetails d WHERE d.address = :address")
    List<DutyDetails> findByAddressJPQL(@Param("address") String address);
    List<DutyDetails> findByAddress(@Param("address") String address);
    @Query(value = "SELECT * FROM duty_details d WHERE d.address = :address",nativeQuery = true)
    List<DutyDetails> findByAddressNative(@Param("address") String address);


    @Query("SELECT d FROM DutyDetails d WHERE d.actPickupTime = :actPickupTime")
    List<DutyDetails> findByActPickupTimeJPQL(@Param("actPickupTime") Timestamp actPickupTime);
    List<DutyDetails> findByActPickupTime(@Param("actPickupTime") Timestamp actPickupTime);
    @Query(value = "SELECT * FROM duty_details d WHERE d.act_pickup_time = :actPickupTime",nativeQuery = true)
    List<DutyDetails> findByActPickupTimeNative(@Param("actPickupTime") Timestamp actPickupTime);


    @Query("SELECT d FROM DutyDetails d WHERE d.staffStatus = :staffStatus")
    List<DutyDetails> findByStaffStatusJPQL(@Param("staffStatus") String staffStatus);
    List<DutyDetails> findByStaffStatus(@Param("staffStatus") String staffStatus);
    @Query(value = "SELECT * FROM duty_details d WHERE d.staff_status = :staffStatus",nativeQuery = true)
    List<DutyDetails> findByStaffStatusNative(@Param("staffStatus") String staffStatus);


    @Query("SELECT d FROM DutyDetails d WHERE d.driverName = :driverName")
    List<DutyDetails> findByDriverNameJPQL(@Param("driverName") String driverName);
    List<DutyDetails> findByDriverName(@Param("driverName") String driverName);
    @Query(value = "SELECT * FROM duty_details d WHERE d.driver_name = :driverName",nativeQuery = true)
    List<DutyDetails> findByDriverNameNative(@Param("driverName") String driverName);


    @Query("SELECT d FROM DutyDetails d WHERE d.dutyType = :dutyType")
    List<DutyDetails> findByDutyTypeJPQL(@Param("dutyType") String dutyType);
    List<DutyDetails> findByDutyType(@Param("dutyType") String dutyType);
    @Query(value = "SELECT * FROM duty_details d WHERE d.duty_type = :dutyType",nativeQuery = true)
    List<DutyDetails> findByDutyTypeNative(@Param("dutyType") String dutyType);

    @Query("SELECT d FROM DutyDetails d WHERE d.dDName = :dDName")
    List<DutyDetails> findByDDNameJPQL(@Param("dDName") String dDName);
    //List<DutyDetails> findByDDName(@Param("dDName") String dDName);
    @Query(value = "SELECT * FROM duty_details d WHERE d.d_d_name = :dDName",nativeQuery = true)
    List<DutyDetails> findByDDNameNative(@Param("dDName") String dDName);


    @Query("SELECT d FROM DutyDetails d WHERE d.mobileNum = :mobileNum")
    List<DutyDetails> findByMobileNumJPQL(@Param("mobileNum") String mobileNum);
    List<DutyDetails> findByMobileNum(@Param("mobileNum") String mobileNum);
    @Query(value = "SELECT * FROM duty_details d WHERE d.mobile_num = :mobileNum",nativeQuery = true)
    List<DutyDetails> findByMobileNumNative(@Param("mobileNum") String mobileNum);


    //Through query
    @Query("select d from DutyDetails d where d.isDelete= true and d.isActive = false")
    List<DutyDetails> findAllDeletedDutyDetails();

    @Query("select d from DutyDetails d where d.isDelete= true and d.isActive = false")
    Page<DutyDetails> findAllDeletedDutyDetailsPagination(Pageable pageable);


    // Get the record that are not deleted.
    @Query("select d from DutyDetails d where d.isDelete=false and d.isActive=true")
    List<DutyDetails> findAllActiveDutyDetails();

    @Query("select d from DutyDetails d where d.isDelete=false and d.isActive=true")
    Page<DutyDetails> findAllActiveDutyDetailsPagination(Pageable pageable);


    @Modifying
    @Query("update DutyDetails a set a.isActive=true, a.isDelete = false where a.isDelete = true and a.dutyDetailsId =:dutyDetailsId")
    public void revertDutyDetails(@Param("dutyDetailsId") int dutyDetailsId);

    @Modifying
    @Query(value = "update DutyDetails set is_active = true , is_delete=false where is_delete = true and duty_details_id = :dutyDetailsId", nativeQuery = true)
    public void revertN(@Param("dutyDetailsId") int dutyDetailsId);

    @Modifying
    @Query(value = "UPDATE public.duty_details\n" +
            "\tSET  distance=:distance, driver_name=(select d.driver_name from driver d where driver_id =:driverId), driver_id=:driverId WHERE staff_id = :staffId and duty_id = :dutyId",nativeQuery = true)
    public void updateStaffDriver(Double distance,Integer driverId,Integer staffId,int dutyId);
}
