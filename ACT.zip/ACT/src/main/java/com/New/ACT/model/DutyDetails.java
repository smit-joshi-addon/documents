package com.New.ACT.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import lombok.*;
import org.locationtech.jts.geom.Geometry;

import java.sql.Timestamp;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="duty_details")
public class DutyDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name ="duty_details_id")
    private int dutyDetailsId;
    @Column(name ="description") //pickup or drop
    private String description;
    @Column(name ="distance") // staff-Driver
    private double distance;

    @Column(name ="act_pickup_time")
    private Timestamp actPickupTime;
    @Column(name ="staff_status")
    private String staffStatus;
    @Column(name ="driver_name")
    private String driverName;
    @Column(name ="duty_type")
    private String dutyType;
    @Column(name ="d_d_name")
    private String dDName;
    @Column(name ="mobile_num")
    private String mobileNum;
    @Column(name = "address")
    private String address;


    //Common Columns
    @Column(name ="creation_time")
    private Timestamp creationTime;
    @Column(name ="deletion_time")
    private Timestamp deletionTime;
    @Column(name = "is_active")
    private boolean isActive;
    @Column(name = "is_delete")
    private boolean isDelete;
    @Column(name ="ip_address")
    private String ipAddress;


    @ManyToOne
    @JoinColumn(name = "driver_id")
    private Driver driver;
    @ManyToOne
    @JoinColumn(name = "staff_id")
    private Staff staff;
    @ManyToOne
    @JoinColumn(name = "duty_id")
    private Duty duty;

    public DutyDetails(DutyDetails dutyDetails) {

            this.duty = dutyDetails.getDuty();
            this.dDName = dutyDetails.getDDName();
            this.staff = dutyDetails.getStaff();
            this.mobileNum = dutyDetails.getMobileNum();
            this.address = dutyDetails.getAddress();
    }


    /*@Column(columnDefinition = "geometry")
    private Geometry dutyDetailsLocation;*/

   /* public DutyDetails(){
        this.isActive = true;
        this.isDelete = false;
    }*/
}
