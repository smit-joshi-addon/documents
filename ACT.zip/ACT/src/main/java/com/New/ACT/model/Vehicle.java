package com.New.ACT.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import lombok.*;
import org.locationtech.jts.geom.Geometry;

import java.sql.Timestamp;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="vehicle")
public class Vehicle {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name ="vehicle_id")
    private int vehicleId;
    @Column(name = "vehicle_person_capacity")
    private int vehiclePersonCapacity;
    @Column(name ="vehicle_brand")
    private String vehicleBrand;
    @Column(name ="vehicle_model")
    private String vehicleModel;
    @Column(name = "vehicle_plat_num")
    private String vehiclePlatNum;

    //Common Columns
    @Column(name ="creation_time")
    private Timestamp creationTime;
    @Column(name ="deletion_time")
    private Timestamp deletionTime;
    @Column(name = "is_active")
    private boolean isActive;
    @Column(name = "is_delete")
    private boolean isDelete;
    @Column(name ="ip_address")
    private String ipAddress;

    @Column(columnDefinition = "geometry")
    private Geometry vehicleLocation;

   /* @OneToOne
    @JoinColumn(name = "driver_id")
    private Driver driverId;*/




}
