package com.New.ACT.Repository;

import com.New.ACT.model.Vehicle;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import java.util.List;
import java.util.Optional;

@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, Integer> {

    Optional<Vehicle> findByVehicleId(int vehicleId);
    @Query("select v from Vehicle v where v.vehicleId = :vehicleId")
    Optional<Vehicle> findByVehicleIdJPQL(int vehicleId);
    @Query(value = "select * from Vehicle v where v.vehicle_id = :vehicleId  v.is_delete = false and v.is_active = true",nativeQuery = true)
    Optional<Vehicle> findActiveByVehicleIdNative(int vehicleId);
    @Query("select v from Vehicle v where v.isDelete = false and v.isActive = true and v.vehicleId = :vehicleId")
    Optional<Vehicle> findActiveVehicleById(int vehicleId);

    Optional<Vehicle> findByVehiclePlatNum(String vehiclePlatNum);
    @Query("select v from Vehicle v where v.vehiclePlatNum = :vehiclePlatNum")
    Optional<Vehicle> findByVehiclePlatNumJPQL(String vehiclePlatNum);
    @Query(value = "select * from Vehicle v where v.vehicle_plat_num = :vehiclePlatNum",nativeQuery = true)
    Optional<Vehicle> findByVehiclePlatNumNative(String vehiclePlatNum);

    List<Vehicle> findByVehiclePersonCapacity(int vPerCap);
    @Query("select v from Vehicle v where v.vehiclePersonCapacity = :vPerCap")
    List<Vehicle> findByVehiclePersonCapacityJPQL(int vPerCap);
    @Query(value = "select * from Vehicle v where v.vehicle_person_capacity = :vPerCap",nativeQuery = true)
    List<Vehicle> findByVehiclePersonCapacityNative(int vPerCap);

    List<Vehicle> findByVehicleBrand(String brand);
    @Query("select v from Vehicle v where v.vehicleBrand = :brand")
    List<Vehicle> findByVehicleBrandJPQL(String brand);
    @Query(value = "select * from Vehicle v where v.vehicle_brand = :brand",nativeQuery = true)
    List<Vehicle> findByVehicleBrandNative(String brand);

    List<Vehicle> findByVehicleModel(String model);
    @Query("select v from Vehicle v where v.vehicleModel = :model")
    List<Vehicle> findByVehicleModelJPQL(String model);
    @Query(value = "select * from Vehicle v where v.vehicle_model = :model",nativeQuery = true)
    List<Vehicle> findByVehicleModelNative(String model);


    //Fetch the record that are deleted
    List<Vehicle> findByIsDeleteTrue();

    //Through query
    @Query("select a from Vehicle a where a.isDelete= true")
    List<Vehicle> findDeletedVehicles();

    // Get the record that are not deleted.
    @Query("select v from Vehicle v where v.isDelete=false")
    List<Vehicle> findActiveVehicles();

    @Query(value = "select * from Vehicle v where v.is_Delete=false",nativeQuery = true)
    Page<Vehicle> findActiveVehiclesPagination(Pageable pageable);

    @Modifying
    @Query("update Vehicle v set v.isActive=true, v.isDelete = false where v.isDelete = true and v.vehicleId =:vId")
    public void revertVehicle(@Param("vId") Integer vId);

    @Modifying
    @Query(value ="update vehicle set is_active = true , is_delete=false where is_delete = true and vehicle_id = :vId", nativeQuery = true)
    public void revertN(@Param("vId") Integer vId);
}
