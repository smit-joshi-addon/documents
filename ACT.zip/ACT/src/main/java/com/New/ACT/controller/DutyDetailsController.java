package com.New.ACT.controller;


import com.New.ACT.service.DutyDetailsService;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.catalina.authenticator.SavedRequest;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("dutyDetails")
public class DutyDetailsController {
    @Autowired
    DutyDetailsService dutyDetailsService;

    @PostMapping("add")
    public Map<String, Object> addDutyDetails(@RequestBody String dutyDetailsData, HttpServletRequest request) throws JSONException {
        return dutyDetailsService.addDutyDetails(dutyDetailsData, request);
    }

    // Update Only when Active
    @PutMapping("/updateActiveById")
    public Map<String, Object> updateActiveDutyDetails(String dutyDetailsData) throws JSONException {
        return dutyDetailsService.updateActiveDutyDetails(dutyDetailsData);
    }

    //Get By Id Active
    @GetMapping("/getById")
    public Map<String, Object> getActiveDutyDetailsById(@RequestParam int dutyDetailsId) {
        return dutyDetailsService.getActiveDutyDetailsById(dutyDetailsId);
    }
  //Get By Id Active + Delete
    @GetMapping("/getByIdAll")
    public Map<String, Object> getDutyDetailsById(@RequestParam int dutyDetailsId) {
        return dutyDetailsService.getDutyDetailsById(dutyDetailsId);
    }

    @GetMapping("/getDutyDetailsByDescription")
    public Map<String, Object> getDutyDetailsByDescription(@RequestParam String description) {
        return dutyDetailsService.getDutyDetailsByDescription(description);
    }

    @GetMapping("/getDutyDetailsByDescriptionJPQL")
    public Map<String, Object> getDutyDetailsByDescriptionJPQL(@RequestParam String description) {
        return dutyDetailsService.getDutyDetailsByDescriptionJPQL(description);
    }

    @GetMapping("/getDutyDetailsByDescriptionNative")
    public Map<String, Object> getDutyDetailsByDescriptionNative(@RequestParam String description) {
        return dutyDetailsService.getDutyDetailsByDescriptionNative(description);
    }

    @GetMapping("/getDutyDetailsByDistance")
    public Map<String, Object> getDutyDetailsByDistance(@RequestParam double distance) {
        return dutyDetailsService.getDutyDetailsByDistance(distance);
    }

    @GetMapping("/getDutyDetailsByDistanceLessJPQL")
    public Map<String, Object> getDutyDetailsByDistanceLessJPQL(@RequestParam double distance) {
        return dutyDetailsService.getDutyDetailsByDistanceLessJPQL(distance);
    }

    @GetMapping("/getDutyDetailsByDistanceHighNative")
    public Map<String, Object> getDutyDetailsByDistanceHighNative(@RequestParam double distance) {
        return dutyDetailsService.getDutyDetailsByDistanceHighNative(distance);
    }

    @GetMapping("/getDutyDetailsByStaffStatus")
    public Map<String, Object> getDutyDetailsByStaffStatus(@RequestParam String staffStatus) {
        return dutyDetailsService.getDutyDetailsByStaffStatus(staffStatus);
    }

    @GetMapping("/getDutyDetailsByStaffStatusJPQL")
    public Map<String, Object> getDutyDetailsByStaffStatusJPQL(@RequestParam String staffStatus) {
        return dutyDetailsService.getDutyDetailsByStaffStatusJPQL(staffStatus);
    }

    @GetMapping("/getDutyDetailsByStaffStatusNative")
    public Map<String, Object> getDutyDetailsByStaffStatusNative(@RequestParam String staffStatus) {
        return dutyDetailsService.getDutyDetailsByStaffStatusNative(staffStatus);
    }

    @GetMapping("/getDutyDetailsByDriverName")
    public Map<String, Object> getDutyDetailsByDriverName(@RequestParam String driverName) {
        return dutyDetailsService.getDutyDetailsByDriverName(driverName);
    }

    @GetMapping("/getDutyDetailsByDriverNameJPQL")
    public Map<String, Object> getDutyDetailsByDriverNameJPQL(@RequestParam String driverName) {
        return dutyDetailsService.getDutyDetailsByDriverNameJPQL(driverName);
    }

    @GetMapping("/getDutyDetailsByDriverNameNative")
    public Map<String, Object> getDutyDetailsByDriverNameNative(@RequestParam String driverName) {
        return dutyDetailsService.getDutyDetailsByDriverNameNative(driverName);
    }

    @GetMapping("/getDutyDetailsByDutyType")
    public Map<String, Object> getDutyDetailsByDutyType(@RequestParam String dutyType) {
        return dutyDetailsService.getDutyDetailsByDutyType(dutyType);
    }

    @GetMapping("/getDutyDetailsByDutyTypeJPQL")
    public Map<String, Object> getDutyDetailsByDutyTypeJPQL(@RequestParam String dutyType) {
        return dutyDetailsService.getDutyDetailsByDutyTypeJPQL(dutyType);
    }

    @GetMapping("/getDutyDetailsByDutyTypeNative")
    public Map<String, Object> getDutyDetailsByDutyTypeNative(@RequestParam String dutyType) {
        return dutyDetailsService.getDutyDetailsByDutyTypeNative(dutyType);
    }

  /*  @GetMapping("/getDutyDetailsByDDName")
    public Map<String, Object> getDutyDetailsByDDName(@RequestParam String dDName) {
        return dutyDetailsService.getDutyDetailsByDDName(dDName);
    }*/


    @GetMapping("/getDutyDetailsByDDNameJPQL")
    public Map<String, Object> getDutyDetailsByDDNameJPQL(@RequestParam String dDName) {
        return dutyDetailsService.getDutyDetailsByDDNameJPQL(dDName);
    }


    @GetMapping("/getDutyDetailsByDDNameNative")
    public Map<String, Object> getDutyDetailsByDDNameNative(@RequestParam String dDName) {
        return dutyDetailsService.getDutyDetailsByDDNameNative(dDName);
    }

    @GetMapping("/getDutyDetailsByMobileNum")
    public Map<String, Object> getDutyDetailsByMobileNum(@RequestParam String mobileNum) {
        return dutyDetailsService.getDutyDetailsByMobileNum(mobileNum);
    }
    @GetMapping("/getDutyDetailsByMobileNumJPQL")
    public Map<String, Object> getDutyDetailsByMobileNumJPQL(@RequestParam String mobileNum) {
        return dutyDetailsService.getDutyDetailsByMobileNumJPQL(mobileNum);
    }
    @GetMapping("/getDutyDetailsByMobileNumNative")
    public Map<String, Object> getDutyDetailsByMobileNumNative(@RequestParam String mobileNum) {
        return dutyDetailsService.getDutyDetailsByMobileNumNative(mobileNum);
    }




    // Get all Staff with Deleted
    @GetMapping("/allDutyDetails")
    public Map<String, Object> getAllDutyDetails() {
        return dutyDetailsService.getAllDutyDetails();
    }

    // Get all Airlines without Deleted
    @GetMapping("/allActiveDutyDetails")
    public Map<String, Object> getAllActiveDutyDetails() {
        return dutyDetailsService.getAllActiveDutyDetails();
    }

    // Get all Duty Details without Deleted
    @GetMapping("/allDeleteDutyDetails")
    public Map<String, Object> getAllDeletedDutyDetails() {
        return dutyDetailsService.getAllDeletedDutyDetails();
    }

    //Pagination Get all Duty Details with Deleted
    // If With Path Variable  @GetMapping("/alldutyDetailsPagination" or "/alldutyDetailsPagination/{page}...)
    @GetMapping("/allActiveDutyDetailsPagination")
    public Map<String, Object> getAllActiveDutyDetailsPagination(@RequestParam(defaultValue = "0") int page,
                                                                 @RequestParam(defaultValue = "5") int size,
                                                                 @RequestParam(defaultValue = "dutyDetailsId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).descending());
        return dutyDetailsService.getAllActiveDutyDetailsPagination(pageable);
    }

    @GetMapping("/allDeleteDutyDetailsPagination")
    public Map<String, Object> getAllDeletedDutyDetailsPagination(@RequestParam(defaultValue = "0") int page,
                                                                  @RequestParam(defaultValue = "5") int size,
                                                                  @RequestParam(defaultValue = "dutyDetailsDate") String sortBy) {
        return dutyDetailsService.getAllDeletedDutyDetailsPagination(page, size, sortBy);
    }

    @GetMapping("/allDutyDetailsPagination")
    public Map<String, Object> getAllDutyDetailsPagination(@RequestParam(defaultValue = "0") int page,
                                                           @RequestParam(defaultValue = "5") int size,
                                                           @RequestParam(defaultValue = "dutyDetailsId") String sort) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sort).descending());
        return dutyDetailsService.getAllDutyDetailsPagination(pageable);
    }


    //Soft Delete Through Method
    @DeleteMapping("/deleteById")
    public Map<String, Object> deleteDutyDetailsById(@RequestParam int dutyDetailsId) {
        return dutyDetailsService.deleteDutyDetailsById(dutyDetailsId);
    }

    //Hard Delete Through Method
    @DeleteMapping("/deleteHard")
    public Map<String, Object> delDutyDetailsHard(@RequestParam int dutyDetailsId) {
        return dutyDetailsService.delDutyDetailsHard(dutyDetailsId);
    }

    //Revert Through Method
    @PutMapping("/revertById")
    public Map<String, Object> revertDutyDetailsById(@RequestParam int dutyDetailsId) {
        return dutyDetailsService.revertDutyDetailsById(dutyDetailsId);
    }
}
