package com.New.ACT.service;

import com.New.ACT.Repository.BranchRepository;
import com.New.ACT.Repository.DriverRepository;
import com.New.ACT.Repository.VehicleRepository;
import com.New.ACT.model.*;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.json.JSONObject;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Timestamp;
import java.util.*;

@Service
public class DriverService {

    @Autowired
    DriverRepository driverRepository;

    @Autowired
    BranchRepository branchRepository;

    @Autowired
    VehicleRepository vehicleRepository;

    private String licDirectory = "/home/krishnab/Downloads/ACT/src/main/resources/LicenceImage";
    private String idProofDirectory = "/home/krishnab/Downloads/ACT/src/main/resources/IdProof";
   /* @Value("${image.upload.directory}")
    private String licImgUploadDirectory;*/
/*
    public Map<String, Object> addDriverByObj(Driver driverData, MultipartFile licImg, MultipartFile idProof, HttpServletRequest request) throws JSONException {
        Map<String, Object> m1 = new HashMap<String, Object>();
        Driver driver = new Driver();
        Branch branch = null;
        int branchId = 0;
        Vehicle vehicle = null;
        int vehicleId = 0;

        String driverName = null;
        String driverSex = null;
        String licenceNum = null;
        String mobileNum1 = null;
        String mobileNum2 = null;
        String email1 = null;

        branchId = driverData.getBranchId().getBranchId();
        Optional<Branch> existingBranchOptional = branchRepository.findById(branchId);
        branch = existingBranchOptional.orElse(null);

        if (branch == null) {
            m1.put("status", "error");
            m1.put("error", "no_longer_available");
            m1.put("message", "Sorry, this Branch is not longer available.");
            return m1;
        }
        return m1;
    }*/

    public Map<String, Object> addDriver(String driverData, MultipartFile licImg, MultipartFile
            idProof, HttpServletRequest request) throws JSONException {
        JSONObject jsonData = new JSONObject(driverData);

        Map<String, Object> m1 = new HashMap<String, Object>();
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> propertyMap = new HashMap<String, Object>();
        Map<String, Object> propertyMap2 = new HashMap<>();


        Driver driver = new Driver();
        Branch branch = null;
        int branchId = 0;
        Vehicle vehicle = null;
        int vehicleId = 0;
        Geometry driverLocation = null;

        String driverName = null;
        String driverSex = null;
        String licenceNum = null;
        String mobileNum1 = null;
        String mobileNum2 = null;
        String email1 = null;

        try {
            //Check Foreign Key of Branch Id
            if (jsonData.has("branchId") && jsonData.get("branchId") != null
                    && !jsonData.get("branchId").equals("") && !jsonData.get("branchId").equals(null)) {
                branchId = jsonData.getInt("branchId");
                Optional<Branch> existingBranchOptional = branchRepository.findById(branchId);
                branch = existingBranchOptional.orElse(null);
                //branch = branchRepository.findById(branchId).get();

                if (branch == null) {
                    m1.put("status", "error");
                    m1.put("error", "no_longer_available");
                    m1.put("message", "Sorry, this Branch is not longer available.");
                    return m1;
                }
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field_validation");
                m1.put("message", "Please provide Branch identification like branchId.");
                return m1;
            }
            //Check Foreign Key Of Vehicle ID
            if (jsonData.has("vehicleId") && jsonData.get("vehicleId") != null
                    && !jsonData.get("vehicleId").equals("")) {
                vehicleId = jsonData.getInt("vehicleId");
                Optional<Vehicle> existingVehicleOptional = vehicleRepository.findById(vehicleId);
                vehicle = existingVehicleOptional.orElse(null);

                if (vehicle == null) {
                    m1.put("status", "error");
                    m1.put("error", "no_longer_available");
                    m1.put("message", "Sorry, this Vehicle is not longer available.");
                    return m1;
                }
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field_validation");
                m1.put("message", "Please provide Vehicle identification like vehicleId.");
                return m1;
            }

            //driverName Validation
            if (jsonData.has("driverName") && !jsonData.get("driverName").equals("")
                    && jsonData.get("driverName") != null) {
                driverName = jsonData.getString("driverName");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide driverName.");
                return m1;
            }
            // Driver Location Validation
            if (jsonData.has("driverLocation") && !jsonData.get("driverLocation").equals("")
                    && jsonData.get("driverLocation") != null) {
                // Use JTS to convert the WKT string to a Geometry object
                WKTReader wktReader = new WKTReader();
                driverLocation = wktReader.read(jsonData.getString("driverLocation"));
                driverLocation.setSRID(4326);
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide Driver Location.");
                return m1;
            }

            //driverSex Validation
            if (jsonData.has("driverSex") && !jsonData.get("driverSex").equals("")
                    && jsonData.get("driverSex") != null) {
                driverSex = jsonData.getString("driverSex");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide driverSex.");
                return m1;
            }
            //licenceNum Validation
            if (jsonData.has("licenceNum") && !jsonData.get("licenceNum").equals("")
                    && jsonData.get("licenceNum") != null) {
                licenceNum = jsonData.getString("licenceNum");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide licenceNum.");
                return m1;
            }

            //mobileNum1  Validation
            if (jsonData.has("mobileNum1") && !jsonData.get("mobileNum1").equals("")
                    && jsonData.get("mobileNum1") != null) {
                mobileNum1 = jsonData.getString("mobileNum1");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide mobileNum1.");
                return m1;
            }

            if (jsonData.has("email1") && !jsonData.get("email1").equals("")
                    && jsonData.get("email1") != null) {
                email1 = jsonData.getString("email1");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide email1.");
                return m1;
            }
            if (jsonData.has("mobileNum2") && !jsonData.get("mobileNum2").equals("")
                    && jsonData.get("mobileNum2") != null) {
                mobileNum2 = jsonData.getString("mobileNum2");
            }
            // Image
            if (!licImg.isEmpty()) {
                String licImgName = generateFileName(licImg);
                // Create the Licence Image directory if it doesn't exist
                String licDirectory = "/home/krishnab/Downloads/ACT/src/main/resources/LicenceImage";
                Path licDirectoryPath = Paths.get(licDirectory);
                //Path uploadPath = Path.of(uploadDirectory); can used any
                Path licImgPath = licDirectoryPath.resolve(licImgName);
                System.out.println("FilePath" + licImgPath);

                if (!licDirectoryPath.toFile().exists()) {
                    licDirectoryPath.toFile().mkdirs();
                    System.out.println("Licence Image Directory Created");
                }
                Files.copy(licImg.getInputStream(), licImgPath, StandardCopyOption.REPLACE_EXISTING);
                driver.setLicenceImg(licImgName);
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide idProof.");
                return m1;
            }

            if (!idProof.isEmpty()) {
                String idProofName = generateFileName(idProof);
                //Create The Id Proof Directory If it's Does not exist
                String idProofDirectory = "/home/krishnab/Downloads/ACT/src/main/resources/IdProof";
                Path idProofDirectoryPath = Path.of(idProofDirectory);
                //Path idProofDirectoryPath = Paths.get(idProofDirectory);
                Path idProofImgPath = idProofDirectoryPath.resolve(idProofName);
                System.out.println("idProofImgPath" + idProofImgPath);

                if (!idProofDirectoryPath.toFile().exists()) {
                    idProofDirectoryPath.toFile().mkdir();
                    System.out.println("Id Proof Image Directory Created");
                }
                Files.copy(idProof.getInputStream(), idProofImgPath, StandardCopyOption.REPLACE_EXISTING);
                driver.setIdProof(idProofName);
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide idProof.");
                return m1;
            }

            driver.setBranch(branch);
            driver.setVehicle(vehicle);
            driver.setDriverName(driverName);
            driver.setDriverSex(driverSex);
            driver.setLicenceNum(licenceNum);
            driver.setDriverLocation(driverLocation);

            driver.setMobileNum1(mobileNum1);
            driver.setMobileNum2(mobileNum2);
            driver.setEmail(email1);
            driver.setCreationTime(new Timestamp(System.currentTimeMillis()));
            driver.setActive(true);
            driver.setDelete(false);
            String ipAddress = request.getHeader("X-FORWARDED-FOR");
            if (ipAddress == null || ipAddress.isEmpty()) {
                driver.setIpAddress(request.getRemoteAddr());
            }
            driverRepository.save(driver);

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            propertyMap.put("VehicleId", driver.getVehicle().getVehicleId());
            propertyMap.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            propertyMap.put("VehicleModel", driver.getVehicle().getVehicleModel());
            propertyMap.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            propertyMap.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());

            propertyMap2.put("DriverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap2.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap2.put("IdProof", idProofPath);
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", propertyMap);

            m1.put("Driver",propertyMap2);

            m1.put("Status", "Success");
            m1.put("message", "Driver information saved successfully!!");
            return m1;

        } catch (Exception e) {
            e.printStackTrace();
            m1.put("status", "error");
            m1.put("error", "not_found");
            m1.put("message", "Something went wrong");
            return m1;
        }

    }

    //Update Method
    public Map<String, Object> updateActiveDriver(String driverData, MultipartFile licImg, MultipartFile idProof) throws JSONException {
        JSONObject jsonData = new JSONObject(driverData);
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> propertyMap = new HashMap<>();
        Driver driver;
        int driverId = 0;
        Vehicle vehicle = new Vehicle();
        int vehicleId = 0;
        Branch branch = new Branch();
        int branchId = 0;

        String licImgName = null;
        try {
            if (jsonData.has("driverId") && jsonData.get("driverId") != null
                    && !jsonData.get("driverId").equals("")) {
                driverId = jsonData.getInt("driverId");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide driverId.");
                return map;
            }

            Optional<Driver> existingDriverOptional = driverRepository.findActiveDriverById(driverId);
            if (existingDriverOptional.isPresent()) {
                driver = existingDriverOptional.get();
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "The Driver Does Not Exist.");
                return map;
            }

            if (!driver.getBranch().isActive() && driver.getBranch().isDelete()) {
                map.put("status", "error");
                map.put("error", "no_longer_available_branchId");
                map.put("message", "Sorry, This Branch id is not Updatable.");
                return map;
            }
            if (!driver.getVehicle().isActive() && driver.getVehicle().isDelete()) {
                map.put("status", "error");
                map.put("error", "no_longer_available_vehicleId");
                map.put("message", "Sorry, This Vehicle id is not Updatable.");
                return map;
            }
            if (jsonData.has("branchId") && jsonData.get("branchId") != null
                    && !jsonData.get("branchId").equals("")) {
                branchId = jsonData.getInt("branchId");

                Optional<Branch> existingBranchOptional = branchRepository.findActiveBranchById(branchId);
                if (existingBranchOptional.isPresent()) {
                    branch = existingBranchOptional.get();
                    driver.setBranch(branch);
                } else {
                    map.put("status", "error");
                    map.put("error", "no_longer_available");
                    map.put("message", "Sorry, this Branch id is not in the database.");
                    return map;
                }
            }

            if (jsonData.has("vehicleId") && jsonData.get("vehicleId") != null
                    && !jsonData.get("vehicleId").equals("")) {
                vehicleId = jsonData.getInt("vehicleId");

                Optional<Vehicle> existingVehicleOptional = vehicleRepository.findActiveVehicleById(vehicleId);
                if (existingVehicleOptional.isPresent()) {
                    vehicle = existingVehicleOptional.get();
                    driver.setVehicle(vehicle);
                } else {
                    map.put("status", "error");
                    map.put("error", "no_longer_available");
                    map.put("message", "Sorry, this vehicleId is not in the database.");
                    return map;
                }
            }
            if (jsonData.has("driverLocation")) {
                if (!jsonData.get("driverLocation").equals("") && !jsonData.get("driverLocation").equals(null) && jsonData.get("driverLocation") != null) {
                    WKTReader wktReader = new WKTReader();
                    Geometry driverLocation = wktReader.read(jsonData.getString("driverLocation"));
                    driverLocation.setSRID(4326);
                    driver.setDriverLocation(driverLocation);
                    System.out.println("srid" + driver.getDriverLocation().getSRID() + "type" + driver.getDriverLocation().getGeometryType());
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper airportLocation.");
                    return map;
                }
            }

            if (jsonData.has("driverName") && jsonData.get("driverName") != null
                    && !jsonData.get("driverName").equals("")) {
                driver.setDriverName(jsonData.getString("driverName"));
            }
            // airline Address Update
            if (jsonData.has("driverSex") && !jsonData.get("driverSex").equals("")
                    && jsonData.get("driverSex") != null) {
                driver.setDriverSex(jsonData.getString("driverSex"));
            }
            //Driver mobile NUmber Update
            if (jsonData.has("licenceNum") && !jsonData.get("licenceNum").equals("")
                    && jsonData.get("licenceNum") != null) {
                driver.setLicenceNum(jsonData.getString("licenceNum"));
            }
            if (jsonData.has("mobileNum1") && !jsonData.get("mobileNum1").equals("")
                    && jsonData.get("mobileNum1") != null) {
                driver.setMobileNum1(jsonData.getString("mobileNum1"));
            }
            if (jsonData.has("mobileNum2") && !jsonData.get("mobileNum2").equals("")
                    && jsonData.get("mobileNum2") != null) {
                driver.setMobileNum2(jsonData.getString("mobileNum2"));
            }
            // Email Update
            if (jsonData.has("email1") && !jsonData.get("email1").equals("")
                    && jsonData.get("email1") != null) {
                driver.setEmail(jsonData.getString("email1"));
            }
            if (licImg != null && !licImg.isEmpty()) {
                System.out.println("In the lic Img block");
                licImgName = generateFileName(licImg);
                // Create the Licence Image directory if it doesn't exist
                Path licDirectoryPath = Paths.get(licDirectory);
                //Path uploadPath = Path.of(uploadDirectory); can used any
                Path licImgPath = licDirectoryPath.resolve(licImgName);
                System.out.println("FilePath" + licImgPath);
                if (!licDirectoryPath.toFile().exists()) {
                    licDirectoryPath.toFile().mkdirs();
                    System.out.println("Licence Image Directory Created");
                }
                Files.copy(licImg.getInputStream(), licImgPath, StandardCopyOption.REPLACE_EXISTING);
                driver.setLicenceImg(licImgName);
            }
            if (idProof != null && !idProof.isEmpty()) {
                System.out.println("in the block");
                String idProofName = generateFileName(idProof);
                //Create The Id Proof Directory If it's Does not exist
                Path idProofDirectoryPath = Path.of(idProofDirectory);
                //Path idProofDirectoryPath = Paths.get(idProofDirectory);
                Path idProofImgPath = idProofDirectoryPath.resolve(idProofName);
                System.out.println("idProofImgPath" + idProofImgPath);

                if (!idProofDirectoryPath.toFile().exists()) {
                    idProofDirectoryPath.toFile().mkdir();
                    System.out.println("Id Proof Image Directory Created");
                }
                Files.copy(idProof.getInputStream(), idProofImgPath, StandardCopyOption.REPLACE_EXISTING);
                driver.setIdProof(idProofName);
            }
            driverRepository.save(driver);

            map.put("status", "success");
            map.put("message", "Driver id " + driverId + " Update Confirmed!!!");
            // To Return Driver


            m1.put("BranchId", driver.getBranch().getBranchId());
            m1.put("branchCode", driver.getBranch().getBranchCode());
            m1.put("Branch Address", driver.getBranch().getBranchAddress());
            m1.put("BranchCountry", driver.getBranch().getBranchCountry());
            m1.put("BranchName", driver.getBranch().getBranchName());
            m1.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            propertyMap.put("VehicleId", driver.getVehicle().getVehicleId());
            propertyMap.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            propertyMap.put("VehicleModel", driver.getVehicle().getVehicleModel());
            propertyMap.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            propertyMap.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());
            propertyMap.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());



            map.put("DriverId", driver.getDriverId());
            map.put("DriverName", driver.getDriverName());
            map.put("DriverSex", driver.getDriverSex());
            map.put("Driver Location", driver.getDriverLocation().toText());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            map.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            map.put("IdProof", idProofPath);
            map.put("MobileNum1", driver.getMobileNum1());
            map.put("MobileNum2", driver.getMobileNum2());
            map.put("Email1", driver.getEmail());

            map.put("Branch", m1);
            map.put("Vehicle", propertyMap);

            map.put("message","Driver Updated Successfully");
            map.put("status","Success");
            return map;

        } catch (JSONException | IOException | ParseException e) {
            e.printStackTrace();
            map.put("status", "error");
            map.put("error", "not_found");
            map.put("message", "Something went wrong");
            return map;
        }
    }

    //Get all the airline details
    public Map<String, Object> getAllDrivers() {
        List<Driver> existingDriverOptional = driverRepository.findAll();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap2.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap2.put("IdProof", idProofPath);
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;

    }

    //With Pagination
    //Get all the airline details
    public Map<String, Object> getAllDriversPagination(Pageable pageable) {
        Page<Driver> existingDriverOptional = driverRepository.findAll(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap2.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap2.put("IdProof", idProofPath);
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;

    }

    // Get All Active Records Through Native Query
    public Map<String, Object> getAllActiveDrivers() {
        List<Driver> existingDriverOptional = driverRepository.findActiveDrivers();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap2.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap2.put("IdProof", idProofPath);
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            System.out.println("\n Data" + data);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;

    }

    // Get All Active Records Through Native Query
    public Map<String, Object> getAllActiveDriversPagination(int page, int size, String sort) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sort).descending().and(Sort.by("driver_sex")));
        Page<Driver> existingDriverOptional = driverRepository.findActiveRecords(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap2.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap2.put("IdProof", idProofPath);
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            System.out.println("\n Data" + data);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;

    }

    //Get By ID Function For Active Records
    public Map<String, Object> getActiveDriverById(int driverId) {
        Driver driver;
        Optional<Driver> existingDriverOptional = driverRepository.findActiveDriverById(driverId);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();

        try {
            if (existingDriverOptional.isPresent()) {
                driver = existingDriverOptional.get();

                map.put("BranchId", driver.getBranch().getBranchId());
                map.put("branchCode", driver.getBranch().getBranchCode());
                map.put("Branch Address", driver.getBranch().getBranchAddress());
                map.put("BranchCountry", driver.getBranch().getBranchCountry());
                map.put("BranchName", driver.getBranch().getBranchName());
                map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

                m1.put("VehicleId", driver.getVehicle().getVehicleId());
                m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
                m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
                m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
                m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
                m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


                propertyMap.put("Driver Id", driver.getDriverId());
                propertyMap.put("Driver Name", driver.getDriverName());
                propertyMap.put("Driver Sex", driver.getDriverSex());
                propertyMap.put("Driver Location", driver.getDriverLocation().toText());
                propertyMap.put("Licence Num", driver.getLicenceNum());
                String licImgPath = "/licImg/" + driver.getLicenceImg();
                propertyMap.put("Licence Image", licImgPath);
                String idProofPath = "/idProof/" + driver.getIdProof();
                propertyMap.put("Id Proof", idProofPath);
                propertyMap.put("Mobile Num1", driver.getMobileNum1());
                propertyMap.put("Mobile Num2", driver.getMobileNum2());
                propertyMap.put("Email 1", driver.getEmail());

                propertyMap.put("Branch", map);
                propertyMap.put("Vehicle", m1);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Driver" + driverId + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Driver Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }

    }

    public Map<String, Object> getDriverByIdJPQL(int driverId) {
        Driver driver;
        Optional<Driver> existingDriverOptional = driverRepository.findByDriverIdJPQL(driverId);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();

        try {
            if (existingDriverOptional.isPresent()) {
                driver = existingDriverOptional.get();

                map.put("BranchId", driver.getBranch().getBranchId());
                map.put("branchCode", driver.getBranch().getBranchCode());
                map.put("Branch Address", driver.getBranch().getBranchAddress());
                map.put("BranchCountry", driver.getBranch().getBranchCountry());
                map.put("BranchName", driver.getBranch().getBranchName());
                map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

                m1.put("VehicleId", driver.getVehicle().getVehicleId());
                m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
                m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
                m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
                m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
                m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


                propertyMap.put("Driver Id", driver.getDriverId());
                propertyMap.put("Driver Name", driver.getDriverName());
                propertyMap.put("Driver Sex", driver.getDriverSex());
                propertyMap.put("Driver Location", driver.getDriverLocation().toText());
                propertyMap.put("Licence Num", driver.getLicenceNum());
                String licImgPath = "/licImg/" + driver.getLicenceImg();
                propertyMap.put("Licence Image", licImgPath);
                String idProofPath = "/idProof/" + driver.getIdProof();
                propertyMap.put("Id Proof", idProofPath);
                propertyMap.put("Mobile Num1", driver.getMobileNum1());
                propertyMap.put("Mobile Num2", driver.getMobileNum2());
                propertyMap.put("Email 1", driver.getEmail());

                propertyMap.put("Branch", map);
                propertyMap.put("Vehicle", m1);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Driver" + driverId + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Driver Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }

    }

    public Map<String, Object> getDriverByLicenceNumNative(String licenceNum) {
        Driver driver;
        Optional<Driver> existingDriverOptional = driverRepository.findByLicenceNumNative(licenceNum);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();

        try {
            if (existingDriverOptional.isPresent()) {
                driver = existingDriverOptional.get();

                map.put("BranchId", driver.getBranch().getBranchId());
                map.put("branchCode", driver.getBranch().getBranchCode());
                map.put("Branch Address", driver.getBranch().getBranchAddress());
                map.put("BranchCountry", driver.getBranch().getBranchCountry());
                map.put("BranchName", driver.getBranch().getBranchName());
                map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

                m1.put("VehicleId", driver.getVehicle().getVehicleId());
                m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
                m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
                m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
                m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
                m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


                propertyMap.put("Driver Id", driver.getDriverId());
                propertyMap.put("Driver Name", driver.getDriverName());
                propertyMap.put("Driver Sex", driver.getDriverSex());
                propertyMap.put("Driver Location", driver.getDriverLocation().toText());
                propertyMap.put("Licence Num", driver.getLicenceNum());
                String licImgPath = "/licImg/" + driver.getLicenceImg();
                propertyMap.put("Licence Image", licImgPath);
                String idProofPath = "/idProof/" + driver.getIdProof();
                propertyMap.put("Id Proof", idProofPath);
                propertyMap.put("Mobile Num1", driver.getMobileNum1());
                propertyMap.put("Mobile Num2", driver.getMobileNum2());
                propertyMap.put("Email 1", driver.getEmail());

                propertyMap.put("Branch", map);
                propertyMap.put("Vehicle", m1);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Driver" + licenceNum + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Driver licenceNum");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }

    }

    public Map<String, Object> getDriverByLicenceNum(String licenceNum) {
        Driver driver;
        Optional<Driver> existingDriverOptional = driverRepository.findByLicenceNum(licenceNum);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();

        try {
            if (existingDriverOptional.isPresent()) {
                driver = existingDriverOptional.get();

                map.put("BranchId", driver.getBranch().getBranchId());
                map.put("branchCode", driver.getBranch().getBranchCode());
                map.put("Branch Address", driver.getBranch().getBranchAddress());
                map.put("BranchCountry", driver.getBranch().getBranchCountry());
                map.put("BranchName", driver.getBranch().getBranchName());
                map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

                m1.put("VehicleId", driver.getVehicle().getVehicleId());
                m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
                m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
                m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
                m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
                m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


                propertyMap.put("Driver Id", driver.getDriverId());
                propertyMap.put("Driver Name", driver.getDriverName());
                propertyMap.put("Driver Sex", driver.getDriverSex());
                propertyMap.put("Driver Location", driver.getDriverLocation().toText());
                propertyMap.put("Licence Num", driver.getLicenceNum());
                String licImgPath = "/licImg/" + driver.getLicenceImg();
                propertyMap.put("Licence Image", licImgPath);
                String idProofPath = "/idProof/" + driver.getIdProof();
                propertyMap.put("Id Proof", idProofPath);
                propertyMap.put("Mobile Num1", driver.getMobileNum1());
                propertyMap.put("Mobile Num2", driver.getMobileNum2());
                propertyMap.put("Email 1", driver.getEmail());

                propertyMap.put("Branch", map);
                propertyMap.put("Vehicle", m1);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Driver" + licenceNum + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Driver licenceNum");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }

    }

    public Map<String, Object> getDriverByLicenceNumJPQL(String licenceNum) {
        Driver driver;
        Optional<Driver> existingDriverOptional = driverRepository.findByLicenceNumJPQL(licenceNum);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();

        try {
            if (existingDriverOptional.isPresent()) {
                driver = existingDriverOptional.get();

                map.put("BranchId", driver.getBranch().getBranchId());
                map.put("branchCode", driver.getBranch().getBranchCode());
                map.put("Branch Address", driver.getBranch().getBranchAddress());
                map.put("BranchCountry", driver.getBranch().getBranchCountry());
                map.put("BranchName", driver.getBranch().getBranchName());
                map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

                m1.put("VehicleId", driver.getVehicle().getVehicleId());
                m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
                m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
                m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
                m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
                m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


                propertyMap.put("Driver Id", driver.getDriverId());
                propertyMap.put("Driver Name", driver.getDriverName());
                propertyMap.put("Driver Sex", driver.getDriverSex());
                propertyMap.put("Driver Location", driver.getDriverLocation().toText());
                propertyMap.put("Licence Num", driver.getLicenceNum());
                String licImgPath = "/licImg/" + driver.getLicenceImg();
                propertyMap.put("Licence Image", licImgPath);
                String idProofPath = "/idProof/" + driver.getIdProof();
                propertyMap.put("Id Proof", idProofPath);
                propertyMap.put("Mobile Num1", driver.getMobileNum1());
                propertyMap.put("Mobile Num2", driver.getMobileNum2());
                propertyMap.put("Email 1", driver.getEmail());

                propertyMap.put("Branch", map);
                propertyMap.put("Vehicle", m1);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Driver" + licenceNum + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Driver licenceNum");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }

    }

    public Map<String, Object> getDriverByEmailJPQL(String email) {
        Driver driver;
        Optional<Driver> existingDriverOptional = driverRepository.findByEmailJPQL(email);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();

        try {
            if (existingDriverOptional.isPresent()) {
                driver = existingDriverOptional.get();

                map.put("BranchId", driver.getBranch().getBranchId());
                map.put("branchCode", driver.getBranch().getBranchCode());
                map.put("Branch Address", driver.getBranch().getBranchAddress());
                map.put("BranchCountry", driver.getBranch().getBranchCountry());
                map.put("BranchName", driver.getBranch().getBranchName());
                map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

                m1.put("VehicleId", driver.getVehicle().getVehicleId());
                m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
                m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
                m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
                m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
                m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


                propertyMap.put("Driver Id", driver.getDriverId());
                propertyMap.put("Driver Name", driver.getDriverName());
                propertyMap.put("Driver Sex", driver.getDriverSex());
                propertyMap.put("Driver Location", driver.getDriverLocation().toText());
                propertyMap.put("Licence Num", driver.getLicenceNum());
                String licImgPath = "/licImg/" + driver.getLicenceImg();
                propertyMap.put("Licence Image", licImgPath);
                String idProofPath = "/idProof/" + driver.getIdProof();
                propertyMap.put("Id Proof", idProofPath);
                propertyMap.put("Mobile Num1", driver.getMobileNum1());
                propertyMap.put("Mobile Num2", driver.getMobileNum2());
                propertyMap.put("Email 1", driver.getEmail());

                propertyMap.put("Branch", map);
                propertyMap.put("Vehicle", m1);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Driver" + email + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Driver email");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }

    }

    public Map<String, Object> getDriverByEmailNative(String email) {
        Driver driver;
        Optional<Driver> existingDriverOptional = driverRepository.findByEmailNative(email);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();

        try {
            if (existingDriverOptional.isPresent()) {
                driver = existingDriverOptional.get();

                map.put("BranchId", driver.getBranch().getBranchId());
                map.put("branchCode", driver.getBranch().getBranchCode());
                map.put("Branch Address", driver.getBranch().getBranchAddress());
                map.put("BranchCountry", driver.getBranch().getBranchCountry());
                map.put("BranchName", driver.getBranch().getBranchName());
                map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

                m1.put("VehicleId", driver.getVehicle().getVehicleId());
                m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
                m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
                m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
                m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
                m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


                propertyMap.put("Driver Id", driver.getDriverId());
                propertyMap.put("Driver Name", driver.getDriverName());
                propertyMap.put("Driver Sex", driver.getDriverSex());
                propertyMap.put("Driver Location", driver.getDriverLocation().toText());
                propertyMap.put("Licence Num", driver.getLicenceNum());
                String licImgPath = "/licImg/" + driver.getLicenceImg();
                propertyMap.put("Licence Image", licImgPath);
                String idProofPath = "/idProof/" + driver.getIdProof();
                propertyMap.put("Id Proof", idProofPath);
                propertyMap.put("Mobile Num1", driver.getMobileNum1());
                propertyMap.put("Mobile Num2", driver.getMobileNum2());
                propertyMap.put("Email 1", driver.getEmail());

                propertyMap.put("Branch", map);
                propertyMap.put("Vehicle", m1);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Driver" + email + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Driver email");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }

    }

    public Map<String, Object> getDriverByEmail(String email) {
        Driver driver;
        Optional<Driver> existingDriverOptional = driverRepository.findByEmail(email);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();

        try {
            if (existingDriverOptional.isPresent()) {
                driver = existingDriverOptional.get();

                map.put("BranchId", driver.getBranch().getBranchId());
                map.put("branchCode", driver.getBranch().getBranchCode());
                map.put("Branch Address", driver.getBranch().getBranchAddress());
                map.put("BranchCountry", driver.getBranch().getBranchCountry());
                map.put("BranchName", driver.getBranch().getBranchName());
                map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

                m1.put("VehicleId", driver.getVehicle().getVehicleId());
                m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
                m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
                m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
                m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
                m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


                propertyMap.put("Driver Id", driver.getDriverId());
                propertyMap.put("Driver Name", driver.getDriverName());
                propertyMap.put("Driver Sex", driver.getDriverSex());
                propertyMap.put("Driver Location", driver.getDriverLocation().toText());
                propertyMap.put("Licence Num", driver.getLicenceNum());
                String licImgPath = "/licImg/" + driver.getLicenceImg();
                propertyMap.put("Licence Image", licImgPath);
                String idProofPath = "/idProof/" + driver.getIdProof();
                propertyMap.put("Id Proof", idProofPath);
                propertyMap.put("Mobile Num1", driver.getMobileNum1());
                propertyMap.put("Mobile Num2", driver.getMobileNum2());
                propertyMap.put("Email 1", driver.getEmail());

                propertyMap.put("Branch", map);
                propertyMap.put("Vehicle", m1);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Driver" + email + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Driver email");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }

    }

    public Map<String, Object> getDriverByMobNum(String mobNum) {
        String mobNum2 = mobNum;
        Driver driver;
        Optional<Driver> existingDriverOptional = driverRepository.findByMobileNum1OrMobileNum2(mobNum, mobNum2);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();

        try {
            if (existingDriverOptional.isPresent()) {
                driver = existingDriverOptional.get();

                map.put("BranchId", driver.getBranch().getBranchId());
                map.put("branchCode", driver.getBranch().getBranchCode());
                map.put("Branch Address", driver.getBranch().getBranchAddress());
                map.put("BranchCountry", driver.getBranch().getBranchCountry());
                map.put("BranchName", driver.getBranch().getBranchName());
                map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

                m1.put("VehicleId", driver.getVehicle().getVehicleId());
                m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
                m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
                m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
                m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
                m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


                propertyMap.put("Driver Id", driver.getDriverId());
                propertyMap.put("Driver Name", driver.getDriverName());
                propertyMap.put("Driver Sex", driver.getDriverSex());
                propertyMap.put("Driver Location", driver.getDriverLocation().toText());
                propertyMap.put("Licence Num", driver.getLicenceNum());
                String licImgPath = "/licImg/" + driver.getLicenceImg();
                propertyMap.put("Licence Image", licImgPath);
                String idProofPath = "/idProof/" + driver.getIdProof();
                propertyMap.put("Id Proof", idProofPath);
                propertyMap.put("Mobile Num1", driver.getMobileNum1());
                propertyMap.put("Mobile Num2", driver.getMobileNum2());
                propertyMap.put("Email 1", driver.getEmail());

                propertyMap.put("Branch", map);
                propertyMap.put("Vehicle", m1);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Driver" + mobNum + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Driver mobNum");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }

    }

    public Map<String, Object> getDriverByMobNumJPQL(String mobNum) {
        Driver driver;
        Optional<Driver> existingDriverOptional = driverRepository.findByDriverMobNumPQL(mobNum);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();

        try {
            if (existingDriverOptional.isPresent()) {
                driver = existingDriverOptional.get();

                map.put("BranchId", driver.getBranch().getBranchId());
                map.put("branchCode", driver.getBranch().getBranchCode());
                map.put("Branch Address", driver.getBranch().getBranchAddress());
                map.put("BranchCountry", driver.getBranch().getBranchCountry());
                map.put("BranchName", driver.getBranch().getBranchName());
                map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

                m1.put("VehicleId", driver.getVehicle().getVehicleId());
                m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
                m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
                m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
                m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
                m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


                propertyMap.put("Driver Id", driver.getDriverId());
                propertyMap.put("Driver Name", driver.getDriverName());
                propertyMap.put("Driver Sex", driver.getDriverSex());
                propertyMap.put("Driver Location", driver.getDriverLocation().toText());
                propertyMap.put("Licence Num", driver.getLicenceNum());
                String licImgPath = "/licImg/" + driver.getLicenceImg();
                propertyMap.put("Licence Image", licImgPath);
                String idProofPath = "/idProof/" + driver.getIdProof();
                propertyMap.put("Id Proof", idProofPath);
                propertyMap.put("Mobile Num1", driver.getMobileNum1());
                propertyMap.put("Mobile Num2", driver.getMobileNum2());
                propertyMap.put("Email 1", driver.getEmail());

                propertyMap.put("Branch", map);
                propertyMap.put("Vehicle", m1);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Driver" + mobNum + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Driver mobNum");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }

    }

    public Map<String, Object> getDriverByMobNumNative(String mobNum) {
        Driver driver;
        Optional<Driver> existingDriverOptional = driverRepository.findByDriverMobNumNative(mobNum);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();

        try {
            if (existingDriverOptional.isPresent()) {
                driver = existingDriverOptional.get();

                map.put("BranchId", driver.getBranch().getBranchId());
                map.put("branchCode", driver.getBranch().getBranchCode());
                map.put("Branch Address", driver.getBranch().getBranchAddress());
                map.put("BranchCountry", driver.getBranch().getBranchCountry());
                map.put("BranchName", driver.getBranch().getBranchName());
                map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

                m1.put("VehicleId", driver.getVehicle().getVehicleId());
                m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
                m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
                m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
                m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
                m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


                propertyMap.put("Driver Id", driver.getDriverId());
                propertyMap.put("Driver Name", driver.getDriverName());
                propertyMap.put("Driver Sex", driver.getDriverSex());
                propertyMap.put("Driver Location", driver.getDriverLocation().toText());
                propertyMap.put("Licence Num", driver.getLicenceNum());
                String licImgPath = "/licImg/" + driver.getLicenceImg();
                propertyMap.put("Licence Image", licImgPath);
                String idProofPath = "/idProof/" + driver.getIdProof();
                propertyMap.put("Id Proof", idProofPath);
                propertyMap.put("Mobile Num1", driver.getMobileNum1());
                propertyMap.put("Mobile Num2", driver.getMobileNum2());
                propertyMap.put("Email 1", driver.getEmail());

                propertyMap.put("Branch", map);
                propertyMap.put("Vehicle", m1);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Driver" + mobNum + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Driver mobNum");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }

    }

    public Map<String, Object> getDriverByName(String driverName) {
        List<Driver> existingDriverOptional = driverRepository.findByDriverName(driverName);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap.put("IdProof", idProofPath);
            propertyMap2.put("LicenceImg", driver.getLicenceImg());
            propertyMap2.put("IdProof", driver.getIdProof());
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            System.out.println("\n Data" + data);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;

    }

    public Map<String, Object> getDriverByNameJPQL(String driverSex) {
        List<Driver> existingDriverOptional = driverRepository.findByDriverNameJPQL(driverSex);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap.put("IdProof", idProofPath);
            propertyMap2.put("LicenceImg", driver.getLicenceImg());
            propertyMap2.put("IdProof", driver.getIdProof());
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);

        }

        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;

    }

    public Map<String, Object> getDriverByNameNative(String driverName) {
        List<Driver> existingDriverOptional = driverRepository.findByDriverNameNative(driverName);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap.put("IdProof", idProofPath);
            propertyMap2.put("LicenceImg", driver.getLicenceImg());
            propertyMap2.put("IdProof", driver.getIdProof());
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);

        }
        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;
    }

    public Map<String, Object> getDriverByBranch(Branch branch) {
        List<Driver> existingDriverOptional = driverRepository.findByBranch(branch);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap.put("IdProof", idProofPath);
            propertyMap2.put("LicenceImg", driver.getLicenceImg());
            propertyMap2.put("IdProof", driver.getIdProof());
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);

        }
        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;
    }

    public Map<String, Object> getDriverByBranchNative(int branchId) {
        List<Driver> existingDriverOptional = driverRepository.findByBranchNative(branchId);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap.put("IdProof", idProofPath);
            propertyMap2.put("LicenceImg", driver.getLicenceImg());
            propertyMap2.put("IdProof", driver.getIdProof());
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);

        }
        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;
    }

    public Map<String, Object> getDriverByBranchJPQL(Branch branch) {
        List<Driver> existingDriverOptional = driverRepository.findByBranchJPQL(branch);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap.put("IdProof", idProofPath);
            propertyMap2.put("LicenceImg", driver.getLicenceImg());
            propertyMap2.put("IdProof", driver.getIdProof());
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);

        }

        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;

    }

    public Map<String, Object> getDriverByVehicle(Vehicle vehicle) {
        List<Driver> existingDriverOptional = driverRepository.findByVehicleJPQL(vehicle);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap.put("IdProof", idProofPath);
            propertyMap2.put("LicenceImg", driver.getLicenceImg());
            propertyMap2.put("IdProof", driver.getIdProof());
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);

        }

        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;

    }

    public Map<String, Object> getDriverByVehicleNative(int vehicleId) {
        List<Driver> existingDriverOptional = driverRepository.findByVehicleNative(vehicleId);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap.put("IdProof", idProofPath);
            propertyMap2.put("LicenceImg", driver.getLicenceImg());
            propertyMap2.put("IdProof", driver.getIdProof());
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);

        }

        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;

    }

    public Map<String, Object> getDriverByVehicleJPQL(Vehicle vehicle) {
        List<Driver> existingDriverOptional = driverRepository.findByVehicleJPQL(vehicle);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap.put("IdProof", idProofPath);
            propertyMap2.put("LicenceImg", driver.getLicenceImg());
            propertyMap2.put("IdProof", driver.getIdProof());
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);

        }

        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;

    }

    public Map<String, Object> getDriverBySex(String driverSex) {
        List<Driver> existingDriverOptional = driverRepository.findByDriverSex(driverSex);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap.put("IdProof", idProofPath);
            propertyMap2.put("LicenceImg", driver.getLicenceImg());
            propertyMap2.put("IdProof", driver.getIdProof());
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            System.out.println("\n Data" + data);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;

    }

    public Map<String, Object> getDriverBySexJPQL(String driverSex) {
        List<Driver> existingDriverOptional = driverRepository.findByDriverSexJPQL(driverSex);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap.put("IdProof", idProofPath);
            propertyMap2.put("LicenceImg", driver.getLicenceImg());
            propertyMap2.put("IdProof", driver.getIdProof());
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            System.out.println("\n Data" + data);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;

    }

    public Map<String, Object> getDriverBySexNative(String driverSex) {
        List<Driver> existingDriverOptional = driverRepository.findByDriverSexNative(driverSex);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap.put("IdProof", idProofPath);
            propertyMap2.put("LicenceImg", driver.getLicenceImg());
            propertyMap2.put("IdProof", driver.getIdProof());
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            System.out.println("\n Data" + data);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;

    }

    public Map<String, Object> getDriverByIdNative(int driverId) {
        Driver driver;
        Optional<Driver> existingDriverOptional = driverRepository.findByDriverIdNative(driverId);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();

        try {
            if (existingDriverOptional.isPresent()) {
                driver = existingDriverOptional.get();

                map.put("BranchId", driver.getBranch().getBranchId());
                map.put("branchCode", driver.getBranch().getBranchCode());
                map.put("Branch Address", driver.getBranch().getBranchAddress());
                map.put("BranchCountry", driver.getBranch().getBranchCountry());
                map.put("BranchName", driver.getBranch().getBranchName());
                map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

                m1.put("VehicleId", driver.getVehicle().getVehicleId());
                m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
                m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
                m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
                m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
                m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


                propertyMap.put("Driver Id", driver.getDriverId());
                propertyMap.put("Driver Name", driver.getDriverName());
                propertyMap.put("Driver Sex", driver.getDriverSex());
                propertyMap.put("Driver Location", driver.getDriverLocation().toText());
                propertyMap.put("Licence Num", driver.getLicenceNum());
                String licImgPath = "/licImg/" + driver.getLicenceImg();
                propertyMap.put("Licence Image", licImgPath);
                String idProofPath = "/idProof/" + driver.getIdProof();
                propertyMap.put("Id Proof", idProofPath);
                propertyMap.put("Mobile Num1", driver.getMobileNum1());
                propertyMap.put("Mobile Num2", driver.getMobileNum2());
                propertyMap.put("Email 1", driver.getEmail());

                propertyMap.put("Branch", map);
                propertyMap.put("Vehicle", m1);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Driver" + driverId + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Driver Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }

    }


    //Get By ID Function For All Records
    public Map<String, Object> getDriverById(int driverId) {
        Driver driver;
        Optional<Driver> existingDriverOptional = driverRepository.findById(driverId);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();

        try {
            if (existingDriverOptional.isPresent()) {
                driver = existingDriverOptional.get();

                map.put("BranchId", driver.getBranch().getBranchId());
                map.put("branchCode", driver.getBranch().getBranchCode());
                map.put("Branch Address", driver.getBranch().getBranchAddress());
                map.put("BranchCountry", driver.getBranch().getBranchCountry());
                map.put("BranchName", driver.getBranch().getBranchName());
                map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

                m1.put("VehicleId", driver.getVehicle().getVehicleId());
                m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
                m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
                m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
                m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
                m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


                propertyMap.put("Driver Id", driver.getDriverId());
                propertyMap.put("Driver Name", driver.getDriverName());
                propertyMap.put("Driver Sex", driver.getDriverSex());
                propertyMap.put("Driver Location", driver.getDriverLocation().toText());
                propertyMap.put("Licence Num", driver.getLicenceNum());
                String licImgPath = "/licImg/" + driver.getLicenceImg();
                propertyMap.put("Licence Image", licImgPath);
                String idProofPath = "/idProof/" + driver.getIdProof();
                propertyMap.put("Id Proof", idProofPath);
                propertyMap.put("Mobile Num1", driver.getMobileNum1());
                propertyMap.put("Mobile Num2", driver.getMobileNum2());
                propertyMap.put("Email 1", driver.getEmail());

                propertyMap.put("Branch", map);
                propertyMap.put("Vehicle", m1);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Driver" + driverId + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Driver Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }

    }

    // Get All Delete Records Through Auto Query
    public Map<String, Object> getAllDeleteDrivers() {
        List<Driver> existingDriverOptional = driverRepository.findByIsDeleteTrue();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap.put("IdProof", idProofPath);
            propertyMap2.put("LicenceImg", driver.getLicenceImg());
            propertyMap2.put("IdProof", driver.getIdProof());
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            System.out.println("\n Data" + data);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;
    }

    // Get All Delete Records With Pagination with JPQL
    public Map<String, Object> getAllDeleteDriversPagination(Pageable pageable) {
        Page<Driver> existingDriverOptional = driverRepository.findDeletedRecords(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingDriverOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Driver Details not found");
            return propertyMap;
        }

        for (Driver driver : existingDriverOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            m1 = new HashMap<>();

            map.put("BranchId", driver.getBranch().getBranchId());
            map.put("branchCode", driver.getBranch().getBranchCode());
            map.put("Branch Address", driver.getBranch().getBranchAddress());
            map.put("BranchCountry", driver.getBranch().getBranchCountry());
            map.put("BranchName", driver.getBranch().getBranchName());
            map.put("Branch Location", driver.getBranch().getBranchLocation().toText());

            m1.put("VehicleId", driver.getVehicle().getVehicleId());
            m1.put("VehicleBrand", driver.getVehicle().getVehicleBrand());
            m1.put("VehicleModel", driver.getVehicle().getVehicleModel());
            m1.put("VehiclePlatNum", driver.getVehicle().getVehiclePlatNum());
            m1.put("VehiclePersonCapacity", driver.getVehicle().getVehiclePersonCapacity());
            m1.put("Vehicle Location", driver.getVehicle().getVehicleLocation().toText());


            propertyMap2.put("DiverId", driver.getDriverId());
            propertyMap2.put("DriverName", driver.getDriverName());
            propertyMap2.put("DriverSex", driver.getDriverSex());
            propertyMap2.put("Driver Location", driver.getDriverLocation().toText());
            propertyMap2.put("LicenceNum", driver.getLicenceNum());
            String licImgPath = "/licImg/" + driver.getLicenceImg();
            propertyMap.put("Licence Image", licImgPath);
            String idProofPath = "/idProof/" + driver.getIdProof();
            propertyMap.put("IdProof", idProofPath);
            propertyMap2.put("LicenceImg", driver.getLicenceImg());
            propertyMap2.put("IdProof", driver.getIdProof());
            propertyMap2.put("MobileNum1", driver.getMobileNum1());
            propertyMap2.put("MobileNum2", driver.getMobileNum2());
            propertyMap2.put("Email1", driver.getEmail());

            propertyMap2.put("Branch", map);
            propertyMap2.put("Vehicle", m1);
            data.add(propertyMap2);
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            System.out.println("\n Data" + data);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Driver", data);
        return propertyMap;
    }

    //Soft Delete only if Active Record
    public Map<String, Object> delActiveDriverById(int driverId) {
        Map<String, Object> propertyMap = new HashMap<>();
        try {
            Optional<Driver> existingDriverOptional = driverRepository.findActiveDriverById(driverId);
            if (existingDriverOptional.isPresent()) {
                Driver driver = existingDriverOptional.get();
                driver.setDelete(true);
                driver.setActive(false);
                driver.setDeletionTime(new Timestamp(System.currentTimeMillis()));
                driverRepository.save(driver);
                propertyMap.put("status", "success");
                propertyMap.put("message", "Driver soft deletion Confirmed!!");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Driver" + driverId + " is not Existed.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Driver Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> delDriverById(int driverId) {
        Map<String, Object> map = new HashMap<>();

        Optional<Driver> existingDriverOptional = driverRepository.findById(driverId);

        try {
            if (existingDriverOptional.isPresent()) {
                driverRepository.deleteById(driverId);
                map.put("status", "success");
                map.put("message", "Driver id " + driverId + " deletion Confirmed!!");
                return map;
            } else {
                map.put("status", "error");
                map.put("error", "no_longer_available");
                map.put("message", "Sorry, this Driver " + driverId + " does not Existed.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Invalid Driver Id");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }

    public Map<String, Object> revertDriverById(int driverId) {
        Map<String, Object> map = new HashMap<>();
        try {
            Optional<Driver> existingDriverOptional = driverRepository.findById(driverId);
            if (existingDriverOptional.isPresent()) {
                Driver driver = existingDriverOptional.get();

                if (driver.isActive() == false && driver.isDelete() == true) {
                    driver.setDelete(false);
                    driver.setActive(true);
                    driver.setDeletionTime(null);
                    driverRepository.save(driver);
                    map.put("status", "success");
                    map.put("message", "driver " + driverId + " Revert Confirmed!!");
                    return map;
                } else {
                    map.put("status", "error");
                    map.put("error", "driver can't be Reverted.");
                    return map;
                }
            } else {
                map.put("status", "error");
                map.put("error", "driver " + driverId + " field is invalid input.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Please Check Again.");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }

    public String generateFileName(MultipartFile imgFile) {
        String originalFileName = imgFile.getOriginalFilename();
        String fileExtension = "";
        String fileNameWithoutExtension = "";

        // Check if the originalFileName contains a file extension
        int lastDotIndex = originalFileName.lastIndexOf('.');
        if (lastDotIndex != -1) {
            fileExtension = originalFileName.substring(lastDotIndex);
            fileNameWithoutExtension = originalFileName.substring(0, lastDotIndex);
        }
        String timestampName = fileNameWithoutExtension + System.currentTimeMillis() + fileExtension;
        System.out.println("File Name " + timestampName);
        return timestampName;
    }


    public List<Object[]> findNearestStaffByDriver(double radius) {
        List<Object[]> staffs = driverRepository.findNearestStaffByDriver(radius);
        System.out.println("Staff & Driver "+staffs);
        return staffs;
    }
}
