package com.New.ACT.service;

import com.New.ACT.Repository.BranchRepository;
import com.New.ACT.model.Airport;
import com.New.ACT.model.Branch;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.json.JSONObject;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.Point;
import org.locationtech.jts.io.WKTReader;
import org.locationtech.jts.io.WKTWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.*;

@Service
public class BranchService {
    @Autowired
    BranchRepository branchRepository;


    public Map<String, Object> addBranch(String branchData, HttpServletRequest request) throws JSONException {
        JSONObject jsonData = new JSONObject(branchData);
        Map<String, Object> map = new HashMap<>();

        Branch branch = new Branch();
        int branchId = 0;
        String branchName = null;
        String branchAddress = null;
        String branchCountry = null;
        String branchCode = null;
        Geometry branchLocation ;
        try {
            //branch Name Validation
            if (jsonData.has("branchName") && !jsonData.get("branchName").equals("")
                    && jsonData.get("branchName") != null && !jsonData.get("branchName").equals(null)) {
                branchName = jsonData.getString("branchName");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide branchName.");
                return map;
            }

            // branchAddress Validation
            if (jsonData.has("branchAddress") && !jsonData.get("branchAddress").equals("")
                    && jsonData.get("branchAddress") != null) {
                branchAddress = jsonData.getString("branchAddress");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide branchAddress.");
                return map;
            }

            // branchCountry Validation
            if (jsonData.has("branchCountry") && !jsonData.get("branchCountry").equals("")
                    && jsonData.get("branchCountry") != null) {
                branchCountry = jsonData.getString("branchCountry");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide branchCountry.");
                return map;
            }

            if (jsonData.has("branchCode") && !jsonData.get("branchCode").equals("")
                    && jsonData.get("branchCode") != null) {
                branchCode = jsonData.getString("branchCode");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide branchCode.");
                return map;
            }
            // Branch Location Validation
            if (jsonData.has("branchLocation") && !jsonData.get("branchLocation").equals("")
                    && jsonData.get("branchLocation") != null) {
                // Use JTS to convert the WKT string to a Geometry object
                WKTReader wktReader = new WKTReader();
                branchLocation =  wktReader.read(jsonData.getString("branchLocation"));
                branchLocation.setSRID(4326);
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide  branchLocation.");
                return map;
            }


            branch.setBranchName(branchName);
            branch.setBranchCode(branchCode);
            branch.setBranchCountry(branchCountry);
            branch.setBranchAddress(branchAddress);
            branch.setBranchLocation(branchLocation);
            branch.setCreationTime(new Timestamp(System.currentTimeMillis()));
            branch.setActive(true);
            branch.setDelete(false);
            String ipAddress = request.getHeader("X-FORWARDED-FOR");
            if (ipAddress == null || ipAddress.isEmpty()) {
                branch.setIpAddress(request.getRemoteAddr());
            }
            branchRepository.save(branch);

            map.put("status", "success");
            map.put("message", "Branch information saved successfully!!");
            return map;

        } catch (Exception e) {
            e.printStackTrace();
            map.put("status", "error");
            map.put("error", "not_found");
            map.put("message", "Something went wrong");
            return map;
        }

    }

    //Update
    public Map<String, Object> updateBranchById(String branchData) throws JSONException {
        JSONObject jsonData = new JSONObject(branchData);
        Map<String, Object> map = new HashMap<>();
        int branchId = 0;
        Branch branch;
        Geometry branchLocation;
        try {
            if (jsonData.has("branchId") && jsonData.get("branchId") != null
                    && !jsonData.get("branchId").equals("")) {
                branchId = jsonData.getInt("branchId");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide branchId.");
                return map;
            }
            Optional<Branch> existingBranchOptional = branchRepository.findActiveBranchById(branchId);
            if (existingBranchOptional.isPresent()) {
                branch = existingBranchOptional.get();
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "The Branch Does Not Exist.");
                return map;
            }

            if (jsonData.has("branchAddress")) {
                if (!jsonData.get("branchAddress").equals("") && jsonData.get("branchAddress") != null) {
                    branch.setBranchAddress(jsonData.getString("branchAddress"));
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper branchAddress.");
                    return map;
                }
            }
            if (jsonData.has("branchCountry")) {
                if (!jsonData.get("branchCountry").equals("") && jsonData.get("branchCountry") != null) {
                    branch.setBranchCountry(jsonData.getString("branchCountry"));
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper branchCountry.");
                    return map;
                }
            }
            if (jsonData.has("branchName")) {
                if (!jsonData.get("branchName").equals("") && !jsonData.get("branchName").equals(null) && jsonData.get("branchName") != null) {
                    branch.setBranchName(jsonData.getString("branchName"));
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper branchName.");
                    return map;
                }
            }
            if (jsonData.has("branchCode")) {
                if (!jsonData.get("branchCode").equals("") && !jsonData.get("branchCode").equals(null) && jsonData.get("branchCode") != null) {
                    branch.setBranchCode(jsonData.getString("branchCode"));
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper branchCode.");
                    return map;
                }
            }
            if (jsonData.has("branchLocation")) {
                if (!jsonData.get("branchLocation").equals("") && !jsonData.get("branchLocation").equals(null) && jsonData.get("branchLocation") != null) {
                    WKTReader wktReader = new WKTReader();
                    branchLocation =wktReader.read(jsonData.getString("branchLocation"));
                    branchLocation.setSRID(4326);
                    branch.setBranchLocation(branchLocation);
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper branchLocation.");
                    return map;
                }
            }

            branchRepository.save(branch);
            map.put("status", "success");
            map.put("message", "Branch id : " + branchId + " Update Confirmed!!!");
            // Record Show With Only Required Field
            map.put("Branch Id", branch.getBranchId());
            map.put("branch Code", branch.getBranchCode());
            map.put("Branch Address", branch.getBranchAddress());
            map.put("Branch Location", branch.getBranchLocation().toText());
            map.put("Branch Country", branch.getBranchCountry());
            map.put("Branch Name", branch.getBranchName());

        } catch (Exception e) {
            e.printStackTrace();
            map.put("status", "error");
            map.put("error", "not_found");
            map.put("message", "Something went wrong");
            return map;
        }
        return map;

    }

    //Request Param Get By Id
    public Map<String, Object> getBranchById(int brId) {
        Branch branch;
        Optional<Branch> existingBranchOptional = branchRepository.findById(brId);

        Map<String, Object> propertyMap = new HashMap<>();

        try {
            if (existingBranchOptional.isPresent()) {
                branch = existingBranchOptional.get();
                propertyMap.put("BranchId", branch.getBranchId());
                propertyMap.put("branchCode", branch.getBranchCode());
                propertyMap.put("Branch Address", branch.getBranchAddress());
                propertyMap.put("Branch Location", branch.getBranchLocation().toText());
                propertyMap.put("BranchCountry", branch.getBranchCountry());
                propertyMap.put("BranchName", branch.getBranchName());
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Branch" + brId + " is not longer available.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Branch Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> getActiveBranchByIdJPQL(int branchId) {
        Branch branch;
        Optional<Branch> existingBranchOptional = branchRepository.findActiveByBranchIdJPQL(branchId);
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            if (existingBranchOptional.isPresent()) {
                branch = existingBranchOptional.get();
                propertyMap.put("BranchId", branch.getBranchId());
                propertyMap.put("branchCode", branch.getBranchCode());
                propertyMap.put("Branch Address", branch.getBranchAddress());
                propertyMap.put("Branch Location", branch.getBranchLocation().toText());
                propertyMap.put("BranchCountry", branch.getBranchCountry());
                propertyMap.put("BranchName", branch.getBranchName());
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Branch" + branchId + " is not longer available.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Branch Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> getBranchByIdNative(int branchId) {
        Branch branch;
        Optional<Branch> existingBranchOptional = branchRepository.findByBranchIdNative(branchId);
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            if (existingBranchOptional.isPresent()) {
                branch = existingBranchOptional.get();
                propertyMap.put("BranchId", branch.getBranchId());
                propertyMap.put("branchCode", branch.getBranchCode());
                propertyMap.put("Branch Address", branch.getBranchAddress());
                propertyMap.put("Branch Location", branch.getBranchLocation().toText());
                propertyMap.put("BranchCountry", branch.getBranchCountry());
                propertyMap.put("BranchName", branch.getBranchName());
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Branch" + branchId + " is not longer available.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Branch Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }


    public Map<String, Object> getBranchByNameNative(String branchName) {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();
        List<Branch> branches = branchRepository.findByBranchNameNative(branchName);

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
            System.out.println("\nProperty Map ====\n" + map2);
            System.out.println("\n Branches" + data);
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    public Map<String, Object> getBranchByNameJPQL(String branchName) {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();
        List<Branch> branches = branchRepository.findByBranchNameJPQL(branchName);

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
            System.out.println("\nProperty Map ====\n" + map2);
            System.out.println("\n Branches" + data);
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    public Map<String, Object> getBranchByName(String branchName) {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();
        List<Branch> branches = branchRepository.findByBranchName(branchName);

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
            System.out.println("\nProperty Map ====\n" + map2);
            System.out.println("\n Branches" + data);
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    public Map<String, Object> getBranchByAddress(String branchAddress) {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();
        List<Branch> branches = branchRepository.findByBranchAddress(branchAddress);

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
            System.out.println("\nProperty Map ====\n" + map2);
            System.out.println("\n Branches" + data);
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    public Map<String, Object> getBranchByAddressJPQL(String branchAddress) {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();
        List<Branch> branches = branchRepository.findByBranchAddressJPQL(branchAddress);

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
            System.out.println("\nProperty Map ====\n" + map2);
            System.out.println("\n Branches" + data);
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    public Map<String, Object> getBranchByAddressNative(String branchAddress) {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();
        List<Branch> branches = branchRepository.findByBranchAddressNative(branchAddress);

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
          /*  System.out.println("\nProperty Map ====\n" + map2);
            System.out.println("\n Branches" + data);*/
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    public Map<String, Object> getBranchByCountry(String branchCountry) {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();
        List<Branch> branches = branchRepository.findByBranchCountry(branchCountry);

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
          /*  System.out.println("\nProperty Map ====\n" + map2);
            System.out.println("\n Branches" + data);*/
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    public Map<String, Object> getBranchByCountryJPQL(String branchCountry) {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();
        List<Branch> branches = branchRepository.findByBranchAddressJPQL(branchCountry);

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
          /*  System.out.println("\nProperty Map ====\n" + map2);
            System.out.println("\n Branches" + data);*/
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    public Map<String, Object> getBranchByCountryNative(String branchCountry) {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();
        List<Branch> branches = branchRepository.findByBranchCountryNative(branchCountry);

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    public Map<String, Object> getBranchByCode(String branchCode) {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();
        List<Branch> branches = branchRepository.findByBranchCode(branchCode);

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    public Map<String, Object> getBranchByCodeJPQL(String branchCode) {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();
        List<Branch> branches = branchRepository.findByBranchCodeJPQL(branchCode);

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    public Map<String, Object> getBranchByCodeNative(String branchCode) {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();
        List<Branch> branches = branchRepository.findByBranchCodeNative(branchCode);

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }


    //Request Param Get By Id only Active
    public Map<String, Object> getActiveBranchById(int brId) {
        Branch branch;
        Optional<Branch> existingBranchOptional = branchRepository.findActiveBranchById(brId);
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            if (existingBranchOptional.isPresent()) {
                branch = existingBranchOptional.get();
                propertyMap.put("BranchId", branch.getBranchId());
                propertyMap.put("branchCode", branch.getBranchCode());
                propertyMap.put("Branch Address", branch.getBranchAddress());
                propertyMap.put("Branch Location", branch.getBranchLocation().toText());
                propertyMap.put("BranchCountry", branch.getBranchCountry());
                propertyMap.put("BranchName", branch.getBranchName());
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Branch" + brId + " is not longer available.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Branch Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    // Jpql Query
    public Map<String, Object> getDeletedBranches() {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();
        List<Branch> branches = branchRepository.findDeletedBranches();

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
            System.out.println("\nProperty Map ====\n" + map2);
            System.out.println("\n Branches" + data);
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    // Jpql Query with Pagination
    public Map<String, Object> getDeletedBranchesPagination(Pageable pageable) {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        Page<Branch> branches = branchRepository.findDeletedBranchesPagination(pageable);

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
            System.out.println("\nProperty Map ====\n" + map2);
            System.out.println("\n Branches" + data);
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    // Native Query
    public Map<String, Object> getActiveBranchesPagination(int page, int size, String sort) {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        Pageable pageable = PageRequest.of(page, size, Sort.by(sort));
        Page<Branch> branches = branchRepository.findActiveBranchesPagination(pageable);

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
            System.out.println("\nProperty Map ====\n" + map2);
            System.out.println("\n Branches" + data);
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    // Native Query
    public Map<String, Object> getActiveBranches() {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();
        List<Branch> branches = branchRepository.findActiveBranches();

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
            System.out.println("\nProperty Map ====\n" + map2);
            System.out.println("\n Branches" + data);
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    public Map<String, Object> getAllBranches() {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();
        List<Branch> branches = branchRepository.findAll();

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
            System.out.println("\nProperty Map ====\n" + map2);
            System.out.println("\n Branches" + data);
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    public Map<String, Object> getAllBranchesPagination(Pageable pageable) {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        Page<Branch> branches = branchRepository.findAll(pageable);

        if (branches.isEmpty()) {
            map.put("status", "error");
            map.put("error", "data_no_longer_available");
            map.put("message", "There is no data");
            return map;
        }

        for (Branch branch : branches) {
            map2 = new HashMap<>();
            map2.put("BranchId", branch.getBranchId());
            map2.put("branchCode", branch.getBranchCode());
            map2.put("Branch Address", branch.getBranchAddress());
            map2.put("Branch Location", branch.getBranchLocation().toText());
            map2.put("BranchCountry", branch.getBranchCountry());
            map2.put("BranchName", branch.getBranchName());

            data.add(map2);
            System.out.println("\nProperty Map ====\n" + map2);
            System.out.println("\n Branches" + data);
        }

        map.put("Branches", data);
        map.put("status", "success");
        return map;
    }

    // Soft Delete By Id.
    public Map<String, Object> delBranchById(int branchId) {
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            Optional<Branch> existingBranchOptional = branchRepository.findActiveBranchById(branchId);
            if (existingBranchOptional.isPresent()) {
                Branch branch = existingBranchOptional.get();
                branch.setDelete(true);
                branch.setActive(false);
                branch.setDeletionTime(new Timestamp(System.currentTimeMillis()));
                branchRepository.save(branch);
                propertyMap.put("status", "success");
                propertyMap.put("message", "Branch soft deletion Confirmed!!");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Branch" + branchId + " is not Existed.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Branch Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    // HARD Delete
    public Map<String, Object> delBranchHardById(int branchId) {
        Map<String, Object> map = new HashMap<>();

        Optional<Branch> existingBranchOptional = branchRepository.findById(branchId);

        try {
            if (existingBranchOptional.isPresent()) {

                branchRepository.deleteById(branchId);
                map.put("status", "success");
                map.put("message", "Branch id " + branchId + " deletion Confirmed!!");
                return map;
            } else {
                map.put("status", "error");
                map.put("error", "no_longer_available");
                map.put("message", "Sorry, this Branch " + branchId + " does not Existed.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Invalid Branch Id");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }

    // Revert the record that are only soft deleted
    public Map<String, Object> revertBranchById(int branchId) {
        Map<String, Object> map = new HashMap<>();

        try {
            Optional<Branch> existingBranchOptional = branchRepository.findById(branchId);
            if (existingBranchOptional.isPresent()) {
                Branch branch = existingBranchOptional.get();

                if (!branch.isActive() && branch.isDelete()) {
                    branch.setDelete(false);
                    branch.setActive(true);
                    branch.setDeletionTime(null);
                    branchRepository.save(branch);
                    map.put("status", "success");
                    map.put("message", "Branch " + branchId + " Revert Confirmed!!");
                    return map;
                } else {
                    map.put("status", "error");
                    map.put("error", "Branch can't be Reverted.");
                    return map;
                }
            } else {
                map.put("status", "error");
                map.put("error", "Branch " + branchId + " field is invalid input.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Please Check Again.");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }


}
