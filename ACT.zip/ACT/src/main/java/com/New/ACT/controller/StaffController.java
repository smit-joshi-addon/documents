package com.New.ACT.controller;

import com.New.ACT.service.StaffService;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("staff")
public class StaffController {
    @Autowired
    StaffService staffService;

    @PostMapping("add")
    public Map<String, Object> addStaff(@RequestBody String staffData, HttpServletRequest request) throws JSONException {
        return staffService.addStaff(staffData, request);
    }

    // Update Only when Active
    @PutMapping("/updateActiveById")
    public Map<String, Object> updateActiveStaff(@RequestBody String staffData) throws JSONException {
        return staffService.updateActiveStaff(staffData);
    }

    //Get By Id Active
    @GetMapping("/getById")
    public Map<String, Object> findActiveStaffById(@RequestParam int staffId) {
        return staffService.findActiveStaffById(staffId);
    }

    // Return Active Records through JPQL
    @GetMapping("/findStaffByIdJPQL")
    public Map<String, Object> findStaffByIdJPQL(@RequestParam int staffId) {
        return staffService.findStaffByIdJPQL(staffId);
    }

    //Auto method for the retrieval of the id
    @GetMapping("/findStaffById")
    public Map<String, Object> findStaffById(@RequestParam int staffId) {
        return staffService.findStaffById(staffId);
    }

    @GetMapping("/findStaffByCode")
    public Map<String, Object> findStaffByCode(@RequestParam String staffCode) {
        return staffService.findStaffByCode(staffCode);
    }

    @GetMapping("/findStaffByCodeJPQL")
    public Map<String, Object> findStaffByCodeJPQL(@RequestParam String staffCode) {
        return staffService.findStaffByCodeJPQL(staffCode);
    }

    @GetMapping("/findStaffByCodeNative")
    public Map<String, Object> findStaffByCodeNative(@RequestParam String staffCode) {
        return staffService.findStaffByCodeNative(staffCode);
    }

    @GetMapping("/findStaffByFullName")
    public Map<String, Object> findStaffByFullName(@RequestParam String fullName) {
        return staffService.findStaffByFullName(fullName);
    }

    @GetMapping("/findStaffByFullNameJPQL")
    public Map<String, Object> findStaffByFullNameJPQL(@RequestParam String fullName) {
        return staffService.findStaffByFullNameJPQL(fullName);
    }

    @GetMapping("/findStaffByFullNameNative")
    public Map<String, Object> findStaffByFullNameNative(@RequestParam String fullName) {
        return staffService.findStaffByFullNameNative(fullName);
    }

    @GetMapping("/getStaffBySex")
    public Map<String, Object> getStaffBySex(@RequestParam String staffSex) {
        return staffService.getStaffBySex(staffSex);
    }

    @GetMapping("/getStaffBySexJPQL")
    public Map<String, Object> getStaffBySexJPQL(@RequestParam String staffSex) {
        return staffService.getStaffBySexJPQL(staffSex);
    }

    @GetMapping("/getStaffBySexNative")
    public Map<String, Object> getStaffBySexNative(@RequestParam String staffSex) {
        return staffService.getStaffBySexNative(staffSex);
    }

    @GetMapping("/findStaffByAddress")
    public Map<String, Object> findStaffByAddress(@RequestParam String staffAddress) {
        return staffService.findStaffByAddress(staffAddress);
    }

    @GetMapping("/findStaffByAddressJPQL")
    public Map<String, Object> findStaffByAddressJPQL(@RequestParam String staffAddress) {
        return staffService.findStaffByAddressJPQL(staffAddress);
    }

    @GetMapping("/findStaffByAddressNative")
    public Map<String, Object> findStaffByAddressNative(@RequestParam String staffAddress) {
        return staffService.findStaffByAddressNative(staffAddress);
    }

    @GetMapping("/findStaffByEmail")
    public Map<String, Object> findStaffByEmail(@RequestParam String email) {
        return staffService.findStaffByEmail(email);
    }

    @GetMapping("/findStaffByEmailJPQL")
    public Map<String, Object> findStaffByEmailJPQL(@RequestParam String email) {
        return staffService.findStaffByEmailJPQL(email);
    }

    @GetMapping("/findStaffByEmailNative")
    public Map<String, Object> findStaffByEmailNative(@RequestParam String email) {
        return staffService.findStaffByEmailNative(email);
    }

    @GetMapping("/findStaffByMobNum")
    public Map<String, Object> findStaffByMobNum(@RequestParam String mobNum) {
        return staffService.findStaffByMobNum(mobNum);
    }

    @GetMapping("/findStaffByMobNumJPQL")
    public Map<String, Object> findStaffByMobNumJPQL(@RequestParam String mobNum) {
        return staffService.findStaffByMobNumJPQL(mobNum);
    }

    @GetMapping("/findStaffByMobNumNative")
    public Map<String, Object> findStaffByMobNumNative(@RequestParam String mobNum) {
        return staffService.findStaffByMobNumNative(mobNum);
    }

    @GetMapping("/findStaffByAirlineNameJPQL")
    public Map<String, Object> findStaffByAirlineNameJPQL(@RequestParam String airlineName) {
        return staffService.findStaffByAirlineNameJPQL(airlineName);
    }

    @GetMapping("/findStaffByAirlineNameNative")
    public Map<String, Object> findStaffByAirlineNameNative(@RequestParam String airlineName) {
        return staffService.findStaffByAirlineNameNative(airlineName);
    }

    @GetMapping("/findStaffByAirlineName")
    public Map<String, Object> findStaffByAirlineName(@RequestParam String airlineName) {
        return staffService.findStaffByAirlineName(airlineName);
    }


    // Get all Staff with Deleted
    @GetMapping("/allStaff")
    public Map<String, Object> getAllStaff() {
        return staffService.getAllStaff();
    }

    // Get all Airlines without Deleted
    @GetMapping("/allActiveStaff")
    public Map<String, Object> getAllActiveStaff() {
        return staffService.getAllActiveStaff();
    }

    // Get all Airlines without Deleted
    @GetMapping("/allDeleteStaff")
    public Map<String, Object> getAllDeletedStaff() {
        return staffService.getAllDeletedStaff();
    }

    //Pagination Get all Vehicles with Deleted
    // If With Path Variable  @GetMapping("/allStaffPagination" or "/allAirlinesPagination/{page}...)
    @GetMapping("/allActiveStaffPagination")
    public Map<String, Object> getAllActiveStaffPagination(@RequestParam(defaultValue = "0") int page,
                                                           @RequestParam(defaultValue = "5") int size,
                                                           @RequestParam(defaultValue = "staffId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).descending());
        return staffService.getAllActiveStaffPagination(pageable);
    }

    @GetMapping("/allDeleteStaffPagination")
    public Map<String, Object> getAllDeleteStaffPagination(@RequestParam(defaultValue = "0") int page,
                                                           @RequestParam(defaultValue = "5") int size,
                                                           @RequestParam(defaultValue = "staffId") String sortBy) {
        return staffService.getAllDeletedStaffPagination(page, size, sortBy);
    }

    @GetMapping("/allStaffPagination")
    public Map<String, Object> getAllVehiclePagination(@RequestParam(defaultValue = "0") int page,
                                                       @RequestParam(defaultValue = "5") int size,
                                                       @RequestParam(defaultValue = "staffId") String sort) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sort).descending());
        return staffService.getAllStaffPagination(pageable);
    }


    //Soft Delete Through Method
    @DeleteMapping("/deleteById")
    public Map<String, Object> deleteStaffById(@RequestParam int staffId) {
        return staffService.deleteStaffById(staffId);
    }

    //Hard Delete Through Method
    @DeleteMapping("/deleteHard")
    public Map<String, Object> deleteStaffByIdHard(@RequestParam int staffId) {
        return staffService.delStaffHard(staffId);
    }

    //Revert Through Method
    @PutMapping("/revertById")
    public Map<String, Object> revertStaff(@RequestParam int staffId) {
        return staffService.revertStaff(staffId);
    }


}
