package com.New.ACT.controller;


import com.New.ACT.model.Branch;
import com.New.ACT.model.Vehicle;
import com.New.ACT.service.DriverService;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("drivers")
public class DriverController {

    @Autowired
    DriverService driverService;

    @PostMapping("add")
    public Map<String, Object> addDriver(@RequestParam String driverData,
                                         @RequestParam("licImg") MultipartFile licImg,
                                         @RequestParam MultipartFile idProof,
                                         HttpServletRequest request) throws JSONException {
        return driverService.addDriver(driverData, licImg, idProof, request);
    }

    //Not Working...
    @PostMapping("addRequestBody")
    public Map<String, Object> addDriverRequestBody(@RequestBody String driverData,
                                                    @RequestParam("licImg") MultipartFile licImg,
                                                    @RequestParam MultipartFile idProof,
                                                    HttpServletRequest request) throws JSONException {
        return driverService.addDriver(driverData, licImg, idProof, request);
    }

    // Get all Drivers with Deleted
    @GetMapping("/allDrivers")
    public Map<String, Object> getAllDrivers() {
        return driverService.getAllDrivers();
    }

    @GetMapping("/allDriversPagination")
    public Map<String, Object> getAllDriversPagination(@RequestParam(defaultValue = "0") int page,
                                                       @RequestParam(defaultValue = "10") int size,
                                                       @RequestParam(defaultValue = "driverId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).descending().and(Sort.by("driverId")));
        return driverService.getAllDriversPagination(pageable);
    }

    // Active Records
    @GetMapping("/allActiveDrivers")
    public Map<String, Object> getAllActiveDrivers() {
        return driverService.getAllActiveDrivers();
    }

    // Active Records
    @GetMapping("/allActiveDriversPagination")
    public Map<String, Object> getAllActiveDriversPagination(@RequestParam(defaultValue = "0") int page,
                                                             @RequestParam(defaultValue = "5") int size,
                                                             @RequestParam(defaultValue = "driver_id") String sortBy) {
        return driverService.getAllActiveDriversPagination(page, size, sortBy);
    }

    @GetMapping("getByIdAll")
    public Map<String, Object> getDriverById(@RequestParam(name = "driverId") int driverId) {
        return driverService.getDriverById(driverId);
    }

    // Get Only Active Records
    @GetMapping("getById")
    public Map<String, Object> getActiveDriverById(@RequestParam(name = "driverId") int driverId) {
        return driverService.getActiveDriverById(driverId);
    }

    @GetMapping("getDriverByIdNative")
    public Map<String, Object> getDriverByIdNative(@RequestParam(name = "driverId") int driverId) {
        return driverService.getDriverByIdNative(driverId);
    }

    @GetMapping("getDriverByIdJPQL")
    public Map<String, Object> getDriverByIdJPQL(@RequestParam(name = "driverId") int driverId) {
        return driverService.getDriverByIdJPQL(driverId);
    }

    @GetMapping("getDriverByLicenceNum")
    public Map<String, Object> getDriverByLicenceNum(@RequestParam(name = "licNum") String licNum) {
        return driverService.getDriverByLicenceNum(licNum);
    }

    @GetMapping("getDriverByLicenceNumNative")
    public Map<String, Object> getDriverByLicenceNumNative(@RequestParam(name = "licNum") String licNum) {
        return driverService.getDriverByLicenceNumNative(licNum);
    }

    @GetMapping("getDriverByLicenceNumJPQL")
    public Map<String, Object> getDriverByLicenceNumJPQL(@RequestParam(name = "licNum") String licNum) {
        return driverService.getDriverByLicenceNumJPQL(licNum);

    }

    @GetMapping("getDriverBySex")
    public Map<String, Object> getDriverBySex(@RequestParam(name = "driverId") String driverSex) {
        return driverService.getDriverBySex(driverSex);
    }

    @GetMapping("getDriverBySexJPQL")
    public Map<String, Object> getDriverBySexJPQL(@RequestParam(name = "driverId") String driverSex) {
        return driverService.getDriverBySexJPQL(driverSex);
    }

    @GetMapping("getDriverBySexNative")
    public Map<String, Object> getDriverBySexNative(@RequestParam(name = "driverId") String driverSex) {
        return driverService.getDriverBySexNative(driverSex);
    }

    @GetMapping("getDriverByName")
    public Map<String, Object> getDriverByName(@RequestParam(name = "driverName") String driverName) {
        return driverService.getDriverByName(driverName);
    }

    @GetMapping("getDriverByNameJPQL")
    public Map<String, Object> getDriverByNameJPQL(@RequestParam(name = "driverName") String driverName) {
        return driverService.getDriverByNameJPQL(driverName);
    }

    @GetMapping("getDriverByNameNative")
    public Map<String, Object> getDriverByNameNative(@RequestParam(name = "driverName") String driverName) {
        return driverService.getDriverByNameNative(driverName);
    }

    @GetMapping("getDriverByMobNum")
    public Map<String, Object> getDriverByMobNum(@RequestParam(name = "mobNum") String mobNum) {
        return driverService.getDriverByMobNum(mobNum);
    }

    @GetMapping("getDriverByMobNumJPQL")
    public Map<String, Object> getDriverByMobNumJPQL(@RequestParam(name = "mobNum") String mobNum) {
        return driverService.getDriverByMobNumJPQL(mobNum);
    }

    @GetMapping("getDriverByMobNumNative")
    public Map<String, Object> getDriverByMobNumNative(@RequestParam(name = "mobNum") String mobNum) {
        return driverService.getDriverByMobNumNative(mobNum);
    }

    @GetMapping("getDriverByEmail")
    public Map<String, Object> getDriverByEmail(@RequestParam(name = "email") String email) {
        return driverService.getDriverByEmail(email);
    }

    @GetMapping("getDriverByEmailJPQL")
    public Map<String, Object> getDriverByEmailJPQL(@RequestParam(name = "email") String email) {
        return driverService.getDriverByEmailJPQL(email);
    }

    @GetMapping("getDriverByEmailNative")
    public Map<String, Object> getDriverByEmailNative(@RequestParam(name = "email") String email) {
        return driverService.getDriverByEmailNative(email);
    }


    @GetMapping("getDriverByBranch")
    public Map<String, Object> getDriverByBranch(@RequestBody Branch branch) {
        return driverService.getDriverByBranch(branch);
    }

    @GetMapping("getDriverByBranchJPQL")
    public Map<String, Object> getDriverByBranchJPQL(@RequestBody Branch branch) {
        return driverService.getDriverByBranchJPQL(branch);
    }

    @GetMapping("getDriverByBranchNative")
    public Map<String, Object> getDriverByBranchNative(@RequestParam(name = "branchId") int branchId) {
        return driverService.getDriverByBranchNative(branchId);
    }


    @GetMapping("getDriverByVehicle")
    public Map<String, Object> getDriverByVehicle(@RequestBody Vehicle vehicle) {
        return driverService.getDriverByVehicle(vehicle);
    }

    @GetMapping("getDriverByVehicleJPQL")
    public Map<String, Object> getDriverByVehicleJPQL(@RequestBody Vehicle vehicle) {
        return driverService.getDriverByVehicleJPQL(vehicle);
    }

    @GetMapping("getDriverByVehicleNative")
    public Map<String, Object> getDriverByVehicleNative(@RequestParam int vehicleId) {
        return driverService.getDriverByVehicleNative(vehicleId);
    }


    // Delete Records
    @GetMapping("/allDeleteDrivers")
    public Map<String, Object> getAllDeleteDrivers() {
        return driverService.getAllDeleteDrivers();
    }

    // Delete Records
    @GetMapping("/allDeleteDriversPagination")
    public Map<String, Object> getAllDeleteDriversPagination(@RequestParam(defaultValue = "0") int page,
                                                             @RequestParam(defaultValue = "10") int size,
                                                             @RequestParam(defaultValue = "driverId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).ascending().and(Sort.by("driverSex")));
        return driverService.getAllDeleteDriversPagination(pageable);
    }

    // Form-data (Body) -> Multipath , Request Body -> raw(body)
    @PutMapping("update")
    public Map<String, Object> updateActiveDriver(@RequestParam(required = false) MultipartFile licImg,
                                                  @RequestParam(required = false) MultipartFile idProof,
                                                  @RequestBody String driverData) throws JSONException {
        // Check if idProof is present, and set it to null if not provided
        MultipartFile idProofFile = idProof != null && !idProof.isEmpty() ? idProof : null;
        MultipartFile licImgFile = licImg != null && !licImg.isEmpty() ? licImg : null;
        return driverService.updateActiveDriver(driverData, licImgFile, idProofFile);
    }

    @DeleteMapping("/delById")
    public Map<String, Object> delDriverById(@RequestParam int driverId) {
        return driverService.delActiveDriverById(driverId);
    }

    @DeleteMapping("/hardDelById")
    public Map<String, Object> hardDelDriverById(@RequestParam int driverId) {
        return driverService.delDriverById(driverId);
    }

    @PutMapping("/revertById")
    public Map<String, Object> revertAirline(@RequestParam int driverId) {
        return driverService.revertDriverById(driverId);
    }

    @GetMapping("geofence")
    public List<Object[]> findNearestStaffByDriver(@RequestParam double radius) {
        return driverService.findNearestStaffByDriver(radius);
    }

    //@PostMapping("addByObj")
    /*public Map<String, Object> addDriverByObj(@RequestBody Driver driverData,
                                         @RequestParam("licImg") MultipartFile licImg,
                                         @RequestParam MultipartFile idProof,
                                         HttpServletRequest request) throws JSONException {
        return driverService.addDriverByObj(driverData, licImg, idProof, request);
    }*/
    /*public Map<String, Object> addDriverByObj( @RequestParam int num,@RequestBody Driver driverData,

                                              HttpServletRequest request) throws JSONException {
        Map<String,Object> m1= new HashMap<>();
        System.out.println("Number\n"+num);
        System.out.println("DriverData \n"+driverData);
        return m1;
    }*/
}