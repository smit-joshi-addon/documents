package com.New.ACT.controller;

import com.New.ACT.service.DutyService;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.io.FileNotFoundException;
import java.util.Map;

@RestController
@RequestMapping("Duty")
public class DutyController {
    @Autowired
    DutyService dutyService;

    @PostMapping("add")
    public Map<String, Object> addDuty(@RequestBody String dutyData, HttpServletRequest request) throws JSONException {
        return dutyService.addDuty(dutyData, request);
    }

    // Update Only when Active
    @PutMapping("/updateActiveById")
    public Map<String, Object> updateActiveDuty(@RequestBody String dutyData) throws JSONException {
        return dutyService.updateActiveDuty(dutyData);
    }

    //Get By Id Active
    @GetMapping("/getById")
    public Map<String, Object> getActiveDutyById(@RequestParam int dutyId) {
        return dutyService.getActiveDutyById(dutyId);
    }

    @GetMapping("/getByDutyName")
    public Map<String, Object> getDutyByName(@RequestParam String dutyName) {
        return dutyService.getDutyByName(dutyName);
    }

    @GetMapping("/getDutyByNameJPQL")
    public Map<String, Object> getDutyByNameJPQL(@RequestParam String dutyName) {
        return dutyService.getDutyByNameJPQL(dutyName);
    }

    @GetMapping("/getDutyByNameNative")
    public Map<String, Object> getDutyByNameNative(@RequestParam String dutyName) {
        return dutyService.getDutyByNameNative(dutyName);
    }


    @GetMapping("/getDutyByTotalStaffHighNative")
    public Map<String, Object> getDutyByTotalStaffHighNative(@RequestParam int totalStaff) {
        return dutyService.getDutyByTotalStaffHighNative(totalStaff);
    }

    @GetMapping("/getDutyByTotalStaffBetween")
    public Map<String, Object> getDutyByTotalStaffBetween(@RequestParam int start, @RequestParam int stop) {
        return dutyService.getDutyByTotalStaffBetween(start, stop);
    }

    @GetMapping("/getDutyByTotalStaffLessJPQL")
    public Map<String, Object> getDutyByTotalStaffLessJPQL(@RequestParam int totalStaff) {
        return dutyService.getDutyByTotalStaffLessJPQL(totalStaff);
    }

    @GetMapping("/getDutyByRelatedStaffBetween")
    public Map<String, Object> getDutyByRelatedStaffBetween(@RequestParam int start, @RequestParam int stop) {
        return dutyService.getDutyByRelatedStaffBetween(start, stop);
    }

    @GetMapping("/getDutyByRelatedStaffLessJPQL")
    public Map<String, Object> getDutyByRelatedStaffLessJPQL(@RequestParam int totalStaff) {
        return dutyService.getDutyByRelatedStaffLessJPQL(totalStaff);
    }

    @GetMapping("/getDutyByRelatedStaffHighNative")
    public Map<String, Object> getDutyByRelatedStaffHighNative(@RequestParam int totalStaff) {
        return dutyService.getDutyByRelatedStaffHighNative(totalStaff);
    }

    @GetMapping("/getDutyByFileLocation")
    public Map<String, Object> getDutyByFileLocation(@RequestParam String fileLocation) {
        return dutyService.getDutyByFileLocation(fileLocation);
    }

    @GetMapping("/getDutyByFileLocationJPQL")
    public Map<String, Object> getDutyByFileLocationJPQL(@RequestParam String fileLocation) {
        return dutyService.getDutyByFileLocationJPQL(fileLocation);
    }

    @GetMapping("/getDutyByFileLocationNative")
    public Map<String, Object> getDutyByFileLocationNative(@RequestParam String fileLocation) {
        return dutyService.getDutyByFileLocationNative(fileLocation);
    }

    @GetMapping("/getDutyByFileName")
    public Map<String, Object> getDutyByFileName(@RequestParam String fileName) {
        return dutyService.getDutyByFileName(fileName);
    }

    @GetMapping("/getDutyByFileNameNative")
    public Map<String, Object> getDutyByFileNameNative(@RequestParam String fileName) {
        return dutyService.getDutyByFileNameNative(fileName);
    }

    @GetMapping("/getDutyByFileNameJPQL")
    public Map<String, Object> getDutyByFileNameJPQL(@RequestParam String fileName) {
        return dutyService.getDutyByFileNameJPQL(fileName);
    }

    @GetMapping("/getDutyByStatus")
    public Map<String, Object> getDutyByStatus(@RequestParam boolean status) {
        return dutyService.getDutyByStatus(status);
    }

    @GetMapping("/getDutyByStatusJPQL")
    public Map<String, Object> getDutyByStatusJPQL(@RequestParam boolean status) {
        return dutyService.getDutyByStatusJPQL(status);
    }

    @GetMapping("/getDutyByStatusNative")
    public Map<String, Object> getDutyByStatusNative(@RequestParam boolean status) {
        return dutyService.getDutyByStatusNative(status);
    }


    // Get all Staff with Deleted
    @GetMapping("/allDuty")
    public Map<String, Object> getAllDuty() {
        return dutyService.getAllDuty();
    }

    // Get all Airlines without Deleted
    @GetMapping("/allActiveDuty")
    public Map<String, Object> getAllActiveDuty() {
        return dutyService.getAllActiveDuty();
    }

    // Get all Airlines without Deleted
    @GetMapping("/allDeleteDuty")
    public Map<String, Object> getAllDeletedDuty() {
        return dutyService.getAllDeletedDuty();
    }

    //Pagination Get all Vehicles with Deleted
    // If With Path Variable  @GetMapping("/allDutyPagination" or "/allDutyPagination/{page}...)
    @GetMapping("/allActiveDutyPagination")
    public Map<String, Object> getAllActiveDutyPagination(@RequestParam(defaultValue = "0") int page,
                                                          @RequestParam(defaultValue = "5") int size,
                                                          @RequestParam(defaultValue = "dutyId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).descending());
        return dutyService.getAllActiveDutyPagination(pageable);
    }

    @GetMapping("/allDeleteDutyPagination")
    public Map<String, Object> getAllDeletedDutyPagination(@RequestParam(defaultValue = "0") int page,
                                                           @RequestParam(defaultValue = "5") int size,
                                                           @RequestParam(defaultValue = "dutyDate") String sortBy) {
        return dutyService.getAllDeletedDutyPagination(page, size, sortBy);
    }

    @GetMapping("/allDutyPagination")
    public Map<String, Object> getAllDutyPagination(@RequestParam(defaultValue = "0") int page,
                                                    @RequestParam(defaultValue = "5") int size,
                                                    @RequestParam(defaultValue = "dutyId") String sort) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sort).descending());
        return dutyService.getAllDutyPagination(pageable);
    }


    //Soft Delete Through Method
    @DeleteMapping("/deleteById")
    public Map<String, Object> deleteDutyById(@RequestParam int dutyId) {
        return dutyService.deleteDutyById(dutyId);
    }

    //Hard Delete Through Method
    @DeleteMapping("/deleteHard")
    public Map<String, Object> delDutyHard(@RequestParam int dutyId) {
        return dutyService.delDutyHard(dutyId);
    }

    //Revert Through Method
    @PutMapping("/revertById")
    public Map<String, Object> revertDuty(@RequestParam int dutyId) {
        return dutyService.revertDuty(dutyId);
    }

    //Get Duty of the Day
    @GetMapping("/dutyDate")
    public Map<String, Object> getDutyOfDay(@RequestParam String targetDate) {
        // Date targetDate = Date.valueOf("2024-03-11");
        return dutyService.getRecordsForDate(targetDate);

    }

    @PostMapping("/uploadFile")
    public String uploadFile(HttpServletRequest request) throws FileNotFoundException {
        return dutyService.uploadFile(request);
    }

  @PostMapping("/uploadFileTest")
    public String uploadFileTest(HttpServletRequest request) throws FileNotFoundException {
        return dutyService.uploadFileTest(request);
    }

}
