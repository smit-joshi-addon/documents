package com.New.ACT.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import lombok.*;
import org.locationtech.jts.geom.Geometry;

import java.sql.Timestamp;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="staff")
public class Staff {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name ="staff_id")
    private int staffId;
    @Column(name ="staff_code")
    private String staffCode;
    @Column(name = "staff_full_name")
    private String staffFullName;
    @Column(name = "staff_sex")
    private String staffSex;
    @Column(name = "staff_address",columnDefinition = "text")
    private String staffAddress;

    @Column(name = "mobile_num1")
    //@Pattern(regexp = "^[0-9]{10}$", message = "Please provide a valid 10-digit mobile number")
    private String mobileNum1;
    @Column(name = "mobile_num2")
    private String mobileNum2;

    @Column(name = "email")
    @Email(message = "Please provide a valid email address")
    private String email;

    //Common Fields
    @Column(name ="creation_time")
    private Timestamp creationTime;
    @Column(name ="deletion_time")
    private Timestamp deletionTime;
    @Column(name = "is_active")
    private boolean isActive;
    @Column(name = "is_delete")
    private boolean isDelete;
    @Column(name ="ip_address")
    private String ipAddress;

    @ManyToOne
    @JoinColumn(name = "airline_id")
    private Airline airline;

    @Column(columnDefinition = "geometry")
    private Geometry staffLocation;


    // going to use the service set method to set the value.
}
