package com.New.ACT.service;

import com.New.ACT.Repository.AirlineRepository;
import com.New.ACT.Repository.DriverRepository;
import com.New.ACT.Repository.StaffRepository;
import com.New.ACT.model.Airline;
import com.New.ACT.model.Driver;
import com.New.ACT.model.Staff;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.json.JSONException;
import org.json.JSONObject;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class StaffService {
    @Autowired
    StaffRepository staffRepository;

    @Autowired
    DriverRepository driverRepository;

    @Autowired
    AirlineRepository airlineRepository;


    public Map<String, Object> addStaff(String staffData, HttpServletRequest request) throws JSONException {
        JSONObject jsonData = new JSONObject(staffData);
        Map<String, Object> m1 = new HashMap<String, Object>();
        Map<String, Object> map = new HashMap<String, Object>();

        Airline airline = null;
        int airlineId = 0;
        String staffCode = null;
        String staffFullName = null;
        String staffSex = null;
        String staffAddress = null;

        String mobileNum1 = null;
        String mobileNum2 = null;
        String email1 = null;
        Geometry staffLocation = null;

        try {
            if (jsonData.has("airlineId") && jsonData.get("airlineId") != null
                    && !jsonData.get("airlineId").equals("")) {

                airlineId = jsonData.getInt("airlineId");
                Optional<Airline> existingAirlineOptional = airlineRepository.findByIsActiveTrueAndAirlineId(airlineId);
                airline = existingAirlineOptional.orElse(null);
                if (airline == null) {
                    m1.put("status", "error");
                    m1.put("error", "no_longer_available");
                    m1.put("message", "Sorry, this airline is not longer available.");
                    return m1;
                }
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field_validation");
                m1.put("message", "Please provide airline identification like airlineId.");
                return m1;
            }

            //staffCode Validation
            if (jsonData.has("staffCode") && !jsonData.get("staffCode").equals("")
                    && jsonData.get("staffCode") != null) {
                staffCode = jsonData.getString("staffCode");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide staffCode.");
                return m1;
            }

            // staffFullName  Validation
            if (jsonData.has("staffFullName") && !jsonData.get("staffFullName").equals("")
                    && jsonData.get("staffFullName") != null) {
                staffFullName = jsonData.getString("staffFullName");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide staffFullName.");
                return m1;
            }

            // staffSex  Validation
            if (jsonData.has("staffSex") && !jsonData.get("staffSex").equals("")
                    && jsonData.get("staffSex") != null) {
                staffSex = jsonData.getString("staffSex");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide staffSex.");
                return m1;
            }
            // staffAddress  Validation
            if (jsonData.has("staffAddress") && !jsonData.get("staffAddress").equals("")
                    && jsonData.get("staffAddress") != null) {
                staffAddress = jsonData.getString("staffAddress");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide staffAddress.");
                return m1;
            }

            // Staff Location Validation
            if (jsonData.has("staffLocation") && !jsonData.get("staffLocation").equals("")
                    && jsonData.get("staffLocation") != null) {
                // Use JTS to convert the WKT string to a Geometry object
                WKTReader wktReader = new WKTReader();
                staffLocation = wktReader.read(jsonData.getString("staffLocation"));
                staffLocation.setSRID(4326);
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide Staff Location.");
                return m1;
            }

            //mobileNum1   Validation
            if (jsonData.has("mobileNum1") && !jsonData.get("mobileNum1").equals("")
                    && jsonData.get("mobileNum1") != null) {
                mobileNum1 = jsonData.getString("mobileNum1");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide mobileNum1.");
                return m1;
            }

            if (jsonData.has("email1") && !jsonData.get("email1").equals("")
                    && jsonData.get("email1") != null) {
                email1 = jsonData.getString("email1");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide email1.");
                return m1;
            }
            if (jsonData.has("mobileNum2") && !jsonData.get("mobileNum2").equals("")
                    && jsonData.get("mobileNum2") != null) {
                mobileNum2 = jsonData.getString("mobileNum2");
            }


            Staff staff = new Staff();
            staff.setAirline(airline);
            staff.setStaffCode(staffCode);
            staff.setStaffSex(staffSex);
            staff.setStaffAddress(staffAddress);
            staff.setStaffFullName(staffFullName);
            staff.setStaffLocation(staffLocation);

            staff.setMobileNum1(mobileNum1);
            staff.setMobileNum2(mobileNum2);
            staff.setEmail(email1);
            staff.setCreationTime(new Timestamp(System.currentTimeMillis()));
            staff.setActive(true);
            staff.setDelete(false);
            String ipAddress = request.getHeader("X-FORWARDED-FOR");
            if (ipAddress == null || ipAddress.isEmpty()) {
                staff.setIpAddress(request.getRemoteAddr());
            }
            staffRepository.save(staff);

            m1.put("status", "success");
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());
            m1.put("StaffId", staff.getStaffId());
            m1.put("StaffSex", staff.getStaffSex());
            m1.put("StaffAddress", staff.getStaffAddress());
            m1.put("StaffCode", staff.getStaffCode());
            m1.put("StaffFullName", staff.getStaffFullName());
            m1.put("MobileNum1", staff.getMobileNum1());
            m1.put("MobileNum2", staff.getMobileNum2());
            m1.put("Email1", staff.getEmail());
            m1.put("Airline", map);
            m1.put("message", "Staff information saved successfully!!");
            return m1;

        } catch (Exception e) {
            e.printStackTrace();
            m1.put("status", "error");
            m1.put("error", "not_found");
            m1.put("message", "Something went wrong");
            return m1;
        }
    }

    //Update
    public Map<String, Object> updateActiveStaff(String staffData) throws JSONException {
        JSONObject jsonData = new JSONObject(staffData);
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> propertyMap = new HashMap<>();

        Airline airline = new Airline();
        int airlineId = 0;
        Staff staff;
        int staffId = 0;
        try {
            if (jsonData.has("staffId") && jsonData.get("staffId") != null
                    && !jsonData.get("staffId").equals("")) {
                staffId = jsonData.getInt("staffId");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide staffId.");
                return map;
            }
            Optional<Staff> existingStaffOptional = staffRepository.findActiveStaffById(staffId);
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "The Staff Does Not Exist.");
                return map;
            }

            if (!staff.getAirline().isActive() && staff.getAirline().isDelete()) {
                map.put("status", "error");
                map.put("error", "no_longer_available_airportId");
                map.put("message", "Sorry, This Airline id is not Updatable.");
                return map;
            }
            if (jsonData.has("airlineId") && jsonData.get("airlineId") != null
                    && !jsonData.get("airlineId").equals("")) {
                airlineId = jsonData.getInt("airlineId");

                Optional<Airline> existingAirlineOptional = airlineRepository.findByIsActiveTrueAndAirlineId(airlineId);
                if (existingAirlineOptional.isPresent()) {
                    airline = existingAirlineOptional.get();
                    staff.setAirline(airline);
                } else {
                    map.put("status", "error");
                    map.put("error", "no_longer_available");
                    map.put("message", "Sorry, this Airline id is not in the database.");
                    return map;
                }
            }
            if (jsonData.has("staffCode") && jsonData.get("staffCode") != null
                    && !jsonData.get("staffCode").equals("")) {
                staff.setStaffCode(jsonData.getString("staffCode"));
            }
            // airline Address Update
            if (jsonData.has("staffFullName") && !jsonData.get("staffFullName").equals("")
                    && jsonData.get("staffFullName") != null) {
                staff.setStaffFullName(jsonData.getString("staffFullName"));
            }
            if (jsonData.has("staffSex") && !jsonData.get("staffSex").equals("")
                    && jsonData.get("staffSex") != null) {
                staff.setStaffSex(jsonData.getString("staffSex"));
            }
            if (jsonData.has("staffAddress") && !jsonData.get("staffAddress").equals("")
                    && jsonData.get("staffAddress") != null) {
                staff.setStaffAddress(jsonData.getString("staffAddress"));
            }
            if (jsonData.has("staffLocation")) {
                if (!jsonData.get("staffLocation").equals("") && !jsonData.get("staffLocation").equals(null) && jsonData.get("staffLocation") != null) {
                    WKTReader wktReader = new WKTReader();
                    Geometry staffLocation = wktReader.read(jsonData.getString("staffLocation"));
                    staffLocation.setSRID(4326);
                    staff.setStaffLocation(staffLocation);
                    System.out.println("srid" + staff.getStaffLocation().getSRID() + "type" + staff.getStaffLocation().getGeometryType());
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper StaffLocation.");
                    return map;
                }
            }
            //Staff mobile NUmber Update
            if (jsonData.has("mobileNum1") && !jsonData.get("mobileNum1").equals("")
                    && jsonData.get("mobileNum1") != null) {
                staff.setMobileNum1(jsonData.getString("mobileNum1"));
            }
            if (jsonData.has("mobileNum2") && !jsonData.get("mobileNum2").equals("")
                    && jsonData.get("mobileNum2") != null) {
                staff.setMobileNum2(jsonData.getString("mobileNum2"));
            }

            //Staff Email Update
            if (jsonData.has("email1") && !jsonData.get("email1").equals("")
                    && jsonData.get("email1") != null) {
                staff.setEmail(jsonData.getString("email1"));
            }

            Staff staffUpdate = staffRepository.save(staff);
            map.put("status", "success");
            map.put("message", "Staff id " + staffId + " Update Confirmed!!!");
            // To Return Staff
            propertyMap.put("Airline Id", staffUpdate.getAirline().getAirlineId());
            propertyMap.put("AirlineName", staffUpdate.getAirline().getAirlineName());
            propertyMap.put("AirlineAddress", staffUpdate.getAirline().getAirlineAddress());
            propertyMap.put("AirlineLocation", staffUpdate.getAirline().getAirlineLocation().toText());
            propertyMap.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            propertyMap.put("MobileNum1", staffUpdate.getAirline().getMobileNum1());
            propertyMap.put("MobileNum2", staffUpdate.getAirline().getMobileNum2());
            propertyMap.put("MobileNum3", staffUpdate.getAirline().getMobileNum3());
            propertyMap.put("Email1", staffUpdate.getAirline().getEmail1());
            propertyMap.put("Email2", staffUpdate.getAirline().getEmail2());
            map.put("getStaffId", staffUpdate.getStaffId());
            map.put("getStaffSex", staffUpdate.getStaffSex());
            map.put("Staff Address", staffUpdate.getStaffAddress());
            map.put("Staff Location", staffUpdate.getStaffLocation().toText());
            map.put("AirportCountry", staffUpdate.getStaffCode());
            map.put("AirportRegion", staffUpdate.getStaffFullName());
            map.put("MobileNum1", staffUpdate.getMobileNum1());
            map.put("MobileNum2", staffUpdate.getMobileNum2());
            map.put("Email1", staffUpdate.getEmail());
            map.put("Airline", propertyMap);

        } catch (JSONException | ParseException e) {
            e.printStackTrace();
            map.put("status", "error");
            map.put("error", "not_found");
            map.put("message", "Something went wrong");
            return map;
        }
        return map;
    }

    public Map<String, Object> findActiveStaffById(int staffId) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findActiveStaffById(staffId);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("Airline Location", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("StaffLocation", staff.getStaffLocation().toText());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + staffId + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid staff Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findStaffByIdJPQL(int staffId) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findActiveStaffByIdJPQL(staffId);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + staffId + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid staff Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findStaffById(int staffId) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findByStaffId(staffId);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + staffId + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid staff Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findStaffByCode(String staffCode) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findByStaffCode(staffCode);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + staffCode + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid staff Code");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findStaffByCodeJPQL(String staffCode) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findByStaffCodeJPQL(staffCode);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + staffCode + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid  staffCode");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findStaffByCodeNative(String staffCode) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findByStaffCodeNative(staffCode);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + staffCode + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid  staffCode");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findStaffByEmail(String email) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findByEmail(email);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + email + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid  email");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findStaffByEmailJPQL(String email) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findByEmailJPQL(email);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + email + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid  email");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findStaffByEmailNative(String email) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findByEmailNative(email);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + email + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid  email");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findStaffByMobNum(String mobNum) {
        String mobNum2 = mobNum;
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findByMobileNum1OrMobileNum2(mobNum, mobNum2);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + mobNum + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid  mobNum");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findStaffByMobNumJPQL(String mobNum) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findByStaffMobNumJPQL(mobNum);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + mobNum + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid  mobNum");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findStaffByMobNumNative(String mobNum) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findByStaffMobNumNative(mobNum);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + mobNum + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid  mobNum");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findStaffByAddress(String staffAddress) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findByStaffAddress(staffAddress);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + staffAddress + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid  staffAddress");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findStaffByAddressJPQL(String staffAddress) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findByStaffAddressJPQL(staffAddress);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + staffAddress + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid  staffAddress");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findStaffByAddressNative(String staffAddress) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findByStaffAddressNative(staffAddress);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + staffAddress + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid  staffAddress");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }


    public Map<String, Object> findStaffByFullName(String staffFullName) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findByStaffFullName(staffFullName);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + staffFullName + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid  staffFullName");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findStaffByFullNameJPQL(String staffFullName) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findByStaffFullNameJPQL(staffFullName);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + staffFullName + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid  staffFullName");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findStaffByFullNameNative(String staffFullName) {
        Staff staff;
        Optional<Staff> existingStaffOptional = staffRepository.findByStaffFullNameNative(staffFullName);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingStaffOptional.isPresent()) {
                staff = existingStaffOptional.get();
                map.put("Airline Id", staff.getAirline().getAirlineId());
                map.put("AirlineName", staff.getAirline().getAirlineName());
                map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
                map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
                map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
                map.put("MobileNum1", staff.getAirline().getMobileNum1());
                map.put("MobileNum2", staff.getAirline().getMobileNum2());
                map.put("MobileNum3", staff.getAirline().getMobileNum3());
                map.put("Email1", staff.getAirline().getEmail1());
                map.put("Email2", staff.getAirline().getEmail2());

                propertyMap.put("StaffId", staff.getStaffId());
                propertyMap.put("StaffSex", staff.getStaffSex());
                propertyMap.put("StaffAddress", staff.getStaffAddress());
                propertyMap.put("Staff Location", staff.getStaffLocation().toText());
                propertyMap.put("StaffCode", staff.getStaffCode());
                propertyMap.put("StaffFullName", staff.getStaffFullName());
                propertyMap.put("MobileNum1", staff.getMobileNum1());
                propertyMap.put("MobileNum2", staff.getMobileNum2());
                propertyMap.put("Email1", staff.getEmail());
                propertyMap.put("Airline", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Staff " + staffFullName + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid  staffFullName");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> getStaffBySex(String staffSex) {
        List<Staff> existingStaffOptional = staffRepository.findByStaffSex(staffSex);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("Staff Location", staff.getStaffLocation().toText());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    public Map<String, Object> getStaffBySexJPQL(String staffSex) {
        List<Staff> existingStaffOptional = staffRepository.findByStaffSexJPQL(staffSex);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("Staff Location", staff.getStaffLocation().toText());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    public Map<String, Object> getStaffBySexNative(String staffSex) {
        List<Staff> existingStaffOptional = staffRepository.findByStaffSexNative(staffSex);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("Staff Location", staff.getStaffLocation().toText());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    public Map<String, Object> findStaffByAirlineName(String airlineName) {
        List<Staff> existingStaffOptional = staffRepository.findByAirline_AirlineName(airlineName);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("Airline Location", staff.getAirline().getAirlineLocation().toText());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            //map.put("Airport Location", staff.getAirline().getAirport().getAirportLocation().toText());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("Staff Location", staff.getStaffLocation().toText());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email", staff.getEmail());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    public Map<String, Object> findStaffByAirlineNameJPQL(String airlineName) {
        List<Staff> existingStaffOptional = staffRepository.findStaffByAirlineNameJPQL(airlineName);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("Staff Location", staff.getStaffLocation().toText());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    public Map<String, Object> findStaffByAirlineNameNative(String airlineName) {
        List<Staff> existingStaffOptional = staffRepository.findStaffByAirlineNameNative(airlineName);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data for airline not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("Staff Location", staff.getStaffLocation().toText());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }


    // Get Active & Delete Records
    public Map<String, Object> getAllStaff() {
        List<Staff> existingStaffOptional = staffRepository.findAll();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("Staff Location", staff.getStaffLocation().toText());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    // Get Active & Delete Staff
    public Map<String, Object> getAllStaffPagination(Pageable pageable) {
        Page<Staff> existingStaffOptional = staffRepository.findAll(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("Staff Location", staff.getStaffLocation().toText());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    // Get Active Records
    public Map<String, Object> getAllActiveStaff() {
        List<Staff> existingStaffOptional = staffRepository.findAllActiveStaff();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("Staff Location", staff.getStaffLocation().toText());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    // Get Active Records
    public Map<String, Object> getAllActiveStaffPagination(Pageable pageable) {
        Page<Staff> existingStaffOptional = staffRepository.findActiveStaffPagination(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("Staff Location", staff.getStaffLocation().toText());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    // Get Deleted Records
    public Map<String, Object> getAllDeletedStaff() {
        List<Staff> existingStaffOptional = staffRepository.findAllDeletedStaff();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("Staff Location", staff.getStaffLocation().toText());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    // Get Deleted Staff Pagination
    public Map<String, Object> getAllDeletedStaffPagination(int page, int size, String sort) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sort));
        Page<Staff> existingStaffOptional = staffRepository.findAllDeletedStaffPagination(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingStaffOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "staff_no_longer_available");
            propertyMap.put("message", "Staff data not found");
            return propertyMap;
        }

        for (Staff staff : existingStaffOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            map.put("Airline Id", staff.getAirline().getAirlineId());
            map.put("AirlineName", staff.getAirline().getAirlineName());
            map.put("AirlineAddress", staff.getAirline().getAirlineAddress());
            map.put("AirlineLocation", staff.getAirline().getAirlineLocation().toText());
            map.put("Airport Id", staff.getAirline().getAirport().getAirportId());
            map.put("MobileNum1", staff.getAirline().getMobileNum1());
            map.put("MobileNum2", staff.getAirline().getMobileNum2());
            map.put("MobileNum3", staff.getAirline().getMobileNum3());
            map.put("Email1", staff.getAirline().getEmail1());
            map.put("Email2", staff.getAirline().getEmail2());

            propertyMap2.put("StaffId", staff.getStaffId());
            propertyMap2.put("StaffSex", staff.getStaffSex());
            propertyMap2.put("StaffAddress", staff.getStaffAddress());
            propertyMap2.put("Staff Location", staff.getStaffLocation().toText());
            propertyMap2.put("StaffCode", staff.getStaffCode());
            propertyMap2.put("StaffFullName", staff.getStaffFullName());
            propertyMap2.put("MobileNum1", staff.getMobileNum1());
            propertyMap2.put("MobileNum2", staff.getMobileNum2());
            propertyMap2.put("Email1", staff.getEmail());
            propertyMap2.put("Airline", map);
            data.add(propertyMap2);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Staff", data);
        return propertyMap;
    }

    //HARD DELETE
    public Map<String, Object> delStaffHard(int staffId) {
        Map<String, Object> map = new HashMap<>();

        Optional<Staff> existingStaffOptional = staffRepository.findById(staffId);

        try {
            if (existingStaffOptional.isPresent()) {
                staffRepository.deleteById(staffId);
                map.put("status", "success");
                map.put("message", "Staff id " + staffId + " deletion Confirmed!!");
                return map;
            } else {
                map.put("status", "error");
                map.put("error", "no_longer_available");
                map.put("message", "Sorry, this Staff " + staffId + " does not Existed.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Invalid Staff Id");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }

    // Delete By Id Soft Delete
    public Map<String, Object> deleteStaffById(int staffId) {
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            Optional<Staff> existingStaffOptional = staffRepository.findActiveStaffById(staffId);
            if (existingStaffOptional.isPresent()) {
                Staff staff = existingStaffOptional.get();
                staff.setDelete(true);
                staff.setActive(false);
                staff.setDeletionTime(new Timestamp(System.currentTimeMillis()));
                staffRepository.save(staff);
                propertyMap.put("status", "success");
                propertyMap.put("message", "Staff soft deletion Confirmed!!");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "Staff_no_longer_available");
                propertyMap.put("message", "Sorry, this Staff" + staffId + " is not Existed.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Staff Id ");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> revertStaff(int staffId) {
        Map<String, Object> map = new HashMap<>();

        try {
            Optional<Staff> existingStaffOptional = staffRepository.findById(staffId);
            if (existingStaffOptional.isPresent()) {
                Staff staff = existingStaffOptional.get();

                if (!staff.isActive() && staff.isDelete()) {
                    staff.setDelete(false);
                    staff.setActive(true);
                    staff.setDeletionTime(null);
                    staffRepository.save(staff);
                    map.put("status", "success");
                    map.put("message", "Staff " + staffId + " Revert Confirmed!!");
                    return map;
                } else {
                    map.put("status", "error");
                    map.put("error", "Staff can't be Reverted.");
                    return map;
                }
            } else {
                map.put("status", "error");
                map.put("error", "Staff " + staffId + " is not Present.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Please Check Again.");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }

    public Map<String, Object> allocateStaff(int airlineId) {

        List<Staff> availableStaffs = staffRepository.findByAirline_AirlineId(airlineId);
        List<Driver> availableDrivers = driverRepository.findActiveDrivers();
        Map<String, Object> map = null;
        return map;
    }

    public String readFromFile() {
        String filePath = "/home/krishnab/Downloads/Daily Roster Report Go 24 Mar 2022.xls"; // Replace with the path to your Excel file
        String fileName = filePath.substring(filePath.lastIndexOf('/') + 1);
        try (InputStream inputStream = new FileInputStream(filePath);
             Workbook workbook = new HSSFWorkbook(inputStream)) {

            Sheet sheet = workbook.getSheetAt(0); // Assuming the data is in the first sheet
            System.out.println("Inner Sheet");

            // Regex pattern to match 'G8' followed by 'AMD' at the end of flight sector
            // Pattern pattern = Pattern.compile("G8-.*AMD$");
            Map<String, String> flightSectorMap = new HashMap<>();
            Set<String> uniqueStaffCodes = new HashSet<>(); // Set to store unique staff codes
            int totalStaffCount = 0; // Initialize total staff counter

            // Initialize a list to store the staff codes
            List<String> staffCodeList = new ArrayList<>();

            // Iterate through rows
            for (Row row : sheet) {
                Cell flightSectorCell = row.getCell(4); // Column index 3 for 'Flight No(s) Sector(s)'
                System.out.println("Cell"+flightSectorCell);
                if (flightSectorCell != null) {
                    String flightSectorValue = flightSectorCell.getStringCellValue();
                    String staffIdNames = row.getCell(16).getStringCellValue();
                    System.out.println("Global ..."+staffIdNames);
                    if (flightSectorValue.contains("AMD")) {
                        int lastNumericIndex = -1;
                        for (int i = flightSectorValue.length() - 1; i >= 0; i--) {
                            if (Character.isDigit(flightSectorValue.charAt(i))) {
                                lastNumericIndex = i;
                                break;
                            }
                        }

                        if (lastNumericIndex != -1) {
                            String flightRoute = flightSectorValue.substring(lastNumericIndex + 1);
                            if (flightRoute.startsWith("AMD") || flightRoute.endsWith("AMD")) {
                                System.out.println("flightRoute: " + flightRoute);
                              //  staffIdNames = row.getCell(16).getStringCellValue(); // Fetch value from index 16 about staffcode and name
                                System.out.println("StaffNames..."+staffIdNames);
                                //Pattern for finding the staff Ids
                                Pattern pattern = Pattern.compile("(\\d+):");
                                // Create a matcher object
                                Matcher matcher = pattern.matcher(staffIdNames);

                                StringBuilder extractedValues = new StringBuilder();
                                System.out.println("extractedValue"+extractedValues);

                                // Find numeric values before ':' in each line and append to the StringBuilder
                                while (matcher.find()) {
                                    //extractedValues.append(matcher.group(1)).append(" ");
                                    String staffCode = matcher.group(1);
                                    System.out.println("Count..."+matcher.groupCount());
                                    // Check if the staff ID exists in the database
                                    if (uniqueStaffCodes.contains(staffCode)) {
                                        extractedValues.append(staffCode).append(" ");
                                    } else if (staffRepository.existsByStaffCode(staffCode)) {
                                        extractedValues.append(staffCode).append(" ");
                                        uniqueStaffCodes.add(staffCode); // Add the staff code to the set to mark it as processed
                                        totalStaffCount++; // Increment total staff counter
                                    }
                                }
                                // Remove trailing space
                                String staffIds = extractedValues.toString().trim();
                                if (!staffIds.isEmpty()) {
                                    flightSectorMap.put(flightRoute, staffIds);
                                }
                            }

                        }

                    }
                }
            }

            int relatedStaff = uniqueStaffCodes.size();
            System.out.println("Total staff: " + totalStaffCount);


            // Displaying the flight sector and its corresponding index 16 value
            for (Map.Entry<String, String> entry : flightSectorMap.entrySet()) {
                System.out.println("Flight Sector: " + entry.getKey() + ", Staff ID : Crew Name: " + entry.getValue());
            }

            return "Try Block";
        } catch (
                IOException e) {
            e.printStackTrace();
            return "catch Block";
        }
    }

}
