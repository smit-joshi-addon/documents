package com.New.ACT.controller;

import com.New.ACT.service.VehicleService;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("vehicle")
public class VehicleController {
    @Autowired
    VehicleService vehicleService;

    @PostMapping("add")
    public Map<String, Object> addVehicle(@RequestBody String vehicleData, HttpServletRequest request) throws JSONException {
        return vehicleService.addVehicle(vehicleData, request);
    }

    //Update the Vehicle
    @PutMapping("/update")
    public Map<String, Object> updateVehicleById(@RequestBody String vehicleData) throws JSONException {
        return vehicleService.updateVehicleById(vehicleData);
    }

    /*http://localhost:8080/airlines/getById?alId=1*/
    @GetMapping("getById")
    public Map<String, Object> getVehicleById(@RequestParam(name = "vehicleId") int vehicleId) {
        return vehicleService.getVehicleById(vehicleId);
    }

    @GetMapping("getVehicleByIdJPQL")
    public Map<String, Object> getVehicleByIdJPQL(@RequestParam(name = "vehicleId") int vehicleId) {
        return vehicleService.getVehicleByIdJPQL(vehicleId);
    }

    @GetMapping("getActiveVehicleByIdNative")
    public Map<String, Object> getActiveVehicleByIdNative(@RequestParam(name = "vehicleId") int vehicleId) {
        return vehicleService.getActiveVehicleByIdNative(vehicleId);
    }
    // Only Get When Id Is Active
    @GetMapping("Auto/getByActiveVehicleId")
    public Map<String, Object> getActiveVehicleById(@RequestParam int vehicleId) {
        return vehicleService.getActiveVehicleById(vehicleId);
    }

    @GetMapping("getVehicleByPlatNum")
    public Map<String, Object> getVehicleByPlatNum(@RequestParam String platNum) {
        return vehicleService.getVehicleByPlatNum(platNum);
    }

    @GetMapping("getVehicleByPlatNumJPQL")
    public Map<String, Object> getVehicleByPlatNumJPQL(@RequestParam String platNum) {
        return vehicleService.getVehicleByPlatNumJPQL(platNum);
    }

    @GetMapping("getVehicleByPlatNumNative")
    public Map<String, Object> getVehicleByPlatNumNative(@RequestParam String platNum) {
        return vehicleService.getVehicleByPlatNumNative(platNum);
    }

    @GetMapping("Auto/getVehicleByPersonCapacity")
    public Map<String, Object> getVehicleByPersonCapacity(@RequestParam int perCap) {
        return vehicleService.getVehicleByPersonCapacity(perCap);
    }

    @GetMapping("/getVehicleByPersonCapacityJPQL")
    public Map<String, Object> getVehicleByPersonCapacityJPQL(@RequestParam int perCap) {
        return vehicleService.getVehicleByPersonCapacityJPQL(perCap);
    }

    @GetMapping("getVehicleByPersonCapacityNative")
    public Map<String, Object> getVehicleByPersonCapacityNative(@RequestParam int perCap) {
        return vehicleService.getVehicleByPersonCapacityNative(perCap);
    }




    @GetMapping("getVehicleByBrandJPQL")
    public Map<String, Object> getVehicleByBrandJPQL(@RequestParam String brand) {
        return vehicleService.getVehicleByBrandJPQL(brand);
    }

    @GetMapping("getVehicleByBrandNative")
    public Map<String, Object> getVehicleByBrandNative(@RequestParam String brand) {
        return vehicleService.getVehicleByBrandNative(brand);
    }

    @GetMapping("getVehicleByBrand")
    public Map<String, Object> getVehicleByBrand(@RequestParam String brand) {
        return vehicleService.getVehicleByBrand(brand);
    }

    @GetMapping("getVehicleByModel")
    public Map<String, Object> getVehicleByModel(@RequestParam String model) {
        return vehicleService.getVehicleByModel(model);
    }

    @GetMapping("getVehicleByModelJPQL")
    public Map<String, Object> getVehicleByModelJPQL(@RequestParam String model) {
        return vehicleService.getVehicleByModelJPQL(model);
    }

    @GetMapping("getVehicleByModelNative")
    public Map<String, Object> getVehicleByModelNative(@RequestParam String model) {
        return vehicleService.getVehicleByModelNative(model);
    }


    // Get all Airlines with Deleted
    @GetMapping("/allVehicles")
    public Map<String, Object> getAllVehicles() {
        return vehicleService.getAllVehicles();
    }

    // Get all Airlines without Deleted
    @GetMapping("/allActiveVehicles")
    public Map<String, Object> getAllActiveVehicles() {
        return vehicleService.getAllActiveVehicles();
    }

    // Get all Airlines without Deleted
    @GetMapping("/allDeleteVehicles")
    public Map<String, Object> getAllDeleteVehicles() {
        return vehicleService.getAllDeleteVehicles();
    }

    //Pagination Get all Vehicles with Deleted
    // If With Path Variable  @GetMapping("/allAirlinesPagination" or "/allAirlinesPagination/{page}...)
    @GetMapping("/allActiveAirlinesPagination")
    public Map<String, Object> getAllActiveVehiclePagination(@RequestParam(defaultValue = "0") int page,
                                                             @RequestParam(defaultValue = "5") int size,
                                                             @RequestParam(defaultValue = "vehicleId") String sortBy) {
        return vehicleService.getAllActiveVehiclesPagination(page, size, sortBy);
    }

    @GetMapping("/allAirlinesPagination")
    public Map<String, Object> getAllVehiclePagination(@RequestParam(defaultValue = "0") int page,
                                                       @RequestParam(defaultValue = "5") int size,
                                                       @RequestParam(defaultValue = "vehicleId") String sort) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sort).descending());
        return vehicleService.getAllVehiclesPagination(pageable);
    }


    @DeleteMapping("deleteById")
    public Map<String, Object> delVehicleById(@RequestParam int vehicleId) {
        return vehicleService.delVehicleById(vehicleId);
    }

    @DeleteMapping("deleteHard")
    public Map<String, Object> delVehicleHard(@RequestParam int vehicleId) {
        return vehicleService.delVehicleIdHard(vehicleId);
    }

    @PutMapping("revertById")
    public Map<String, Object> revertVehicleById(@RequestParam int vehicleId) {
        return vehicleService.revertVehicleById(vehicleId);
    }


}
