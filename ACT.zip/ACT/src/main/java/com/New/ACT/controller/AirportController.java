package com.New.ACT.controller;

import com.New.ACT.service.AirportService;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("airports")
public class AirportController {

    @Autowired
    AirportService airportService;

    //Insert
    @PostMapping("/add")
    public Map<String, Object> addAirport(@RequestBody String airportData, HttpServletRequest request) throws JSONException {
        return airportService.addAirport(airportData, request);
    }

    //Insert Through Request Param
    //http://localhost:8080/airports/addByParam Body-> FormData
    @PostMapping("/addByParam")
    public Map<String, Object> addAirportByParam(@RequestParam String airportData, HttpServletRequest request) throws JSONException {
        // System.out.println("Airport Data "+airportData);

        return airportService.addAirport(airportData, request);
    }

    // Get One Record By Id.
    //http://localhost:8080/airports/1
    @GetMapping("/{apId}")
    public Map<String, Object> getAirportById(@PathVariable int apId) {
        return airportService.getAirportById(apId);
    }

    //Work in both param & form-data
    //http://localhost:8080/airports/getAirportByParam?apId=1
    @GetMapping("/getAirportByParam")
    public Map<String, Object> getAirportByParam(@RequestParam int apId) {
        return airportService.findByAirportIdJPQL(apId);
    }

    @GetMapping("/getByIdNative")
    public Map<String, Object> getAirportByIdNative(@RequestParam int apId) {
        return airportService.getAirportByIdNative(apId);
    }

    @GetMapping("getByIATACode")
    public Map<String, Object> getByIATACode(@RequestParam String IATACode) {
        return airportService.getByIATACode(IATACode);
    }

    @GetMapping("getByIATACodeJPQL")
    public Map<String, Object> getByIATACodeJPQL(@RequestParam String IATACode) {
        return airportService.getByIATACodeJPQL(IATACode);
    }

    @GetMapping("getByIATACodeNative")
    public Map<String, Object> getByIATACodeNative(@RequestParam String IATACode) {
        return airportService.getByIATACodeNative(IATACode);
    }

    @GetMapping("getByAirportAddress")
    public Map<String, Object> getByAirportAddress(@RequestParam String airportAddress) {
        return airportService.getByAirportAddress(airportAddress);
    }

    @GetMapping("getByAirportAddressJPQL")
    public Map<String, Object> getByAirportAddressJPQL(@RequestParam String airportAddress) {
        return airportService.getByAirportAddressJPQL(airportAddress);
    }

    @GetMapping("getByAirportAddressNative")
    public Map<String, Object> getByAirportAddressNative(@RequestParam String airportAddress) {
        return airportService.getByAirportAddressNative(airportAddress);
    }


    @GetMapping("getByAirportCountry")
    public Map<String, Object> getByAirportCountry(@RequestParam String airportCountry) {
        return airportService.getByAirportCountry(airportCountry);
    }

    @GetMapping("getByAirportCountryJQPL")
    public Map<String, Object> getByAirportCountryJPQL(@RequestParam String airportCountry) {
        return airportService.getByAirportCountryJPQL(airportCountry);
    }

    @GetMapping("getByAirportCountryNative")
    public Map<String, Object> getByAirportCountryNative(@RequestParam String airportCountry) {
        return airportService.getByAirportCountryNative(airportCountry);
    }
@GetMapping("getByAirportRegion")
    public Map<String, Object> getByAirportRegion(@RequestParam String airportRegion) {
        return airportService.getByAirportRegion(airportRegion);
    }
@GetMapping("getByAirportRegionJPQL")
    public Map<String, Object> getByAirportRegionJPQL(@RequestParam String airportRegion) {
        return airportService.getByAirportRegionJPQL(airportRegion);
    }
@GetMapping("getByAirportRegionNative")
    public Map<String, Object> getByAirportRegionNative(@RequestParam String airportRegion) {
        return airportService.getByAirportRegionNative(airportRegion);
    }


    //Only pass value as 10
    @GetMapping("/getAirportByBody")
    public Map<String, Object> getAirportByBody(@RequestBody int apId) {
        //System.out.println("data"+data);
        //System.out.println("tri"+tri);
        return airportService.getAirportById(apId);
    }

    //Get All The Airports.
    @GetMapping("/getAirports")
    public Map<String, Object> getAllAirports() {
        return airportService.getAllAirports();
    }


    //Get All The Airports.
    @GetMapping("/getAirportsPage")
    public Map<String, Object> getAllAirportsPagination(@RequestParam(defaultValue = "0") int page,
                                                        @RequestParam(defaultValue = "3") int size,
                                                        @RequestParam(defaultValue = "airportId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).ascending().and(Sort.by("IATACode")));
        return airportService.getAllAirportsPagination(pageable);
    }

    //Update the Airport
    @PutMapping("/update")
    public Map<String, Object> updateAirportById(@RequestBody String airportData) throws JSONException {
        return airportService.updateAirportById(airportData);
    }

    //Revert
    @PutMapping("/{apId}")
    public Map<String, Object> revertAirport(@PathVariable int apId) {
        return airportService.revertAirport(apId);
    }

    // Soft Delete
    @DeleteMapping("delete/{apId}")
    public Map<String, Object> delAirportByID(@PathVariable int apId) {
        return airportService.delAirportById(apId);
    }

    //Hard Delete
    @DeleteMapping("/{apId}")
    public Map<String, Object> delAirportHard(@PathVariable int apId) {
        return airportService.delAirportHard(apId);
    }


    //Return ALl the records that are soft Deleted.
    @GetMapping("softDelAirports")
    public Map<String, Object> findSoftDelAirports() {
        return airportService.findSoftDelAirports();
    }

    @GetMapping("softDelAirportsPage")
    public Map<String, Object> findSoftDelAirportsPage(@RequestParam(defaultValue = "0") int page,
                                                       @RequestParam(defaultValue = "3") int size,
                                                       @RequestParam(defaultValue = "airportId") String sortBy) {
        return airportService.findSoftDelAirportsPagination(size, page, sortBy);
    }

    //Return Only Active Record JPQL Query.
    @GetMapping("activeAirports")
    public Map<String, Object> findActiveAirports() {
        return airportService.findActiveAirports();
    }

    @GetMapping("activeAirportsPage")
    public Map<String, Object> findActiveAirportsPagination(@RequestParam(defaultValue = "0") int page,
                                                            @RequestParam(defaultValue = "3") int size,
                                                            @RequestParam(defaultValue = "airportId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).ascending().and(Sort.by("IATACode")));
        return airportService.findActiveAirportsPagination(pageable);
    }

    @PostMapping("test")
    public String test(@RequestParam String a) {
        //Pass In the Param
        // Request Body In the raw

        //  System.out.println("Airport---"+airport);
        System.out.println("Num---" + a);
        return null;
    }
}
