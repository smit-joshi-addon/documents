package com.New.ACT.service;

import com.New.ACT.Repository.AirlineRepository;
import com.New.ACT.Repository.AirportRepository;
import com.New.ACT.model.Airline;
import com.New.ACT.model.Airport;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.json.JSONObject;
import org.locationtech.jts.geom.*;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.*;

@Service
public class AirlineService {
    @Autowired
    AirlineRepository airlineRepository;
    @Autowired
    AirportRepository airportRepository;


    //Insert
   /* public String addAirline(Airline airline, HttpServletRequest request){
        //To get the client ip
        String ipAddress = request.getHeader("X-FORWARDED-FOR");
        if(ipAddress == null || ipAddress.isEmpty()){
            airline.setIpAddress(request.getRemoteAddr());
        }


        *//*String ipAddress = request.getHeader("X-FORWARDED-FOR");

                if (ipAddress == null || ipAddress.isEmpty()) {
                     String remoteAddr = request.getRemoteAddr();

                  // Check if it's an IPv6 loopback address and convert to IPv4
                    if (remoteAddr.equals("0:0:0:0:0:0:0:1")) {
                          InetAddress inetAddress;
                          try {
                              inetAddress = InetAddress.getLocalHost();
                              remoteAddr = inetAddress.getHostAddress();
                          } catch (UnknownHostException e) {
                       e.printStackTrace(); // Handle the exception as needed
                   }
               }

                airline.setIpAddress(remoteAddr);
            }*//*
            // Rest of your method...

        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
        airline.setCreationTime(currentTimestamp);
        alRepo.save(airline);
        return "Created";
    }
*/
    //Inserted
//    public Map<String,Object> addAirline(String data, HttpServletRequest request) throws JSONException {
//
//        JSONObject obj = new JSONObject(data);


    //To get the client ip
       /* String ipAddress = request.getHeader("X-FORWARDED-FOR");
        if(ipAddress == null || ipAddress.isEmpty()){
            airline.setIpAddress(request.getRemoteAddr());
        }
        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
        airline.setCreationTime(currentTimestamp);
        alRepo.save(airline);
        return "Created";*/
//    }

    //Insert
    public Map<String, Object> addAirline(String airlineData, HttpServletRequest request) throws JSONException {
        JSONObject jsonData = new JSONObject(airlineData);
        Map<String, Object> m1 = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        Airport airport = null;
        int airportId = 0;

        String airlineName = null;
        String airlineAddress = null;

        Geometry airlineLocation = null;
        String mobileNum1;
        String mobileNum2 = null;
        String mobileNum3 = null;

        String email1 = null;
        String email2 = null;

        try {
            if (jsonData.has("airportId") && jsonData.get("airportId") != null
                    && !jsonData.get("airportId").equals("")) {
                //airportId = jsonData.getJSONObject("airportId").getInt("airportId");
                airportId = jsonData.getInt("airportId");
                Optional<Airport> existingAirportOptional = airportRepository.findById(airportId);
                //airport = airportRepository.findById(airportId).get() ;
                airport = existingAirportOptional.orElse(null);
                if (airport == null) {
                    m1.put("status", "error");
                    m1.put("error", "no_longer_available");
                    m1.put("message", "Sorry, this airport is not longer available.");
                    return m1;
                }
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field_validation");
                m1.put("message", "Please provide airport identification like airportId.");
                return m1;
            }

            //airlineName Validation
            if (jsonData.has("airlineName") && !jsonData.get("airlineName").equals("")
                    && jsonData.get("airlineName") != null) {
                airlineName = jsonData.getString("airlineName");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide airlineName.");
                return m1;
            }

            // airline Address Validation
            if (jsonData.has("airlineAddress") && !jsonData.get("airlineAddress").equals("")
                    && jsonData.get("airlineAddress") != null) {
                airlineAddress = jsonData.getString("airlineAddress");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide alAddress.");
                return m1;
            }
            // Airport Location Validation
            if (jsonData.has("airlineLocation") && !jsonData.get("airlineLocation").equals("")
                    && jsonData.get("airlineLocation") != null) {
                // Use JTS to convert the WKT string to a Geometry object
                WKTReader wktReader = new WKTReader();
                airlineLocation =  wktReader.read(jsonData.getString("airlineLocation"));
                airlineLocation.setSRID(4326);
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide Airline Location.");
                return m1;
            }
            //mobileNum1   Validation
            if (jsonData.has("mobileNum1") && !jsonData.get("mobileNum1").equals("")
                    && jsonData.get("mobileNum1") != null) {
                mobileNum1 = jsonData.getString("mobileNum1");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide mobileNum1.");
                return m1;
            }

            if (jsonData.has("email1") && !jsonData.get("email1").equals("")
                    && jsonData.get("email1") != null) {
                email1 = jsonData.getString("email1");
            } else {
                m1.put("status", "error");
                m1.put("error", "required_field");
                m1.put("message", "Please provide email1.");
                return m1;
            }
            if (jsonData.has("mobileNum2") && !jsonData.get("mobileNum2").equals("")
                    && jsonData.get("mobileNum2") != null) {
                mobileNum2 = jsonData.getString("mobileNum2");
            }
            if (jsonData.has("mobileNum3") && !jsonData.get("mobileNum3").equals("")
                    && jsonData.get("mobileNum3") != null) {
                mobileNum3 = jsonData.getString("mobileNum3");
            }
            if (jsonData.has("email2") && !jsonData.get("email2").equals("")
                    && jsonData.get("email2") != null) {
                email2 = jsonData.getString("email2");
            }


            /*GeometryFactory geometryFactory = new GeometryFactory();
            //Convert lat * log to point
            Point point = geometryFactory.createPoint(new Coordinate(longitude, latitude));
            // Convert Point to WKT
            WKTWriter wktWriter = new WKTWriter();
            String wktPoint = wktWriter.write(point);


            WKTReader fromText = new WKTReader();
            // GeometryFactory geometryFactory = new GeometryFactory(new PrecisionModel(), );
            //String wktPoint = String.format("POINT(%f %f)", longitude, latitude);
            //location = fromText.read(wktPoint);
            try {
                location = fromText.read(wktPoint);
            } catch (ParseException e) {
                throw new RuntimeException("Not a WKT string:" + wktPoint, e);
            }
            location.setSRID(4326);
*/
          /*  String wktPoint =String.format("SRID=4326;POINT (%f %f)", longitude, latitude);
            WKTReader fromText = new WKTReader();
            location = fromText.read(wktPoint);*/

            Airline airline = new Airline();
            airline.setAirport(airport);
            airline.setAirlineName(airlineName);
            airline.setAirlineAddress(airlineAddress);
            airline.setMobileNum1(mobileNum1);
            airline.setMobileNum2(mobileNum2);
            airline.setMobileNum3(mobileNum3);
            airline.setEmail1(email1);
            airline.setEmail2(email2);
            airline.setAirlineLocation(airlineLocation);
            airline.setCreationTime(new Timestamp(System.currentTimeMillis()));
            airline.setActive(true);
            airline.setDelete(false);
            String ipAddress = request.getHeader("X-FORWARDED-FOR");
            if (ipAddress == null || ipAddress.isEmpty()) {
                airline.setIpAddress(request.getRemoteAddr());
            }
            airlineRepository.save(airline);

            m1.put("status", "success");
            m1.put("AirlineId", airline.getAirlineId());
            m1.put("AirlineName", airline.getAirlineName());
            m1.put("AirlineAddress", airline.getAirlineAddress());
            m1.put("AirlineLocation", airline.getAirlineLocation().toText());
            m1.put("MobileNum1", airline.getMobileNum1());
            m1.put("MobileNum2", airline.getMobileNum2());
            m1.put("MobileNum3", airline.getMobileNum3());
            m1.put("Email1", airline.getEmail1());
            m1.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            m1.put("Airport", map);
            m1.put("message", "Airline information saved successfully!!");
            return m1;

        } catch (Exception e) {
            e.printStackTrace();
            m1.put("status", "error");
            m1.put("error", "not_found");
            m1.put("message", "Something went wrong");
            return m1;
        }
    }


    //Get By ID Function
    public Map<String, Object> getAirlineById(int alId) {

        Airline airline;
        Optional<Airline> existingAirlineOptional = airlineRepository.findById(alId);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingAirlineOptional.isPresent()) {
                airline = existingAirlineOptional.get();
                propertyMap.put("AirlineId", airline.getAirlineId());
                propertyMap.put("AirlineName", airline.getAirlineName());
                propertyMap.put("AirlineAddress", airline.getAirlineAddress());
                propertyMap.put("AirlineLocation", airline.getAirlineLocation().toText());
                propertyMap.put("MobileNum1", airline.getMobileNum1());
                propertyMap.put("MobileNum2", airline.getMobileNum2());
                propertyMap.put("MobileNum3", airline.getMobileNum3());
                propertyMap.put("Email1", airline.getEmail1());
                propertyMap.put("Email2", airline.getEmail2());
                map.put("AirportId", airline.getAirport().getAirportId());
                map.put("IATACode", airline.getAirport().getIATACode());
                map.put("AirportAddress", airline.getAirport().getAirportAddress());
                map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
                map.put("AirportCountry", airline.getAirport().getAirportCountry());
                map.put("AirportRegion", airline.getAirport().getAirportRegion());
                propertyMap.put("Airport", map);
                propertyMap.put("Demo",airline.getAirport().toString());
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Airline" + alId + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Airline Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }

    }

    //Get all the airline details
    public Map<String, Object> getAllAirlines() {
        List<Airline> existingAirlineOptional = airlineRepository.findAll();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingAirlineOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Airline airline : existingAirlineOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("AirlineLocation", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());

            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            System.out.println("\n Data" + data);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Airline", data);
        return propertyMap;

    }

    // With Pagination
    public Map<String, Object> getAllAirlinesPagination(int page, int size, String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy));
        Page<Airline> existingAirlineOptional = airlineRepository.findAll(pageable);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingAirlineOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Airline airline : existingAirlineOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("AirlineLocation", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());

            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            System.out.println("\n Data" + data);
        }

        propertyMap.put("status", "success");
        propertyMap.put("Airline", data);
        return propertyMap;

    }


// This method is for the update but update the given field and other will be null
    /*public Airline updateAirline(Integer alId , Airline airline){
        al = alRepo.findById(alId).get();
        System.out.println(al);

        if(Objects.nonNull(al.getAirlineId())){
            airline.setAirlineId(alId);
        }
        return alRepo.save(airline);
    }*/

    //Update Method With All Records
    public Map<String, Object> updateAirline(String airlineData) throws JSONException {
        JSONObject jsonData = new JSONObject(airlineData);
        Map<String, Object> map = new HashMap<>();
        Airline airline;
        int airlineId = 0;
        Airport airport = new Airport();
        int airportId = 0;
        double latitude = 0;
        double longitude = 0;
        Geometry location = null;
        try {
            if (jsonData.has("airlineId") && jsonData.get("airlineId") != null
                    && !jsonData.get("airlineId").equals("")) {
                airlineId = jsonData.getInt("airlineId");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide airlineId.");
                return map;
            }
            Optional<Airline> existingAirlineOptional = airlineRepository.findById(airlineId);

            if (existingAirlineOptional.isPresent()) {
                airline = existingAirlineOptional.get();
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "The Airline Does Not Exist.");
                return map;
            }
            if (airline.isActive() && !airline.isDelete()) {

            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "AirlineId is Soft Delete.");
                return map;
            }
            if (jsonData.has("airportId") && jsonData.get("airportId") != null
                    && !jsonData.get("airportId").equals("")) {
                airportId = jsonData.getInt("airportId");

                Optional<Airport> existingAirportOptional = airportRepository.findById(airportId);
                System.out.println("Exist " + existingAirportOptional);
                if (existingAirportOptional.isPresent()) {
                    airline.setAirport(airportRepository.findById(airportId).get());
                } else {
                    map.put("status", "error");
                    map.put("error", "no_longer_available");
                    map.put("message", "Sorry, this airport id is not in the database.");
                    return map;
                }
            }
            if (jsonData.has("airlineName") && jsonData.get("airlineName") != null
                    && !jsonData.get("airlineName").equals("")) {
                airline.setAirlineName(jsonData.getString("airlineName"));
            }
            // airline Address Update
            if (jsonData.has("airlineAddress") && !jsonData.get("airlineAddress").equals("")
                    && jsonData.get("airlineAddress") != null) {
                airline.setAirlineAddress(jsonData.getString("airlineAddress"));
            }
            if (jsonData.has("airlineLocation")) {
                if (!jsonData.get("airlineLocation").equals("") && !jsonData.get("airlineLocation").equals(null) && jsonData.get("airlineLocation") != null) {
                    WKTReader wktReader = new WKTReader();
                    location =wktReader.read(jsonData.getString("airlineLocation"));
                    location.setSRID(4326);
                    airline.setAirlineLocation(location);
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper airlineLocation.");
                    return map;
                }
            }
            //Airline mobile NUmber Update
            if (jsonData.has("mobileNum1") && !jsonData.get("mobileNum1").equals("")
                    && jsonData.get("mobileNum1") != null) {
                airline.setMobileNum1(jsonData.getString("mobileNum1"));
            }
            if (jsonData.has("mobileNum2") && !jsonData.get("mobileNum2").equals("")
                    && jsonData.get("mobileNum2") != null) {
                airline.setMobileNum2(jsonData.getString("mobileNum2"));
            }
            if (jsonData.has("mobileNum3") && !jsonData.get("mobileNum3").equals("")
                    && jsonData.get("mobileNum3") != null) {
                airline.setMobileNum3(jsonData.getString("mobileNum3"));
            }
            //Airline Email Update
            if (jsonData.has("email1") && !jsonData.get("email1").equals("")
                    && jsonData.get("email1") != null) {
                airline.setEmail1(jsonData.getString("email1"));
            }
            if (jsonData.has("email2") && !jsonData.get("email2").equals("")
                    && jsonData.get("email2") != null) {
                airline.setEmail2(jsonData.getString("email2"));
            }

            airlineRepository.save(airline);
            map.put("status", "success");
            map.put("message", "Airline id " + airlineId + " Update Confirmed!!!");
            // To Return Airline
            Map<String, Object> propertyMap = new HashMap<>();
            map.put("AirlineId", airline.getAirlineId());
            map.put("AirlineName", airline.getAirlineName());
            map.put("AirlineAddress", airline.getAirlineAddress());
            map.put("Airline Location", airline.getAirlineLocation().toText());
            map.put("MobileNum1", airline.getMobileNum1());
            map.put("MobileNum2", airline.getMobileNum2());
            map.put("MobileNum3", airline.getMobileNum3());
            map.put("Email1", airline.getEmail1());
            map.put("Email2", airline.getEmail2());
            propertyMap.put("AirportId", airline.getAirport().getAirportId());
            propertyMap.put("IATACode", airline.getAirport().getIATACode());
            propertyMap.put("AirportAddress", airline.getAirport().getAirportAddress());
            propertyMap.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            propertyMap.put("AirportCountry", airline.getAirport().getAirportCountry());
            propertyMap.put("AirportRegion", airline.getAirport().getAirportRegion());
            map.put("Airport", propertyMap);
            // map.put("Airline Record ", airline);
        } catch (JSONException | ParseException e) {
            e.printStackTrace();
            map.put("status", "error");
            map.put("error", "not_found");
            map.put("message", "Something went wrong");
            return map;
        }
        return map;

       /* Airline al = new Airline();
        al = airlineRepository.findById(alId).get();

        if (Objects.nonNull(al.getAirlineId())) {
            al.setAirlineName(airline.getAirlineName());
        }
        return airlineRepository.save(al);*/
    }

    public Map<String, Object> updateActiveAirline(String airlineData) throws JSONException {
        JSONObject jsonData = new JSONObject(airlineData);
        Map<String, Object> map = new HashMap<>();
        Airline airline;
        int airlineId = 0;
        Airport airport = new Airport();
        int airportId = 0;
        double latitude = 0;
        double longitude = 0;
        Geometry location = null;
        try {
            if (jsonData.has("airlineId") && jsonData.get("airlineId") != null
                    && !jsonData.get("airlineId").equals("")) {
                airlineId = jsonData.getInt("airlineId");
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "Please provide airlineId.");
                return map;
            }
            //Optional<Airline> existingAirlineOptional = airlineRepository.findById(airlineId);
            Optional<Airline> existingAirlineOptional = airlineRepository.findByIsActiveTrueAndAirlineId(airlineId);
            if (existingAirlineOptional.isPresent()) {
                airline = existingAirlineOptional.get();
            } else {
                map.put("status", "error");
                map.put("error", "required_field");
                map.put("message", "The Airline Does Not Exist.");
                return map;
            }

            if (!airline.getAirport().isActive() && airline.getAirport().isDelete()) {
                map.put("status", "error");
                map.put("error", "no_longer_available_airportId");
                map.put("message", "Sorry, This airport id is not Updatable.");
                return map;
            }
            if (jsonData.has("airportId") && jsonData.get("airportId") != null
                    && !jsonData.get("airportId").equals("")) {
                airportId = jsonData.getInt("airportId");

                Optional<Airport> existingAirportOptional = airportRepository.findActiveByAirportId(airportId);
                System.out.println("Exist " + existingAirportOptional);
                if (existingAirportOptional.isPresent()) {
                    airport = existingAirportOptional.get();
                    airline.setAirport(airport);
                } else {
                    map.put("status", "error");
                    map.put("error", "no_longer_available");
                    map.put("message", "Sorry, this airport id is not in the database.");
                    return map;
                }
            }
            if (jsonData.has("airlineName") && jsonData.get("airlineName") != null
                    && !jsonData.get("airlineName").equals("")) {
                airline.setAirlineName(jsonData.getString("airlineName"));
            }
            // airline Address Update
            if (jsonData.has("airlineAddress") && !jsonData.get("airlineAddress").equals("")
                    && jsonData.get("airlineAddress") != null) {
                airline.setAirlineAddress(jsonData.getString("airlineAddress"));
            }

            if (jsonData.has("airlineLocation")) {
                if (!jsonData.get("airlineLocation").equals("") && !jsonData.get("airlineLocation").equals(null) && jsonData.get("airlineLocation") != null) {
                    WKTReader wktReader = new WKTReader();
                    location =wktReader.read(jsonData.getString("airlineLocation"));
                    location.setSRID(4326);
                    airline.setAirlineLocation(location);
                } else {
                    map.put("status", "error");
                    map.put("error", "Invalid Input");
                    map.put("message", "Please provide proper airlineLocation.");
                    return map;
                }
            }
            //Airline mobile NUmber Update
            if (jsonData.has("mobileNum1") && !jsonData.get("mobileNum1").equals("")
                    && jsonData.get("mobileNum1") != null) {
                airline.setMobileNum1(jsonData.getString("mobileNum1"));
            }
            if (jsonData.has("mobileNum2") && !jsonData.get("mobileNum2").equals("")
                    && jsonData.get("mobileNum2") != null) {
                airline.setMobileNum2(jsonData.getString("mobileNum2"));
            }
            if (jsonData.has("mobileNum3") && !jsonData.get("mobileNum3").equals("")
                    && jsonData.get("mobileNum3") != null) {
                airline.setMobileNum3(jsonData.getString("mobileNum3"));
            }
            //Airline Email Update
            if (jsonData.has("email1") && !jsonData.get("email1").equals("")
                    && jsonData.get("email1") != null) {
                airline.setEmail1(jsonData.getString("email1"));
            }
            if (jsonData.has("email2") && !jsonData.get("email2").equals("")
                    && jsonData.get("email2") != null) {
                airline.setEmail2(jsonData.getString("email2"));
            }

            airline = airlineRepository.save(airline);
            map.put("status", "success");
            map.put("message", "Airline id " + airlineId + " Update Confirmed!!!");
            // To Return Airline
            Map<String, Object> propertyMap = new HashMap<>();
            map.put("AirlineId", airline.getAirlineId());
            map.put("AirlineName", airline.getAirlineName());
            map.put("AirlineAddress", airline.getAirlineAddress());
            map.put("Airline Location", airline.getAirlineLocation().toText());
            map.put("MobileNum1", airline.getMobileNum1());
            map.put("MobileNum2", airline.getMobileNum2());
            map.put("MobileNum3", airline.getMobileNum3());
            map.put("Email1", airline.getEmail1());
            map.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            map.put("Airport", propertyMap);

        } catch (JSONException | ParseException e) {
            e.printStackTrace();
            map.put("status", "error");
            map.put("error", "not_found");
            map.put("message", "Something went wrong");
            return map;
        }
        return map;
    }

    //Though Query.
    @Transactional
    public void revertById(int alId) {
        airlineRepository.revert(alId);
    }

    //Through Native Query.
    @Transactional
    public void revertByIdN(int alId) {
        airlineRepository.revertN(alId);
    }

    public Map<String, Object> revertAirline(int alId) {
        Map<String, Object> map = new HashMap<>();

        try {
            Optional<Airline> existingAirlineOptional = airlineRepository.findById(alId);
            if (existingAirlineOptional.isPresent()) {
                Airline airline = existingAirlineOptional.get();

                if (!airline.isActive() && airline.isDelete()) {
                    airline.setDelete(false);
                    airline.setActive(true);
                    airline.setDeletionTime(null);
                    airlineRepository.save(airline);
                    map.put("status", "success");
                    map.put("message", "Airline " + alId + " Revert Confirmed!!");
                    return map;
                } else {
                    map.put("status", "error");
                    map.put("error", "Airline can't be Reverted.");
                    return map;
                }
            } else {
                map.put("status", "error");
                map.put("error", "Airline " + alId + " field is invalid input.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Please Check Again.");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }

// Fetch data for the deleted record through method
    /*public List<Airline> getDeletedRecords() {
        return alRepo.findByIsDeleteTrue();
    }*/

    // Get Active Records
    public Map<String, Object> getActiveAirlines() {

        List<Airline> existingAirlineOptional = airlineRepository.findActiveAirlines();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map ;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingAirlineOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Airline airline : existingAirlineOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline Location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
        }

        propertyMap.put("status", "success");
        propertyMap.put("data", data);
        return propertyMap;
    }

    // Get Active Records
    public Map<String, Object> getActiveAirlinesNative() {

        List<Airline> existingAirlineOptional = airlineRepository.findActiveAirlinesNative();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingAirlineOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "data not found");
            return propertyMap;
        }

        for (Airline airline : existingAirlineOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
            System.out.println("Map \n" + map);
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            System.out.println("\n Data" + data);
        }

        propertyMap.put("status", "success");
        propertyMap.put("data", data);
        return propertyMap;


    }

    // Get The Soft Deleted Records
    public Map<String, Object> getDeletedRecords() {

        List<Airline> existingAirlineOptional = airlineRepository.findDeletedAirlines();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map ;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingAirlineOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Not Records Of Deleted Airlines.");
            return propertyMap;
        }

        for (Airline airline : existingAirlineOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
            System.out.println("Map \n" + map);
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            System.out.println("\n Data" + data);
        }

        propertyMap.put("status", "success");
        propertyMap.put("data", data);
        return propertyMap;
    }

    //By Native Get The Soft Deleted Records
    public Map<String, Object> getDeletedRecordsNative() {

        List<Airline> existingAirlineOptional = airlineRepository.findDeletedAirlinesNative();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingAirlineOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "Not Records Of Deleted Airlines.");
            return propertyMap;
        }

        for (Airline airline : existingAirlineOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            //propertyMap.put("getCreationTime", airport.getCreationTime());
            //propertyMap.put("Is_Active", airport.isActive());
            //propertyMap.put("Is_Delete", airport.isDelete());
            data.add(propertyMap2);
            System.out.println("Map \n" + map);
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            System.out.println("\n Data" + data);
        }

        propertyMap.put("status", "success");
        propertyMap.put("data", data);
        return propertyMap;
    }

    // Delete By Id Soft Delete
    public Map<String, Object> delAirlineById(int alId) {
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            Optional<Airline> existingAirlineOptional = airlineRepository.findById(alId);
            if (existingAirlineOptional.isPresent()) {

                Airline airline = existingAirlineOptional.get();
                if (airline.isDelete()) {
                    propertyMap.put("status", "error");
                    propertyMap.put("error", "no_longer_change_available");
                    propertyMap.put("message", "Sorry, this Airline " + alId + " is Already Deleted.");
                    return propertyMap;
                }
                airline.setDelete(true);
                airline.setActive(false);
                airline.setDeletionTime(new Timestamp(System.currentTimeMillis()));
                airlineRepository.save(airline);
                propertyMap.put("status", "success");
                propertyMap.put("message", "Airline soft deletion Confirmed!!");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Airline" + alId + " is not Existed.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Airline Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
       /* Airline al = new Airline();
        al = airlineRepository.findById(alId).get();
        if (Objects.nonNull(al.getAirlineId())) {
            al.setDelete(true);
            al.setActive(false);
            Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
            al.setDeletionTime(currentTimestamp);
        }
        return airlineRepository.save(al);*/
    }

    // Delete By Id Soft Delete Using Active Records
    public Map<String, Object> delActiveAirlineById(int alId) {
        Map<String, Object> propertyMap = new HashMap<>();

        try {
            Optional<Airline> existingAirlineOptional = airlineRepository.findByIsActiveTrueAndAirlineId(alId);
            if (existingAirlineOptional.isPresent()) {

                Airline airline = existingAirlineOptional.get();
                airline.setDelete(true);
                airline.setActive(false);
                airline.setDeletionTime(new Timestamp(System.currentTimeMillis()));
                airlineRepository.save(airline);
                propertyMap.put("status", "success");
                propertyMap.put("message", "Airline soft deletion Confirmed!!");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Airline" + alId + " is not Existed.");
                return propertyMap;
            }
        } catch (Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Airline Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    //HARD DELETE
    public Map<String, Object> delAirlineHard(int alId) {
        Map<String, Object> map = new HashMap<>();

        Optional<Airline> existingAirlineOptional = airlineRepository.findById(alId);

        try {
            if (existingAirlineOptional.isPresent()) {
                //airportRepository.deleteById(apId);
                System.out.println("\n\nthis \n" + existingAirlineOptional.get().getAirlineId());
                airlineRepository.deleteById(existingAirlineOptional.get().getAirlineId());
                map.put("status", "success");
                map.put("message", "Airline id " + alId + " deletion Confirmed!!");
                return map;
            } else {
                map.put("status", "error");
                map.put("error", "no_longer_available");
                map.put("message", "Sorry, this Airline " + alId + " does not Existed.");
                return map;
            }
        } catch (Exception e) {
            map.put("status", "exception");
            map.put("exception", "Invalid Airline Id");
            map.put("message", "Something went Wrong...");
            return map;
        }
    }

    //Delete All Airlines
    public String delAllAirlines() {
        airlineRepository.deleteAll();
        return "All Airline Got Deleted";
    }

    // Native & Jpql Query
    public Map<String, Object> getAirlineByIdAuto(int alId) {
        Airline airline = airlineRepository.findByAirlineId(alId);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (airline != null) {
                propertyMap.put("AirlineId", airline.getAirlineId());
                propertyMap.put("AirlineName", airline.getAirlineName());
                propertyMap.put("AirlineAddress", airline.getAirlineAddress());
                propertyMap.put("Airline_location", airline.getAirlineLocation().toText());
                propertyMap.put("MobileNum1", airline.getMobileNum1());
                propertyMap.put("MobileNum2", airline.getMobileNum2());
                propertyMap.put("MobileNum3", airline.getMobileNum3());
                propertyMap.put("Email1", airline.getEmail1());
                propertyMap.put("Email2", airline.getEmail2());
                map.put("AirportId", airline.getAirport().getAirportId());
                map.put("IATACode", airline.getAirport().getIATACode());
                map.put("AirportAddress", airline.getAirport().getAirportAddress());
                map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
                map.put("AirportCountry", airline.getAirport().getAirportCountry());
                map.put("AirportRegion", airline.getAirport().getAirportRegion());
                propertyMap.put("Airport", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Airline" + alId + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Airline Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> getAirlineByIdJPQL(int alId) {
        Airline airline = airlineRepository.findByAirlineIdJPQL(alId);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (airline != null) {
                propertyMap.put("AirlineId", airline.getAirlineId());
                propertyMap.put("AirlineName", airline.getAirlineName());
                propertyMap.put("AirlineAddress", airline.getAirlineAddress());
                propertyMap.put("Airline_location", airline.getAirlineLocation().toText());
                propertyMap.put("MobileNum1", airline.getMobileNum1());
                propertyMap.put("MobileNum2", airline.getMobileNum2());
                propertyMap.put("MobileNum3", airline.getMobileNum3());
                propertyMap.put("Email1", airline.getEmail1());
                propertyMap.put("Email2", airline.getEmail2());
                map.put("AirportId", airline.getAirport().getAirportId());
                map.put("IATACode", airline.getAirport().getIATACode());
                map.put("AirportAddress", airline.getAirport().getAirportAddress());
                map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
                map.put("AirportCountry", airline.getAirport().getAirportCountry());
                map.put("AirportRegion", airline.getAirport().getAirportRegion());
                propertyMap.put("Airport", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Airline" + alId + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Airline Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> getAirlineByIdNative(int alId) {
        Airline airline = airlineRepository.findByAirlineIdNative(alId);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (airline != null) {
                propertyMap.put("AirlineId", airline.getAirlineId());
                propertyMap.put("AirlineName", airline.getAirlineName());
                propertyMap.put("AirlineAddress", airline.getAirlineAddress());
                propertyMap.put("Airline_location", airline.getAirlineLocation().toText());
                propertyMap.put("MobileNum1", airline.getMobileNum1());
                propertyMap.put("MobileNum2", airline.getMobileNum2());
                propertyMap.put("MobileNum3", airline.getMobileNum3());
                propertyMap.put("Email1", airline.getEmail1());
                propertyMap.put("Email2", airline.getEmail2());
                map.put("AirportId", airline.getAirport().getAirportId());
                map.put("IATACode", airline.getAirport().getIATACode());
                map.put("AirportAddress", airline.getAirport().getAirportAddress());
                map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
                map.put("AirportCountry", airline.getAirport().getAirportCountry());
                map.put("AirportRegion", airline.getAirport().getAirportRegion());
                propertyMap.put("Airport", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Airline" + alId + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Airline Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }

    public Map<String, Object> findByAirlineName(String name) {
        List<Airline> existingAirlineOptional = airlineRepository.findByAirlineName(name);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingAirlineOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "There is No Airline By this name.");
            return propertyMap;
        }

        for (Airline airline : existingAirlineOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
            System.out.println("Map \n" + map);
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            System.out.println("\n Data" + data);
        }
        propertyMap.put("status", "success");
        propertyMap.put("data", data);
        return propertyMap;

    }

    public Map<String, Object> getAirlineByNameJPQL(String alName) {
        List<Airline> existingAirlineOptional = airlineRepository.findByAirlineNameJPQL(alName);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map ;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingAirlineOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "There is No Airline By this name.");
            return propertyMap;
        }

        for (Airline airline : existingAirlineOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
            System.out.println("Map \n" + map);
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            System.out.println("\n Data" + data);
        }
        propertyMap.put("status", "success");
        propertyMap.put("data", data);
        return propertyMap;
    }

    public Map<String, Object> getAirlineByNameNative(String alName) {
        List<Airline> existingAirlineOptional = airlineRepository.findByAirlineNameNative(alName);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map ;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingAirlineOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "There is No Airline By this name.");
            return propertyMap;
        }

        for (Airline airline : existingAirlineOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
            System.out.println("Map \n" + map);
            System.out.println("\nProperty Map ====\n" + propertyMap2);
            System.out.println("\n Data" + data);
        }
        propertyMap.put("status", "success");
        propertyMap.put("data", data);
        return propertyMap;
    }

    public Map<String, Object> findByAirlineAddress(String alAddress) {
        List<Airline> existingAirlineOptional = airlineRepository.findByAirlineAddress(alAddress);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingAirlineOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "There is No Airline By this Address.");
            return propertyMap;
        }

        for (Airline airline : existingAirlineOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Airline", data);
        return propertyMap;

    }

    public Map<String, Object> findByAirlineAddressJPQL(String alAddress) {
        List<Airline> existingAirlineOptional = airlineRepository.findByAirlineAddressJPQL(alAddress);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map ;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (existingAirlineOptional.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "There is No Airline By this Address.");
            return propertyMap;
        }

        for (Airline airline : existingAirlineOptional) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);

        }
        propertyMap.put("status", "success");
        propertyMap.put("Airline", data);
        return propertyMap;
    }

    public Map<String, Object> findByAirlineAddressNative(String alAddress) {
        List<Airline> airlines = airlineRepository.findByAirlineAddressNative(alAddress);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map ;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (airlines.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "There is No Airline By this name.");
            return propertyMap;
        }

        for (Airline airline : airlines) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Airline", data);
        return propertyMap;
    }

    //JPQL Query To find By Mobile Number
    public Map<String, Object> findByMobileNumAuto(String mobNum) {
        String mobNum2 = mobNum;
        String mobNum3 = mobNum;

        List<Airline> airlines = airlineRepository.findByMobileNum1OrMobileNum2OrMobileNum3(mobNum, mobNum2, mobNum3);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map ;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (airlines.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "There is No Airline By this name.");
            return propertyMap;
        }

        for (Airline airline : airlines) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Airline", data);
        return propertyMap;
    }

    //JPQL Query To find By Mobile Number
    public Map<String, Object> findByMobileNumJPQL(String mobNum) {
        List<Airline> airlines = airlineRepository.findByMobileNumJPQL(mobNum);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (airlines.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "There is No Airline By this name.");
            return propertyMap;
        }

        for (Airline airline : airlines) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Airline", data);
        return propertyMap;
    }

    public Map<String, Object> findByMobileNumNative(String mobNum) {
        List<Airline> airlines = airlineRepository.findByMobileNumNative(mobNum);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map ;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (airlines.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "There is No Airline By this name.");
            return propertyMap;
        }

        for (Airline airline : airlines) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Airline", data);
        return propertyMap;
    }

    //Derived Query
    public Map<String, Object> findByAirlineNameAndAirportId(String name, int id) {
        List<Airline> airlines = airlineRepository.findByAirlineNameIgnoreCaseAndAirport_AirportId(name, id);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map ;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (airlines.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "There is No Airline By this name.");
            return propertyMap;
        }

        for (Airline airline : airlines) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Airline", data);
        return propertyMap;
    }

    // JPQL Query Foe Airline Name and AirportID
    public Map<String, Object> findByAirlineNameAndAirportIdJPQL(String name, int id) {
        List<Airline> airlines = airlineRepository.findByAirlineNameAndAirportIdJPQL(name, id);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map ;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (airlines.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "There is No Airline By this name.");
            return propertyMap;
        }

        for (Airline airline : airlines) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Airline", data);
        return propertyMap;
    }

    //Native Query Through Airline Name and Airport Id
    public Map<String, Object> findByAirlineNameAndAirportIdNative(String name, int id) {
        List<Airline> airlines = airlineRepository.findByAirlineNameAndAirportIdNative(name, id);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map ;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (airlines.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "There is No Airline By this name.");
            return propertyMap;
        }

        for (Airline airline : airlines) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Airline", data);
        return propertyMap;
    }

  /*  public Map<String, Object> findByDistinctAirlineName() {
        List<Airline> airlines = airlineRepository.findDistinctByAirlineName();
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 = new HashMap<>();
        Map<String, Object> map = new HashMap<>();
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (airlines.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "There is No Airline By this name.");
            return propertyMap;
        }

        for (Airline airline : airlines) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Airline", data);
        return propertyMap;
    }*/

    public Map<String, Object> findByAirlineNameAndAirport_AirportCountry(String name, String country) {
        List<Airline> airlines = airlineRepository.findByAirlineNameContainingAndAirport_AirportCountry(name, country);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map ;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (airlines.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "There is No Airline By this name.");
            return propertyMap;
        }

        for (Airline airline : airlines) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Airline", data);
        return propertyMap;
    }

    public Map<String, Object> findByEmailJPQL(String email) {
        List<Airline> airlines = airlineRepository.findByAirlineEmailJPQL(email);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2;
        Map<String, Object> map;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (airlines.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "There is No Airline By this name.");
            return propertyMap;
        }

        for (Airline airline : airlines) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Airline", data);
        return propertyMap;
    }

    public Map<String, Object> findByEmailNative(String email) {
        List<Airline> airlines = airlineRepository.findByAirlineEmailNative(email);
        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> propertyMap2 ;
        Map<String, Object> map ;
        ArrayList<Map<String, Object>> data = new ArrayList<>();

        if (airlines.isEmpty()) {
            propertyMap.put("status", "error");
            propertyMap.put("error", "data_no_longer_available");
            propertyMap.put("message", "There is No Airline By this name.");
            return propertyMap;
        }

        for (Airline airline : airlines) {
            propertyMap2 = new HashMap<>();
            map = new HashMap<>();
            propertyMap2.put("AirlineId", airline.getAirlineId());
            propertyMap2.put("AirlineName", airline.getAirlineName());
            propertyMap2.put("AirlineAddress", airline.getAirlineAddress());
            propertyMap2.put("Airline_location", airline.getAirlineLocation().toText());
            propertyMap2.put("MobileNum1", airline.getMobileNum1());
            propertyMap2.put("MobileNum2", airline.getMobileNum2());
            propertyMap2.put("MobileNum3", airline.getMobileNum3());
            propertyMap2.put("Email1", airline.getEmail1());
            propertyMap2.put("Email2", airline.getEmail2());
            map.put("AirportId", airline.getAirport().getAirportId());
            map.put("IATACode", airline.getAirport().getIATACode());
            map.put("AirportAddress", airline.getAirport().getAirportAddress());
            map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
            map.put("AirportCountry", airline.getAirport().getAirportCountry());
            map.put("AirportRegion", airline.getAirport().getAirportRegion());
            propertyMap2.put("Airport", map);
            data.add(propertyMap2);
        }
        propertyMap.put("status", "success");
        propertyMap.put("Airline", data);
        return propertyMap;
    }

    // public String ProjectionMethodThroughJoin(){
    public List<Map<String, Object>> getJoinResult() {
        List<Object[]> result = airlineRepository.joinQuery();
        List<Map<String, Object>> mappedResult = new ArrayList<>();

        for (Object[] row : result) {
            Map<String, Object> map = new HashMap<>();
            map.put("airline_id", row[0]);
            map.put("airline_name", row[1]);
            mappedResult.add(map);
        }

        return mappedResult;
    }

    public List<Map<String, Object>> projectionAndJoin(int airlineId) {
        List<Object[]> result = airlineRepository.projectionJoin(airlineId);
        List<Map<String, Object>> mappedResult = new ArrayList<>();
        for (Object[] data : result) {
            Map<String, Object> map = new HashMap<>();
            map.put("airline_id", data[0]);
            map.put("airline_name", data[1]);
            map.put("airline_address", data[2]);
            map.put("airport_id", data[3]);
            map.put("iata_code", data[4]);
            mappedResult.add(map);
        }
        return mappedResult;
    }


    public Map<String, Object> findByIsActiveTrueAndAirlineId(int airlineId) {
        Airline airline;
        Optional<Airline> existingAirlineOptional = airlineRepository.findByIsActiveTrueAndAirlineId(airlineId);

        Map<String, Object> propertyMap = new HashMap<>();
        Map<String, Object> map = new HashMap<>();

        try {
            if (existingAirlineOptional.isPresent()) {
                airline = existingAirlineOptional.get();
                propertyMap.put("AirlineId", airline.getAirlineId());
                propertyMap.put("AirlineName", airline.getAirlineName());
                propertyMap.put("AirlineAddress", airline.getAirlineAddress());
                propertyMap.put("Airline_location", airline.getAirlineLocation().toText());
                propertyMap.put("MobileNum1", airline.getMobileNum1());
                propertyMap.put("MobileNum2", airline.getMobileNum2());
                propertyMap.put("MobileNum3", airline.getMobileNum3());
                propertyMap.put("Email1", airline.getEmail1());
                propertyMap.put("Email2", airline.getEmail2());
                map.put("AirportId", airline.getAirport().getAirportId());
                map.put("IATACode", airline.getAirport().getIATACode());
                map.put("AirportAddress", airline.getAirport().getAirportAddress());
                map.put("Airport Location", airline.getAirport().getAirportLocation().toText());
                map.put("AirportCountry", airline.getAirport().getAirportCountry());
                map.put("AirportRegion", airline.getAirport().getAirportRegion());
                propertyMap.put("Airport", map);
                propertyMap.put("status", "success");
                return propertyMap;
            } else {
                propertyMap.put("status", "error");
                propertyMap.put("error", "no_longer_available");
                propertyMap.put("message", "Sorry, this Airline " + airlineId + " is not longer available.");
                return propertyMap;
            }
        } catch (
                Exception e) {
            propertyMap.put("status", "exception");
            propertyMap.put("exception", "Invalid Airline Id");
            propertyMap.put("message", "Something went Wrong...");
            return propertyMap;
        }
    }
}
