package com.New.ACT.Repository;

import com.New.ACT.model.Duty;
import com.New.ACT.model.Staff;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface DutyRepository extends JpaRepository<Duty, Integer> {

    List<Duty> findByDutyName(String dutyName);

    @Query("Select d from Duty d WHERE d.dutyName=:dutyName")
    List<Duty> findByDutyNameJPQL(String dutyName);

    @Query(value = "Select * from duty d WHERE d.duty_name=:dutyName", nativeQuery = true)
    List<Duty> findByDutyNameNative(String dutyName);


    List<Duty> findByDutyDate(Timestamp dutyDate);

    @Query("Select d from Duty d WHERE d.dutyDate=:dutyDate")
    List<Duty> findByDutyDateJPQL(Timestamp dutyDate);

    @Query(value = "Select * from duty WHERE d.duty_date=:dutyDate", nativeQuery = true)
    List<Duty> findByDutyDateNative(Timestamp dutyDate);


    List<Duty> findByTotalStaffBetween(int start, int stop);

    @Query("Select d from Duty d WHERE d.totalStaff <= :totalStaff")
    List<Duty> findByTotalStaffLessJPQL(int totalStaff);

    @Query(value = "Select * from duty WHERE d.total_staff >= :totalStaff", nativeQuery = true)
    List<Duty> findByTotalStaffHighNative(int totalStaff);

    List<Duty> findByRelatedStaffBetween(int start, int stop);

    @Query("Select d from Duty d WHERE d.relatedStaff <= :relatedStaff")
    List<Duty> findByRelatedStaffLessJPQL(int relatedStaff);

    @Query(value = "Select * from duty WHERE d.related_staff >= :relatedStaff", nativeQuery = true)
    List<Duty> findByRelatedStaffHighNative(int relatedStaff);


    // Find by file location using method name
    List<Duty> findByFileLocation(String fileLocation);

    // Find by file location using JPQL
    @Query("SELECT d FROM Duty d WHERE d.fileLocation = :fileLocation")
    List<Duty> findByFileLocationJPQL(@Param("fileLocation") String fileLocation);

    // Find by file location using Native SQL
    @Query(value = "SELECT * FROM duty WHERE file_location = :fileLocation", nativeQuery = true)
    List<Duty> findByFileLocationNative(@Param("fileLocation") String fileLocation);


    // Find by file name using method name
    List<Duty> findByFileName(String fileName);

    // Find by file name using JPQL
    @Query("SELECT d FROM Duty d WHERE d.fileName = :fileName")
    List<Duty> findByFileNameJPQL(@Param("fileName") String fileName);

    // Find by file name using Native SQL
    @Query(value = "SELECT * FROM duty WHERE file_name = :fileName", nativeQuery = true)
    List<Duty> findByFileNameNative(@Param("fileName") String fileName);


    // Find by status using method name
    List<Duty> findByStatus(boolean status);

    // Find by status using JPQL
    @Query("SELECT d FROM Duty d WHERE d.status = :status")
    List<Duty> findByStatusJPQL(@Param("status") boolean status);

    // Find by status using Native SQL
    @Query(value = "SELECT * FROM duty WHERE status = :status", nativeQuery = true)
    List<Duty> findByStatusNative(@Param("status") boolean status);



    @Query(value = "SELECT * FROM duty d where d.is_delete= false and d.is_active= true and duty_id = :dutyId", nativeQuery = true)
    Optional<Duty> findActiveDutyById(int dutyId);

    //Fetch the record that are deleted
    List<Duty> findByIsDeleteTrue();

    //Through query
    @Query("select d from Duty d where d.isDelete= true and d.isActive=false")
    List<Duty> findAllDeletedDuty();

    @Query("select d from Duty d where d.isDelete= true and d.isActive=false")
    Page<Duty> findAllDeletedDutyPagination(Pageable pageable);

    // Get the record that are not deleted.
    @Query("select d from Duty d where d.isDelete=false and d.isActive=true")
    List<Duty> findAllActiveDuty();

    @Query("select d from Duty d where d.isDelete=false and d.isActive=true")
    Page<Duty> findAllActiveDutyPagination(Pageable pageable);

    @Modifying
    @Query("update Duty d set d.isActive=true, d.isDelete = false where d.isDelete = true and d.dutyId =:dutyId")
    public void revert(@Param("dutyId") int dutyId);

    @Modifying
    @Query(value = "update Duty set is_active = true , is_delete=false where is_delete = true and duty_id = :dutyId", nativeQuery = true)
    public void revertN(@Param("dutyId") int dutyId);

    @Query("SELECT d FROM Duty d WHERE DATE(d.dutyDate) = :targetDate and d.status=true")
    List<Duty> getRecordsForDate(@Param("targetDate") Date targetDate);
}
