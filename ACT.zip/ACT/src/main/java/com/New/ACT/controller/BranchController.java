package com.New.ACT.controller;

import com.New.ACT.service.AirportService;
import com.New.ACT.service.BranchService;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("branches")
public class BranchController {
    @Autowired
    BranchService branchService;

    //Insert
    @PostMapping("/add")
    public Map<String, Object> addBranch(@RequestBody String branchData, HttpServletRequest request) throws JSONException {
        return branchService.addBranch(branchData, request);
    }

    //Update the Branch
    @PutMapping("/update")
    public Map<String, Object> updateBranchById(@RequestBody String branchData) throws JSONException {
        return branchService.updateBranchById(branchData);
    }

    //pass data in the form-data
    @PutMapping("/updateByParam")
    public Map<String, Object> updateBranchByIdParam(@RequestParam String branchData) throws JSONException {
        return branchService.updateBranchById(branchData);
    }

    //Get Method
    @GetMapping("/getBranchById")
    public Map<String, Object> getBranchById(@RequestParam int brId) {
        return branchService.getBranchById(brId);
    }

    @GetMapping("/getBranchByIdNative")
    public Map<String, Object> getBranchByIdNative(@RequestParam int brId) {
        return branchService.getBranchByIdNative(brId);
    }

    @GetMapping("/getActiveBranchById/{brId}")
    public Map<String, Object> getActiveBranchByIdJPQL(@PathVariable int brId) {
        return branchService.getActiveBranchByIdJPQL(brId);
    }
    //Get Method
    @GetMapping("/getActiveBranchById")
    public Map<String, Object> getActiveBranchById(@RequestParam int brId) {
        return branchService.getActiveBranchById(brId);
    }

    @GetMapping("/getBranchByNameNative")
    public Map<String, Object> getBranchByNameNative(@RequestParam String branchName) {
        return branchService.getBranchByNameNative(branchName);
    }

    @GetMapping("/getBranchByNameJPQL")
    public Map<String, Object> getBranchByNameJPQL(@RequestParam String branchName) {
        return branchService.getBranchByNameJPQL(branchName);
    }

    @GetMapping("/getBranchByName")
    public Map<String, Object> getBranchByName(@RequestParam String branchName) {
        return branchService.getBranchByName(branchName);
    }

    @GetMapping("/getBranchByAddressNative")
    public Map<String, Object> getBranchByAddressNative(@RequestParam String branchAddress) {
        return branchService.getBranchByAddressNative(branchAddress);
    }

    @GetMapping("/getBranchByAddressJPQL")
    public Map<String, Object> getBranchByAddressJPQL(@RequestParam String branchAddress) {
        return branchService.getBranchByAddressJPQL(branchAddress);
    }

    @GetMapping("/getBranchByAddress")
    public Map<String, Object> getBranchByAddress(@RequestParam String branchAddress) {
        return branchService.getBranchByAddress(branchAddress);
    }


    @GetMapping("/getBranchByCountry")
    public Map<String, Object> getBranchByCountry(@RequestParam String branchCountry) {
        return branchService.getBranchByCountry(branchCountry);
    }

    @GetMapping("/getBranchByCountryJPQL")
    public Map<String, Object> getBranchByCountryJPQL(@RequestParam String branchCountry) {
        return branchService.getBranchByCountryJPQL(branchCountry);
    }

    @GetMapping("/getBranchByCountryNative")
    public Map<String, Object> getBranchByCountryNative(@RequestParam String branchCountry) {
        return branchService.getBranchByCountryNative(branchCountry);
    }

    @GetMapping("/getBranchByCode")
    public Map<String, Object> getBranchByCode(@RequestParam String branchCode) {
        return branchService.getBranchByCode(branchCode);
    }

    @GetMapping("/getBranchByCodeJPQL")
    public Map<String, Object> getBranchByCodeJPQL(@RequestParam String branchCode) {
        return branchService.getBranchByCodeJPQL(branchCode);
    }

    @GetMapping("/getBranchByCodeNative")
    public Map<String, Object> getBranchByCodeNative(@RequestParam String branchCode) {
        return branchService.getBranchByCodeNative(branchCode);
    }


    // Get Deleted Record Only
    @GetMapping("delBranches")
    public Map<String, Object> getDeletedBranches() {
        return branchService.getDeletedBranches();
    }

    // Get Deleted Record Only with Pagination
    @GetMapping("delBranchesPagination")
    public Map<String, Object> getDeletedBranchesPagination(@RequestParam(defaultValue = "0") int page,
                                                            @RequestParam(defaultValue = "5") int size,
                                                            @RequestParam(defaultValue = "branchId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).descending().and(Sort.by("branchCountry")));
        return branchService.getDeletedBranchesPagination(pageable);
    }

    // Get Active Record Only
    @GetMapping("activeBranches")
    public Map<String, Object> getActiveBranches() {
        return branchService.getActiveBranches();
    }

    @GetMapping("activeBranchesPagination")
    public Map<String, Object> getActiveBranchesPagination(@RequestParam(defaultValue = "0") int page,
                                                           @RequestParam(defaultValue = "5") int size,
                                                           @RequestParam(defaultValue = "branchId") String sortBy) {
        return branchService.getActiveBranchesPagination(page, size, sortBy);
    }


    @GetMapping("/getAllBranches")
    public Map<String, Object> getAllBranches() {
        return branchService.getAllBranches();
    }

    @GetMapping("allBranchesPagination")
    public Map<String, Object> getAllBranchesPagination(@RequestParam(defaultValue = "0") int page,
                                                        @RequestParam(defaultValue = "5") int size,
                                                        @RequestParam(defaultValue = "branchId") String sortBy) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).descending().and(Sort.by("branchCode")));
        return branchService.getAllBranchesPagination(pageable);
    }

    // Soft Delete
    @DeleteMapping("delete/{branchId}")
    public Map<String, Object> delBranchById(@PathVariable int branchId) {
        return branchService.delBranchById(branchId);
    }

    //Hard Delete
    @DeleteMapping("/{branchId}")
    public Map<String, Object> delBranchHardById(@PathVariable int branchId) {
        return branchService.delBranchHardById(branchId);
    }

    //Revert
    @PutMapping("revert/{branchId}")
    public Map<String, Object> revertBranchById(@PathVariable int branchId) {
        return branchService.revertBranchById(branchId);
    }


}
