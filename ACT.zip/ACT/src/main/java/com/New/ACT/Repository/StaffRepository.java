package com.New.ACT.Repository;

import com.New.ACT.model.Driver;
import com.New.ACT.model.Staff;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface StaffRepository extends JpaRepository<Staff, Integer> {


    Optional<Staff> findByMobileNum1OrMobileNum2(String mobNum, String mobNum2);

    @Query("Select s from Staff s WHERE s.mobileNum1=:mobNum or s.mobileNum2=:mobNum")
    Optional<Staff> findByStaffMobNumJPQL(String mobNum);

    @Query(value = "Select s from staff s WHERE s.mobileNum1=:mobNum or s.mobileNum2=:mobNum", nativeQuery = true)
    Optional<Staff> findByStaffMobNumNative(String mobNum);


    Optional<Staff> findByEmail(String email);

    @Query("Select s from Staff s WHERE s.email=:email")
    Optional<Staff> findByEmailJPQL(String email);

    @Query(value = "Select s from staff s WHERE s.email=:email", nativeQuery = true)
    Optional<Staff> findByEmailNative(String email);


    Optional<Staff> findByStaffAddress(String staffAddress);

    @Query("Select s from Staff s WHERE s.staffAddress=:staffAddress")
    Optional<Staff> findByStaffAddressJPQL(String staffAddress);

    @Query(value = "Select s from staff s WHERE s.staff_address=:staffAddress", nativeQuery = true)
    Optional<Staff> findByStaffAddressNative(String staffAddress);


    Optional<Staff> findByStaffFullName(String staffFullName);

    @Query("Select s from Staff s WHERE s.staffFullName=:staffFullName")
    Optional<Staff> findByStaffFullNameJPQL(String staffFullName);

    @Query(value = "Select s from staff s WHERE s.staff_full_name=:staffFullName", nativeQuery = true)
    Optional<Staff> findByStaffFullNameNative(String staffFullName);


    Optional<Staff> findByStaffCode(String staffCode);

    @Query("Select s from Staff s WHERE s.staffCode=:staffCode")
    Optional<Staff> findByStaffCodeJPQL(String staffCode);

    @Query(value = "Select s from staff s WHERE s.staffCode=:staffCode", nativeQuery = true)
    Optional<Staff> findByStaffCodeNative(String staffCode);


    List<Staff> findByStaffSex(String staffSex);

    @Query("Select s from Staff s WHERE s.staffSex=:staffSex")
    List<Staff> findByStaffSexJPQL(String staffSex);

    @Query(value = "Select * from staff s WHERE s.staff_sex=:staffSex", nativeQuery = true)
    List<Staff> findByStaffSexNative(String staffSex);

    List<Staff> findByAirline_AirlineId(int airlineId);

    List<Staff> findByAirline_AirlineName(String airlineName);

    @Query("Select s from Staff s JOIN s.airline a WHERE a.airlineName=:airlineName")
    List<Staff> findStaffByAirlineNameJPQL(String airlineName);

    @Query(value = "Select * from staff s JOIN airline a ON s.airline_id = a.airline_id WHERE a.airlineName=:airlineName", nativeQuery = true)
    List<Staff> findStaffByAirlineNameNative(String airlineName);


    //Fetch the record that are deleted
    List<Staff> findByIsDeleteTrue();

    @Query(value = "select * from staff s where s.is_delete=false and s.is_active = true and s.staff_id = :staffId", nativeQuery = true)
    Optional<Staff> findActiveStaffById(int staffId);

    @Query("select s from Staff s where s.isDelete=false and s.isActive = true and s.staffId = :staffId")
    Optional<Staff> findActiveStaffByIdJPQL(int staffId);

    Optional<Staff> findByStaffId(int staffId);

    //Through query
    @Query("select s from Staff s where s.isDelete= true")
    List<Staff> findAllDeletedStaff();

    //Through query
    @Query("select s from Staff s where s.isDelete= true")
    Page<Staff> findAllDeletedStaffPagination(Pageable pageable);

    // Get the record that are not deleted.
    @Query("select s from Staff s where s.isDelete=false")
    List<Staff> findAllActiveStaff();

    // Get the record that are not deleted.
    @Query("select s from Staff s where s.isDelete=false")
    Page<Staff> findActiveStaffPagination(Pageable pageable);

    //JPQL Query use Object
    @Modifying
    @Query("update Staff s set s.isActive=true, s.isDelete = false where s.isDelete = true and s.staffId =:staffId")
    public void revertStaff(@Param("staffId") int staffId);

    //Native Query use database name
    @Modifying
    @Query(value = "update Staff set is_active = true , is_delete=false , deletion_time = NULL where is_delete = true and staff_id = :staffId", nativeQuery = true)
    public void revertN(@Param("staffId") int staffId);

    //select s1_0.staff_id from staff s1_0 where s1_0.staff_code=? fetch first ? rows only
    boolean existsByStaffCode(String staffCode);

    /*
        @Query(value = "SELECT distinct on (staff_id) ST_Distance(s.staff_location, d.driver_location,'SPHEROID[\"WGS 84\",6378137,298.257223563]') / 1000 AS distance,\n" +
                "       s.staff_id,\n" +
                "       d.driver_id\n" +
                "FROM staff s\n" +
                "CROSS JOIN driver d\n" +
                "WHERE s.staff_code IN :uniqueStaffCodes\n" +
                "ORDER BY  s.staff_id,distance",nativeQuery = true)*/
    @Query(value = "SELECT ST_DistanceSpheroid(s.staff_location, d.driver_location,'SPHEROID[\"WGS 84\",6378137,298.257223563]') / 1000 AS distance,\n" +
            "       s.staff_id,\n" +
            "       d.driver_id\n" +
            "FROM staff s\n" +
            "CROSS JOIN driver d\n" +
            "WHERE s.staff_code IN :uniqueStaffCodes\n" +
            "ORDER BY distance, s.staff_id", nativeQuery = true)
    List<Object[]> staffNDriverAllocation(Set<String> uniqueStaffCodes);


// Driver allocation
    /*SELECT
    s.staff_id,
    (SELECT d.driver_id
     FROM driver d
     ORDER BY ST_Distance(s.staff_location, d.driver_location)
     LIMIT 1) AS driver_id,
    (SELECT ST_Distance(s.staff_location, d.driver_location) * 100000
     FROM driver d
     ORDER BY ST_Distance(s.staff_location, d.driver_location)
     LIMIT 1) AS distance
FROM
    staff s */

    /*WITH distances AS (
    SELECT
        s.staff_id,
        d.driver_id,
        ST_Distance(s.staff_location, d.driver_location) * 100000 AS distance,
        ROW_NUMBER() OVER (PARTITION BY s.staff_id ORDER BY ST_Distance(s.staff_location, d.driver_location)) AS staff_row_num,
        ROW_NUMBER() OVER (PARTITION BY d.driver_id ORDER BY ST_Distance(s.staff_location, d.driver_location)) AS driver_row_num
    FROM
        staff s
    CROSS JOIN
        driver d
)
SELECT
    staff_id,
    driver_id,
    distance
FROM
    distances
WHERE
    staff_row_num = 1 AND driver_row_num <= 2;*/


    // Find through Staff By airline Name
}
