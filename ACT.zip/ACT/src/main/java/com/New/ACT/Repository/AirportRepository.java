package com.New.ACT.Repository;

import com.New.ACT.model.Airline;
import com.New.ACT.model.Airport;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AirportRepository extends JpaRepository<Airport, Integer> {

    Optional<Airport> findByAirportId(int airportId);

    @Query("select a from Airport a where a.airportId=?1")
    Optional<Airport> findByAirportIdJPQL(int airportId);

    @Query(value = "select * from airport where airport_id=:airportId", nativeQuery = true)
    Optional<Airport> findByAirportIdNative(int airportId);


    Optional<Airport> findByIATACode(String IATACode);

    @Query("select a from Airport a where a.IATACode=:IATACode")
    Optional<Airport> findByIATACodeJPQL(String IATACode);

    @Query(value = "select * from airport where iata_code=?1", nativeQuery = true)
    Optional<Airport> findByIATACodeNative(String IATACode);


    List<Airport> findByAirportAddress(String airportAddress);

    @Query("select a from Airport a where a.airportAddress = ?1")
    List<Airport> findByAirportAddressJPQL(String airportAddress);

    @Query(value = "select * from airport where airport_address = ?1", nativeQuery = true)
    List<Airport> findByAirportAddressNative(String airportAddress);

    List<Airport> findByAirportCountry(String airportCountry);

    @Query("select a from Airport a where a.airportCountry = ?1")
    List<Airport> findByAirportCountryJPQL(String airportCountry);

    @Query(value = "select * from airport where airport_country = ?1", nativeQuery = true)
    List<Airport> findByAirportCountryNative(String airportCountry);

    List<Airport> findByAirportRegion(String airportRegion);

    @Query("select a from Airport a where a.airportRegion = ?1")
    List<Airport> findByAirportRegionJPQL(String airportRegion);

    @Query(value = "select * from airport where airport_address = ?1", nativeQuery = true)
    List<Airport> findByAirportRegionNative(String airportRegion);


    //Native
    //@Query(value = "select a.airport_id,a.iata_code,a.airport_address,a.airport_country,a.airport_region from airport a where a.is_delete=true",nativeQuery = true)
    @Query(value = "select * from airport where is_delete=true and is_active=false", nativeQuery = true)
    public List<Airport> findSoftDelAirports();

    @Query(value = "select * from airport where is_delete=true and is_active=false", nativeQuery = true)
    public Page<Airport> findSoftDelAirportsPagination(Pageable pageable);

    //JPQL
    @Query("select a from Airport a where a.isDelete=false and a.isActive = true")
    List<Airport> findActiveAirports();

    //NAtive
    @Query(value = "select * from airport a where a.is_delete=false and a.is_active = true", nativeQuery = true)
    Page<Airport> findActiveAirportsPagination(Pageable pageable);

    @Query(value = "select * from airport where is_active=true and deletion_time is null and airport_id=:airportId", nativeQuery = true)
    Optional<Airport> findActiveByAirportId(int airportId);


}
