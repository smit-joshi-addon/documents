package com.New.ACT.Repository;

import com.New.ACT.model.Airline;
import com.New.ACT.model.Branch;
import com.New.ACT.model.Driver;
import com.New.ACT.model.Vehicle;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DriverRepository extends JpaRepository<Driver, Integer> {

    Optional<Driver> findByDriverId(int driverId);

    @Query("Select d from  Driver d WHERE d.driverId=:driverId")
    Optional<Driver> findByDriverIdJPQL(int driverId);

    @Query(value = "SELECT * FROM driver d where d.driver_id = :driverId", nativeQuery = true)
    Optional<Driver> findByDriverIdNative(int driverId);


    Optional<Driver> findByLicenceNum(String licenceNum);

    @Query("Select d from Driver d WHERE d.licenceNum=:licenceNum")
    Optional<Driver> findByLicenceNumJPQL(String licenceNum);

    @Query(value = "SELECT * FROM driver d where d.licence_num = :licenceNum", nativeQuery = true)
    Optional<Driver> findByLicenceNumNative(String licenceNum);

    List<Driver> findByDriverSex(String driverSex);

    @Query("Select d from Driver d WHERE d.driverSex=:driverSex")
    List<Driver> findByDriverSexJPQL(String driverSex);

    @Query(value = "Select d from driver d WHERE d.driver_sex=:driverSex", nativeQuery = true)
    List<Driver> findByDriverSexNative(String driverSex);

    List<Driver> findByDriverName(String driverName);

    @Query("Select d from Driver d WHERE d.driverName=:driverName")
    List<Driver> findByDriverNameJPQL(String driverName);

    @Query(value = "Select d from driver d WHERE d.driver_name=:driverName", nativeQuery = true)
    List<Driver> findByDriverNameNative(String driverName);


    Optional<Driver> findByMobileNum1OrMobileNum2(String mobNum, String mobNum2);

    @Query("Select d from Driver d WHERE d.mobileNum1=:mobNum or d.mobileNum2=:mobNum")
    Optional<Driver> findByDriverMobNumPQL(String mobNum);

    @Query(value = "Select d from driver d WHERE d.mobileNum1=:mobNum or d.mobileNum2=:mobNum", nativeQuery = true)
    Optional<Driver> findByDriverMobNumNative(String mobNum);


    Optional<Driver> findByEmail(String email);

    @Query("Select d from Driver d WHERE d.email=:email")
    Optional<Driver> findByEmailJPQL(String email);

    @Query(value = "Select d from driver d WHERE d.email=:email", nativeQuery = true)
    Optional<Driver> findByEmailNative(String email);


    List<Driver> findByBranch(Branch branch);

    @Query("Select d from Driver d WHERE d.branch=:branch")
    List<Driver> findByBranchJPQL(Branch branch);

    //You can not pass object to the spring boot as per new version so you have to pass the field type as per database
    @Query(value = "Select d from driver d WHERE d.branch_id=:branchId", nativeQuery = true)
    List<Driver> findByBranchNative(int branchId);


    List<Driver> findByVehicle(Vehicle vehicle);

    @Query("Select d from Driver d WHERE d.vehicle=:vehicle")
    List<Driver> findByVehicleJPQL(Vehicle vehicle);

    @Query(value = "Select * from driver d WHERE d.vehicle_id=:vehicleId", nativeQuery = true)
    List<Driver> findByVehicleNative(int vehicleId);


    List<Driver> findByBranch_BranchNameAndDriverSex(String branchName, String driverSex);

    @Query("select d from Driver d JOIN d.branch b where LOWER(b.branchName) = LOWER(?1) AND  LOWER(d.driverSex) = LOWER(?2)")
    List<Driver> findByBranch_BranchNameAndDriverSexJPQl(String branchName, String driverSex);

    @Query(value = "select d.* from driver d JOIN branch b ON d.branch_id = b.branch_id where LOWER(b.branch_name) = LOWER(?1) AND  LOWER(d.driver_sex) = LOWER(?2)", nativeQuery = true)
    List<Driver> findByBranch_BranchNameAndDriverSexNative(String branchName, String driverSex);


    //Fetch the record that are deleted
    List<Driver> findByIsDeleteTrue();

    //Through query
    @Query("select d from Driver d where d.isDelete= true and d.deletionTime is null")
    Page<Driver> findDeletedRecords(Pageable pageable);

    // Get the record that are not deleted.
    @Query(value = "select * from driver d where d.is_delete=false and d.is_active=true", nativeQuery = true)
    Page<Driver> findActiveRecords(Pageable pageable);

    @Query(value = "select * from Driver d where d.is_delete= false and d.is_active= true", nativeQuery = true)
    List<Driver> findActiveDrivers();

    @Query(value = "select * from Driver d where d.is_delete= false and d.is_active= true and d.driver_id = :driverId", nativeQuery = true)
    Optional<Driver> findActiveDriverById(int driverId);

    @Modifying
    @Query("update Driver d set d.isActive=true, d.isDelete = false where d.isDelete = true and d.driverId =:drId")
    public void revertJPQL(@Param("drId") int drId);

    @Modifying
    @Query(value = "update driver set is_active = true , is_delete=false where is_delete = true and driver_id = :drId", nativeQuery = true)
    public void revertN(@Param("drId") int drId);

    /*  @Query("SELECT DISTINCT d.driverId, s.staffId, \" +\n" +
              "       \"FUNCTION('ST_Distance', d.driverLocation, s.staffLocation) AS distance \" +\n" +
              "       \"FROM Staff s \" +\n" +
              "       \"WHERE FUNCTION('ST_DWithin', d.driverLocation, s.staffLocation, :radius) = true \" +\n" +
              "       \"ORDER BY s.staffId, distance, d.driverId\"")*/
    @Query(value = "SELECT DISTINCT ON (s.staff_id) s.staff_id , d.driver_id, ST_Distance(d.driver_location, s.staff_location) AS distance from driver d LEFT JOIN staff s ON ST_DWithin(d.driver_location, s.staff_location, :radius)ORDER BY s.staff_id, distance,d.driver_id", nativeQuery = true)
    public List<Object[]> findNearestStaffByDriver(double radius);

    @Query(value = "SELECT d.driver_id, v.vehicle_person_capacity FROM driver d JOIN vehicle v ON d.vehicle_id = v.vehicle_id",nativeQuery = true)
    public List<Object[]> vehiclePersonCapacity();

    @Query("SELECT v.vehiclePersonCapacity FROM Driver d JOIN d.vehicle v WHERE d.driverId = :driverId")
    public Integer findVehiclePersonCapacityByDriverId(Integer driverId);
}
