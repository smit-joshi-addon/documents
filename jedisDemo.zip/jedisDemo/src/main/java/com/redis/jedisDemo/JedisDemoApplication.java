package com.redis.jedisDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JedisDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JedisDemoApplication.class, args);
	}

}
