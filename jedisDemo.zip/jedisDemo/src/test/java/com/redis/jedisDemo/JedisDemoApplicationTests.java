package com.redis.jedisDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JedisDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
