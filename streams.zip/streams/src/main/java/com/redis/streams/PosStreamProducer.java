package com.redis.streams;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.web.bind.annotation.*;
import redis.clients.jedis.StreamEntryID;
import redis.clients.jedis.UnifiedJedis;
import redis.clients.jedis.params.XAddParams;
import redis.clients.jedis.resps.StreamEntry;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("stream")
public class PosStreamProducer {

   /* public void setJedis(UnifiedJedis jedis) {
        this.jedis = jedis;
    }*/

    @PostMapping("demo")
    public void PosStream(@RequestBody String jsonData) throws JsonProcessingException {

        // Connect to Redis server
        UnifiedJedis jedis = new UnifiedJedis("redis://localhost:6379");
        // Convert JSON to Map
        Map<String, String> jsonDataMap = convertJsonToMap(jsonData);


        // Use xadd to add an entry to the stream
        StreamEntryID entryID = jedis.xadd("stream:devicePosition", jsonDataMap, XAddParams.xAddParams());

        System.out.println("Entry added to stream with ID: " + entryID);

        long len = jedis.xlen("stream:devicePosition");
        System.out.println(len); // >>> 4

        List<StreamEntry> res12 = jedis.xrange("stream:devicePosition","-","+");

        System.out.println(
                res12
        );
        // Close the connection
        jedis.close();



        /*StreamEntryID res = jedis.xadd("race:france", new HashMap<String, String>() {{
            put("rider", "Castilla");
            put("speed", "30.2");
            put("position", "1");
            put("location_id", "1");
        }}, XAddParams.xAddParams());*/

        /*JsonObject jsonObject = new JsonObject();
        ObjectMapper obMapper = new ObjectMapper();
        Position position = obMapper.readValue(jsonData, Position.class);

        StreamEntryID one = jedis.xadd("stream:devicePosition", new HashMap<String, String>() {{
            put("1",);
        }});*/

        //System.out.println(res);

    }

    private static Map<String, String> convertJsonToMap(String jsonData) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(jsonData);

            // Flatten the nested structure of JSON into a flat map
            Map<String, String> result = new HashMap<>();
            flattenJson(jsonNode, "", result);

            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static void flattenJson(JsonNode jsonNode, String prefix, Map<String, String> result) {
        if (jsonNode.isObject()) {
            Iterator<Map.Entry<String, JsonNode>> fields = jsonNode.fields();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> entry = fields.next();
                flattenJson(entry.getValue(), prefix + entry.getKey() + ".", result);
            }
        } else if (jsonNode.isValueNode()) {
            result.put(prefix.substring(0, prefix.length() - 1), jsonNode.asText());
        }
    }

}
