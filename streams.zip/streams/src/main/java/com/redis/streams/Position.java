package com.redis.streams;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import org.springframework.data.annotation.Id;

import java.sql.Timestamp;

@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
//@RequiredArgsConstructor(staticName = "of")
@AllArgsConstructor(access = AccessLevel.PROTECTED)
@Data
public class Position {

    @Id

    private long id;

    private Timestamp fixTime;

   /* @NonNull
    @Indexed(sortable = true)
    private LocalDateTime permitTimestamp = LocalDateTime.now();*/

    private Attributes attributes;

    private long deviceId;

    private String type;

    private String uuid;

    private String protocol;

    private Timestamp serverTime;

    private Timestamp deviceTime;

    private Boolean outdated;

    private Boolean valid;

    private double latitude;

    private double longitude;

    private double altitude;

    private double speed;

    private double course;

    private String address;

    private int accuracy;

    private long business_device_id;

    private String network;

    private int ignition;

    private int trip;

    private long port;

    private double distance;

    private int stopage_time;

    private String obtype;

    private double battery;

    private double mileage;

    private int idle;

    private int fuel;

    private int temperature;

    private int ac;

    private String vin_number;

}