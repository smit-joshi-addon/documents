package com.redislettuce.stream;

import io.lettuce.core.RedisBusyException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.RedisSystemException;
import org.springframework.data.redis.connection.stream.Consumer;
import org.springframework.data.redis.connection.stream.MapRecord;
import org.springframework.data.redis.connection.stream.ReadOffset;
import org.springframework.data.redis.connection.stream.StreamOffset;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;
import java.time.Duration;
import java.util.List;
import reactor.core.publisher.Flux; //For Reactive Data


/*@RestController
@RequestMapping("stream")*/
/*@Component
public class Consumer {
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    //@Scheduled(fixedRate = 10000) // Adjust the rate as needed
    @GetMapping("consume")
    public void consumeFromStream() {
        StreamOffset<String> offset = StreamOffset.fromStart("devicePositionStream");
        redisTemplate.opsForStream().read(offset).forEach(entry -> {
            // Process the entry (e.g., log it, perform business logic)
            System.out.println("Received entry: " + entry);
        });
    }
}*/

@RestController
@RequestMapping("consume")
public class ConsumerController {

    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    @Autowired
    private RedisTemplate<String, Object> redisObTemplate;

    public final static String STREAMS_KEY = "devicePositionStream";

    public String consGroup;

    /*public RedisStreamConsumer(RedisTemplate<String, String> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }*/

    //Consumer Group Creation
    private static final Logger log = LoggerFactory.getLogger(ConsumerController.class);

    @PostMapping("consumerGroup")
    public void createConsumerGroup(@RequestParam String key, @RequestParam String group) {
        try {
            redisTemplate.opsForStream().createGroup(key, group);
        } catch (RedisSystemException e) {
            var cause = e.getRootCause();
            if (cause != null && RedisBusyException.class.equals(cause.getClass())) {
                log.info("STREAM - Redis group '{}' already exists. Skipping Redis group creation.", group);
            } else {
                throw e;
            }
        }
    }

    @PostMapping("consumer")
    //public void consumeMessages(String streamName, String consumerGroup, String consumerName)
    public void consumeMessages(@RequestParam String consumerGroup, @RequestParam String consumerName) {
        String streamName = STREAMS_KEY;
        StreamOffset<String> offset = StreamOffset.create(streamName, ReadOffset.lastConsumed());


        List<MapRecord<String, Object, Object>> records = redisObTemplate.opsForStream()
                .read(Consumer.from(consumerGroup, consumerName), offset);

        // Process each message
        for (MapRecord<String, Object, Object> record : records) {
            // Process the message
            System.out.println("Received message: " + record.getValue());

            // Acknowledge the message
            redisTemplate.opsForStream()
                    .acknowledge(streamName, consumerGroup, record.getId());
        }

        /*
            // Continuously read messages from the stream
            while (true) {
                redisTemplate.opsForStream()
                        .read(StreamOffset.from(streamName, ReadOffset.from("0")), Consumer.from(consumerGroup), StreamReadOptions.empty())
                        .forEach(message -> {
                            // Process the message
                            System.out.println("Received message: " + message);
                            // Acknowledge the message
                            redisTemplate.opsForStream().acknowledge(streamName, consumerGroup, message);
                        });
            }*/

        try {
            Thread.sleep(1000); // Wait for 1 second before polling again
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

    }
}








