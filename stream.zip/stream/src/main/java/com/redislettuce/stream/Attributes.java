package com.redislettuce.stream;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
//@RequiredArgsConstructor(staticName = "of")
@AllArgsConstructor(access = AccessLevel.PROTECTED)
@Data
public class Attributes {


    private int sat;

    private int mcc;


    private int mnc;


    private int lac;


    private long cid;


    private boolean ignition;


    private String ignition_on;

    private String ignition_off;


    private long event;


    private boolean archive;


    private double mileage;

    private double total_mileage;

    private double distance;


    private int status;


    private double totalDistance;

    private boolean motion;

    private long hours;


    private double power;


}

